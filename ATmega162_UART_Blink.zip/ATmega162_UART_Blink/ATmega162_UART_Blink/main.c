#define F_CPU 4915200UL
#define BAUD 9600UL
#define UBRR_VALUE ((F_CPU / (16UL * BAUD)) - 1)  // = 31 -> 0% error at this crystal frequency

#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>

// ---------- USART0 basic functions ----------

// Initialize USART0 for 9600 baud, 8N1 (8 data bits, no parity, 1 stop bit)
void uart_init(void)
{
	UBRR0H = (uint8_t)(UBRR_VALUE >> 8);   // set baud rate register (high byte)
	UBRR0L = (uint8_t)UBRR_VALUE;          // set baud rate register (low byte)

	UCSR0B = (1 << RXEN0) | (1 << TXEN0);  // enable receiver and transmitter
	UCSR0C = (1 << URSEL0) | (1 << UCSZ01) | (1 << UCSZ00); // URSEL0 required on ATmega162
	// to write UCSR0C (shared address
	// with UBRR0H); UCSZ01/00 = 8 data bits
}

// Send one character via UART0. Used as the "put" function for the stdio stream.
int uart_putchar(char c, FILE *stream)
{
	if (c == '\n')
	uart_putchar('\r', stream);  // send CR before LF (standard terminal behavior)

	while (!(UCSR0A & (1 << UDRE0)))
	;  // wait until the transmit data register is empty

	UDR0 = c;  // load character into transmit buffer -> triggers sending
	return 0;
}

// Receive one character via UART0 (blocking). Used as the "get" function for the stdio stream.
int uart_getchar(FILE *stream)
{
	while (!(UCSR0A & (1 << RXC0)))
	;  // wait until a character has been received

	return UDR0;  // read and return the received byte
}

// Single FILE stream used for both stdin and stdout (read + write)
static FILE uart_stream;

// ---------- Main program ----------

int main(void)
{
	uart_init();  // set up UART0 (9600 baud, 8N1)

	// Connect uart_putchar/uart_getchar to the stdio stream and enable printf/getchar
	fdev_setup_stream(&uart_stream, uart_putchar, uart_getchar, _FDEV_SETUP_RW);
	stdout = &uart_stream;
	stdin  = &uart_stream;

	DDRC |= (1 << PC0);  // configure PC0 as output (LED)

	uint16_t blink_delay_ms = 500;  // default blink interval

	// Print welcome message and menu once at startup
	printf("\r\nRS232 LED Blink Control\r\n");
	printf("Select speed:\r\n");
	printf("  1 = slow   (1000 ms)\r\n");
	printf("  2 = medium (500 ms)\r\n");
	printf("  3 = fast   (100 ms)\r\n");

	while (1)
	{
		// Non-blocking check: has a character arrived?
		if (UCSR0A & (1 << RXC0))
		{
			char c = getchar();  // read the received character

			switch (c)
			{
				case '1':
				blink_delay_ms = 1000;
				printf("-> slow selected (1000 ms)\r\n");
				break;
				case '2':
				blink_delay_ms = 500;
				printf("-> medium selected (500 ms)\r\n");
				break;
				case '3':
				blink_delay_ms = 100;
				printf("-> fast selected (100 ms)\r\n");
				break;
				default:
				printf("Invalid input: '%c'\r\n", c);
				break;
			}
		}

		PORTC ^= (1 << PC0);  // toggle LED on PC0

		// Wait in 10 ms steps instead of one long delay, so a new UART
		// input can interrupt the current blink phase immediately
		for (uint16_t i = 0; i < blink_delay_ms / 10; i++)
		{
			_delay_ms(10);

			if (UCSR0A & (1 << RXC0))  // new input arrived -> break out early
			break;
		}
	}
}