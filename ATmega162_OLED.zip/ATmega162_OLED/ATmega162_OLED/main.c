#define F_CPU 4915200UL
#define BAUD 9600UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>      // PSTR, printf_P
#include <util/delay.h>
#include <stdio.h>
#include "uart.h"
#include "sram.h"
#include "adc.h"
#include "joystick.h"
#include "spi.h"
#include "oled.h"

#define PADDLE_WIDTH   24
#define PADDLE_HEIGHT   4
#define PADDLE_Y       (OLED_HEIGHT - PADDLE_HEIGHT)

static uint8_t paddle_x_from_joystick(int16_t joy_x)
{
	int16_t travel = OLED_WIDTH - PADDLE_WIDTH;
	int16_t pos = ((joy_x + JOY_OUT_MAX) * travel) / (2 * JOY_OUT_MAX);

	if (pos < 0) pos = 0;
	if (pos > travel) pos = travel;

	return (uint8_t)pos;
}

static void draw_frame(uint8_t paddle_x)
{
	oled_clear();

	oled_draw_hline(0, 0, OLED_WIDTH, 1);
	oled_draw_vline(0, 0, OLED_HEIGHT, 1);
	oled_draw_vline(OLED_WIDTH - 1, 0, OLED_HEIGHT, 1);

	oled_fill_rect(paddle_x, PADDLE_Y, PADDLE_WIDTH, PADDLE_HEIGHT, 1);

	oled_flush();
}

static void framebuffer_selftest(void)
{
	volatile uint8_t *fb = (uint8_t *)OLED_BUFFER_ADDR;

	oled_clear();
	oled_set_pixel(0, 0, 1);
	printf_P(PSTR("buffer[0]   = 0x%02X (expect 0x01)\r\n"), fb[0]);

	oled_set_pixel(5, 9, 1);
	printf_P(PSTR("buffer[133] = 0x%02X (expect 0x02)\r\n"), fb[133]);

	oled_clear();
	printf_P(PSTR("after clear = 0x%02X (expect 0x00)\r\n"), fb[0]);
}

int main(void)
{
	DDRE |= (1 << PE2);   // heartbeat LED

	uart_init();
	sei();

	xmem_init();          // REQUIRED: the framebuffer lives in external SRAM
	adc_init();
	spi_init();
	oled_init();

	joystick_calibrate();

	printf_P(PSTR("\r\nNode 1 -- OLED bring-up\r\n"));
	framebuffer_selftest();

	printf_P(PSTR("  1 = 0xA5 all pixels on\r\n"));
	printf_P(PSTR("  2 = 0xA4 resume from RAM\r\n"));
	printf_P(PSTR("  3 = test square 32x32\r\n"));
	printf_P(PSTR("  4 = clear display\r\n"));
	printf_P(PSTR("  5 = 0xAF display on\r\n"));
	printf_P(PSTR("  6 = 0xAE display off\r\n"));
	printf_P(PSTR("  7 = framebuffer selftest\r\n"));
	printf_P(PSTR("  8 = fill framebuffer\r\n"));
	printf_P(PSTR("  o = flip orientation\r\n"));
	printf_P(PSTR("  t = SRAM test\r\n"));
	printf_P(PSTR("  c = recalibrate joystick\r\n"));
	printf_P(PSTR("  p = toggle paddle demo\r\n"));

	uint8_t paddle_running = 0;
	uint8_t last_paddle_x = 255;
	uint8_t flipped = 1;

	while (1)
	{
		if (uart_available())
		{
			char c = getchar();

			switch (c)
			{
				case '1':
				oled_write_command(0xA5);
				printf_P(PSTR("All pixels on\r\n"));
				break;

				case '2':
				oled_write_command(0xA4);
				printf_P(PSTR("Resume from RAM\r\n"));
				break;

				case '3':
				oled_clear();
				oled_fill_rect(0, 0, 32, 32, 1);
				oled_flush();
				printf_P(PSTR("Square drawn\r\n"));
				break;

				case '4':
				oled_clear();
				oled_flush();
				printf_P(PSTR("Cleared\r\n"));
				break;

				case '5':
				oled_write_command(0xAF);
				printf_P(PSTR("Display ON\r\n"));
				break;

				case '6':
				oled_write_command(0xAE);
				printf_P(PSTR("Display OFF\r\n"));
				break;

				case '7':
				framebuffer_selftest();
				break;

				case '8':
				{
					// Bypasses the pixel helpers -- a blank screen after
					// this points at the flush or the display, not at
					// the drawing maths.
					volatile uint8_t *fb = (uint8_t *)OLED_BUFFER_ADDR;
					for (uint16_t i = 0; i < OLED_BUF_SIZE; i++)
					fb[i] = 0xFF;
					oled_flush();
					printf_P(PSTR("Buffer filled\r\n"));
					break;
				}

				case 'o':
				case 'O':
				flipped = !flipped;
				oled_write_command(flipped ? 0xA1 : 0xA0);
				oled_write_command(flipped ? 0xC8 : 0xC0);
				oled_flush();
				printf_P(PSTR("Orientation: %s\r\n"),
				flipped ? "A1/C8" : "A0/C0");
				break;

				case 't':
				case 'T':
				sram_test();
				oled_clear();
				oled_flush();
				last_paddle_x = 255;
				break;

				case 'c':
				case 'C':
				joystick_calibrate();
				joystick_print_calibration();
				break;

				case 'p':
				case 'P':
				paddle_running = !paddle_running;
				last_paddle_x = 255;
				printf_P(PSTR("Paddle %s\r\n"), paddle_running ? "on" : "off");
				break;

				default:
				printf_P(PSTR("Unknown: '%c'\r\n"), c);
				break;
			}
		}

		if (paddle_running)
		{
			joystick_position_t pos = joystick_get_position();
			uint8_t paddle_x = paddle_x_from_joystick(pos.x);

			if (paddle_x != last_paddle_x)
			{
				draw_frame(paddle_x);
				last_paddle_x = paddle_x;
			}
		}

		PORTE ^= (1 << PE2);
		_delay_ms(20);
	}
}