#ifndef F_CPU
#define F_CPU 4915200UL
#endif

#include "joystick.h"
#include "adc.h"
#include <util/delay.h>
#include <stdio.h>

// Below this magnitude the stick counts as centred.
#define JOY_DEADZONE  18

// Centre is measured at startup; the extremes are the known constants
// from joystick.h.
static uint8_t center_x = (JOY_ADC_MIN + JOY_ADC_MAX) / 2;
static uint8_t center_y = (JOY_ADC_MIN + JOY_ADC_MAX) / 2;

// ---------------------------------------------------------------------
// All reads go through adc_read_all(). With MODE tied to a fixed level
// the MAX156 forces D7/ALL = 0, so a single conversion start is followed
// by consecutive RD pulses returning AIN0..AIN3 in order -- the channel
// is NOT selected by the byte written. Issuing a separate conversion per
// axis returns the same channel twice, which makes one axis appear dead.
// ---------------------------------------------------------------------

void joystick_calibrate(void)
{
	uint16_t sum_x = 0;
	uint16_t sum_y = 0;
	uint8_t ch[4];

	// 16 samples at ~2 ms each -- enough to average out jitter,
	// fast enough not to feel like a wait.
	for (uint8_t i = 0; i < 16; i++)
	{
		adc_read_all(ch);
		sum_x += ch[ADC_CH_JOY_X];
		sum_y += ch[ADC_CH_JOY_Y];
		_delay_ms(2);
	}

	center_x = sum_x / 16;
	center_y = sum_y / 16;
}

// Maps a raw reading to -90..+90. Each half is scaled separately, so a
// resting position that isn't midway between the extremes still gives
// symmetric full-scale output in both directions.
static int16_t scale_axis(uint8_t value, uint8_t center)
{
	int16_t result;

	if (value > JOY_ADC_MAX) value = JOY_ADC_MAX;
	if (value < JOY_ADC_MIN) value = JOY_ADC_MIN;

	if (value >= center)
	{
		uint8_t span = JOY_ADC_MAX - center;
		if (span == 0) return 0;
		result = ((int16_t)(value - center) * JOY_OUT_MAX) / span;
	}
	else
	{
		uint8_t span = center - JOY_ADC_MIN;
		if (span == 0) return 0;
		result = -(((int16_t)(center - value) * JOY_OUT_MAX) / span);
	}

	if (result >  JOY_OUT_MAX) result =  JOY_OUT_MAX;
	if (result < -JOY_OUT_MAX) result = -JOY_OUT_MAX;

	return result;
}

joystick_position_t joystick_get_position(void)
{
	joystick_position_t pos;
	uint8_t ch[4];

	adc_read_all(ch);

	pos.x = scale_axis(ch[ADC_CH_JOY_X], center_x);
	pos.y = scale_axis(ch[ADC_CH_JOY_Y], center_y);

	return pos;
}

joystick_direction_t joystick_get_direction(void)
{
	joystick_position_t pos = joystick_get_position();

	int16_t abs_x = (pos.x < 0) ? -pos.x : pos.x;
	int16_t abs_y = (pos.y < 0) ? -pos.y : pos.y;

	if (abs_x < JOY_DEADZONE && abs_y < JOY_DEADZONE)
	return JOY_NEUTRAL;

	// Larger deflection wins, so a diagonal push resolves to one
	// direction instead of flickering between two.
	if (abs_x > abs_y)
	return (pos.x > 0) ? JOY_RIGHT : JOY_LEFT;
	else
	return (pos.y > 0) ? JOY_UP : JOY_DOWN;
}

void joystick_get_raw(uint8_t *x, uint8_t *y)
{
	uint8_t ch[4];

	adc_read_all(ch);
	*x = ch[ADC_CH_JOY_X];
	*y = ch[ADC_CH_JOY_Y];
}

void joystick_print_calibration(void)
{
	printf("Centre: X=%3u Y=%3u   Range: %u..%u\r\n",
	center_x, center_y, JOY_ADC_MIN, JOY_ADC_MAX);
}