#ifndef JOYSTICK_H
#define JOYSTICK_H

#include <stdint.h>

// Measured converter limits for this joystick -- the potentiometers
// never reach either rail, so the usable span is 66..248.
#define JOY_ADC_MIN     66
#define JOY_ADC_MAX     248

// Output range of joystick_get_position(), per axis.
#define JOY_OUT_MAX     90

typedef struct {
	int16_t x;
	int16_t y;
} joystick_position_t;

typedef enum {
	JOY_NEUTRAL,
	JOY_LEFT,
	JOY_RIGHT,
	JOY_UP,
	JOY_DOWN
} joystick_direction_t;

// Samples the resting position and stores it as centre. Takes ~50 ms.
// Leave the stick untouched while it runs. Call once after adc_init().
void joystick_calibrate(void);

// Position scaled to -90..+90 per axis, 0 = centre.
joystick_position_t joystick_get_position(void);

joystick_direction_t joystick_get_direction(void);
void joystick_get_raw(uint8_t *x, uint8_t *y);
void joystick_print_calibration(void);

#endif // JOYSTICK_H