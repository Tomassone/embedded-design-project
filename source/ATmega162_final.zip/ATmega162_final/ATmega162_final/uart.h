#ifndef UART_H
#define UART_H

#include <stdio.h>
#include <stdint.h>

extern FILE uart_stream;

void uart_init(void);
uint8_t uart_available(void);
int uart_putchar(char c, FILE *stream);
int uart_getchar(FILE *stream);

#endif // UART_H
