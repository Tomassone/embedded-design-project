#ifndef IOBOARD_H
#define IOBOARD_H

#include <stdint.h>

#define IOB_CMD_TOUCHPAD   0x01
#define IOB_CMD_SLIDER     0x02
#define IOB_CMD_JOYSTICK   0x03
#define IOB_CMD_BUTTONS    0x04
#define IOB_CMD_LED        0x05
#define IOB_CMD_LED_PWM    0x06
#define IOB_CMD_INFO       0x07

#define IOB_INFO_LENGTH    35
#define IOB_LED_COUNT      6

typedef struct { uint8_t x; uint8_t y; uint8_t size; } ioboard_touchpad_t;
typedef struct { uint8_t x; uint8_t size; } ioboard_slider_t;
typedef struct { uint8_t x; uint8_t y; uint8_t btn; } ioboard_joystick_t;

typedef struct __attribute__((packed)) {
    union {
        uint8_t right;
        struct {
            uint8_t R1:1; uint8_t R2:1; uint8_t R3:1;
            uint8_t R4:1; uint8_t R5:1; uint8_t R6:1;
        };
    };
    union {
        uint8_t left;
        struct {
            uint8_t L1:1; uint8_t L2:1; uint8_t L3:1; uint8_t L4:1;
            uint8_t L5:1; uint8_t L6:1; uint8_t L7:1;
        };
    };
    union {
        uint8_t nav;
        struct {
            uint8_t NB:1; uint8_t NR:1; uint8_t ND:1;
            uint8_t NL:1; uint8_t NU:1;
        };
    };
} ioboard_buttons_t;

ioboard_touchpad_t ioboard_read_touchpad(void);
ioboard_slider_t   ioboard_read_slider(void);
ioboard_joystick_t ioboard_read_joystick(void);
ioboard_buttons_t  ioboard_read_buttons(void);
void ioboard_set_led(uint8_t led, uint8_t on);
void ioboard_set_led_pwm(uint8_t led, uint8_t width);
void ioboard_read_info(uint8_t *buffer);

#endif // IOBOARD_H
