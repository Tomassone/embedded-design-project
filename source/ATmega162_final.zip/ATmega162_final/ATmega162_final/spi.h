#ifndef SPI_H
#define SPI_H

#include <stdint.h>

typedef enum {
    SPI_SLAVE_NONE,
    SPI_SLAVE_DISPLAY,
    SPI_SLAVE_IOBOARD,
    SPI_SLAVE_CAN
} spi_slave_t;

void spi_init(void);
void spi_select(spi_slave_t slave);
void spi_deselect(void);
uint8_t spi_transfer(uint8_t data);
void spi_write(uint8_t data);
uint8_t spi_read(void);
void spi_write_bytes(const uint8_t *data, uint16_t length);
void spi_read_bytes(uint8_t *buffer, uint16_t length);

#endif // SPI_H
