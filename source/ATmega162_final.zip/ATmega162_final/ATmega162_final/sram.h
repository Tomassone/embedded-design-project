#ifndef SRAM_H
#define SRAM_H

#include <stdint.h>

#define SRAM_BASE_ADDR   0x1800
#define SRAM_SIZE        0x800

void xmem_init(void);
uint16_t sram_test(void);

#endif // SRAM_H
