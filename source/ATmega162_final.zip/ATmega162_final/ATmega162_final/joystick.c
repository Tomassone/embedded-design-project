#ifndef F_CPU
#define F_CPU 4915200UL
#endif

#include "joystick.h"
#include "adc.h"
#include <avr/pgmspace.h>
#include <util/delay.h>
#include <stdio.h>

#define JOY_DEADZONE  18
#define FIXED_SCALE   4

static uint8_t center_x = (JOY_ADC_MIN + JOY_ADC_MAX) / 2;
static uint8_t center_y = (JOY_ADC_MIN + JOY_ADC_MAX) / 2;

static int16_t filtered_x;
static int16_t filtered_y;
static int16_t output_x;
static int16_t output_y;

static void read_averaged(uint8_t *x, uint8_t *y)
{
    uint8_t ch[4];
    uint16_t sum_x = 0;
    uint16_t sum_y = 0;

    for (uint8_t i = 0; i < 4; i++)
    {
        adc_read_all(ch);
        sum_x += ch[ADC_CH_JOY_X];
        sum_y += ch[ADC_CH_JOY_Y];
    }

    *x = sum_x / 4;
    *y = sum_y / 4;
}

void joystick_calibrate(void)
{
    uint16_t sum_x = 0;
    uint16_t sum_y = 0;
    uint8_t ch[4];

    for (uint8_t i = 0; i < 16; i++)
    {
        adc_read_all(ch);
        sum_x += ch[ADC_CH_JOY_X];
        sum_y += ch[ADC_CH_JOY_Y];
        _delay_ms(2);
    }

    center_x = sum_x / 16;
    center_y = sum_y / 16;

    filtered_x = (int16_t)center_x << FIXED_SCALE;
    filtered_y = (int16_t)center_y << FIXED_SCALE;
    output_x = 0;
    output_y = 0;
}

static int16_t lowpass(int16_t filtered, uint8_t sample)
{
    int16_t target = (int16_t)sample << FIXED_SCALE;
    return filtered + (target - filtered) / (1 << JOY_FILTER_SHIFT);
}

static int16_t scale_axis(uint8_t value, uint8_t center)
{
    int16_t result;

    if (value > JOY_ADC_MAX) value = JOY_ADC_MAX;
    if (value < JOY_ADC_MIN) value = JOY_ADC_MIN;

    if (value >= center)
    {
        uint8_t span = JOY_ADC_MAX - center;
        if (span == 0) return 0;
        result = ((int16_t)(value - center) * JOY_OUT_MAX) / span;
    }
    else
    {
        uint8_t span = center - JOY_ADC_MIN;
        if (span == 0) return 0;
        result = -(((int16_t)(center - value) * JOY_OUT_MAX) / span);
    }

    if (result >  JOY_OUT_MAX) result =  JOY_OUT_MAX;
    if (result < -JOY_OUT_MAX) result = -JOY_OUT_MAX;

    return result;
}

static int16_t stabilise(int16_t candidate, int16_t last)
{
    if (candidate > -JOY_CENTER_SNAP && candidate < JOY_CENTER_SNAP)
        candidate = 0;

    int16_t delta = candidate - last;
    if (delta < 0) delta = -delta;

    if (delta >= JOY_HYSTERESIS ||
        candidate == 0 ||
        candidate == JOY_OUT_MAX || candidate == -JOY_OUT_MAX)
    {
        return candidate;
    }

    return last;
}

joystick_position_t joystick_get_position(void)
{
    uint8_t raw_x, raw_y;
    joystick_position_t pos;

    read_averaged(&raw_x, &raw_y);

    filtered_x = lowpass(filtered_x, raw_x);
    filtered_y = lowpass(filtered_y, raw_y);

    uint8_t smooth_x = (filtered_x + (1 << (FIXED_SCALE - 1))) >> FIXED_SCALE;
    uint8_t smooth_y = (filtered_y + (1 << (FIXED_SCALE - 1))) >> FIXED_SCALE;

    output_x = stabilise(scale_axis(smooth_x, center_x), output_x);
    output_y = stabilise(scale_axis(smooth_y, center_y), output_y);

    pos.x = output_x;
    pos.y = output_y;
    return pos;
}

joystick_direction_t joystick_get_direction(void)
{
    joystick_position_t pos = joystick_get_position();

    int16_t abs_x = (pos.x < 0) ? -pos.x : pos.x;
    int16_t abs_y = (pos.y < 0) ? -pos.y : pos.y;

    if (abs_x < JOY_DEADZONE && abs_y < JOY_DEADZONE)
        return JOY_NEUTRAL;

    if (abs_x > abs_y)
        return (pos.x > 0) ? JOY_RIGHT : JOY_LEFT;
    else
        return (pos.y > 0) ? JOY_UP : JOY_DOWN;
}

void joystick_get_raw(uint8_t *x, uint8_t *y)
{
    uint8_t ch[4];

    adc_read_all(ch);
    *x = ch[ADC_CH_JOY_X];
    *y = ch[ADC_CH_JOY_Y];
}

void joystick_print_calibration(void)
{
    printf_P(PSTR("Centre: X=%3u Y=%3u   Range: %u..%u\r\n"),
             center_x, center_y, JOY_ADC_MIN, JOY_ADC_MAX);
}
