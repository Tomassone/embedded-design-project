#include "livegame.h"
#include "protocol.h"
#include "joystick.h"
#include "oled.h"
#include "oled_text.h"
#include "menu.h"
#include <avr/pgmspace.h>

// Node 2 clears its score on STOP, so live_start() sends STOP first and
// waits before sending START. Without the gap a score left over from an
// abnormally ended round could end the new one immediately.
#define LIVE_ARM_MS      200

// Frames a GOAL banner stays on screen, at 50 ms per frame.
#define GOAL_FLASH       16

// Position bars: label on the left, bar from x = 36 to the right edge.
#define BAR_X0           36
#define BAR_W            (OLED_WIDTH - BAR_X0 - 2)
#define BAR_MARKER       4

static live_status_t status;
static uint16_t phase_start;     // start of arming, then of play
static uint16_t last_tick;
static uint16_t acc_ms;          // sub-second remainder
static uint16_t seconds;
static uint8_t goals;
static uint8_t goal_flash;

void live_start(uint16_t now)
{
    status = LIVE_ARMING;
    phase_start = now;
    last_tick = now;
    acc_ms = 0;
    seconds = 0;
    goals = 0;
    goal_flash = 0;

    protocol_reset_state();
    protocol_send_command(GAME_CMD_STOP);
}

live_status_t live_update(uint16_t now)
{
    if (status == LIVE_ARMING)
    {
        if ((uint16_t)(now - phase_start) >= LIVE_ARM_MS)
        {
            protocol_send_command(GAME_CMD_START);
            status = LIVE_RUNNING;
            phase_start = now;
            last_tick = now;
        }
        return status;
    }

    if (status != LIVE_RUNNING)
        return status;

    // Playing time, accumulated from frame deltas. timer_millis() wraps
    // after about 65 s, so the elapsed time cannot be a subtraction
    // from a single start stamp.
    acc_ms += (uint16_t)(now - last_tick);
    last_tick = now;

    while (acc_ms >= 1000)
    {
        acc_ms -= 1000;
        seconds++;
    }

    // Node 2 counts the goals: its IR beam sees the ball, not node 1.
    uint8_t reported = protocol_node2()->score;

    if (reported > goals)
    {
        goals = reported;
        goal_flash = GOAL_FLASH;
    }

    if (goal_flash > 0)
        goal_flash--;

    if (goals >= LIVE_MAX_GOALS)
        status = LIVE_OVER;

    return status;
}

void live_resume(uint16_t now)
{
    last_tick = now;
    protocol_send_command(GAME_CMD_START);
}

// Draws a centred position bar with a marker at value (-90..+90).
static void draw_bar(uint8_t y, int16_t value)
{
    oled_draw_hline(BAR_X0, y, BAR_W, 1);
    oled_draw_hline(BAR_X0, y + 5, BAR_W, 1);
    oled_draw_vline(BAR_X0, y, 6, 1);
    oled_draw_vline(BAR_X0 + BAR_W - 1, y, 6, 1);
    oled_draw_vline(BAR_X0 + BAR_W / 2, y + 1, 4, 1);   // centre tick

    int16_t travel = BAR_W - 2 - BAR_MARKER;
    int16_t pos = ((value + JOY_OUT_MAX) * travel) / (2 * JOY_OUT_MAX);

    if (pos < 0) pos = 0;
    if (pos > travel) pos = travel;

    oled_fill_rect(BAR_X0 + 1 + (uint8_t)pos, y + 1, BAR_MARKER, 4, 1);
}

void live_draw(int16_t joy_x, int16_t joy_y, uint8_t fire_level,
               uint8_t link_ok)
{
    static const char title[] PROGMEM = "LIVE PLAY";

    const node2_state_t *n2 = protocol_node2();

    oled_clear();
    menu_draw_title(title);

    if (status == LIVE_ARMING)
    {
        oled_goto(3, 4);
        oled_print_P(PSTR("Starting round..."));
        oled_flush();
        return;
    }

    // 21 text columns: "Goals 0/3   1234 s" is 18, which leaves room
    // for a four-digit time. The obvious "Time %3us" wording did not
    // fit and would have been clipped.
    oled_goto(1, 0);
    oled_printf_P(PSTR("Goals %u/%u   %4u s"),
                  goals, LIVE_MAX_GOALS, seconds);

    // Node 2's own view of itself, plus whether anything is arriving.
    oled_goto(2, 0);
    oled_printf_P(PSTR("N2 %S  link %S"),
                  (n2->status == NODE2_RUNNING) ? PSTR("RUN ") :
                  (n2->status == NODE2_ERROR)   ? PSTR("ERR ") : PSTR("IDLE"),
                  link_ok ? PSTR("ok") : PSTR("--"));

    oled_goto(3, 0);
    oled_print_P(PSTR("Cart"));
    draw_bar(25, joy_x);

    oled_goto(4, 0);
    oled_print_P(PSTR("Serv"));
    draw_bar(33, joy_y);

    // One line serves three purposes, which keeps the screen readable:
    // a goal banner takes priority, then the solenoid state.
    oled_goto(6, 0);

    if (goal_flash > 0)
    {
        oled_set_inverted(1);
        oled_print_P(PSTR("      GOAL!      "));
        oled_set_inverted(0);
    }
    else if (fire_level)
    {
        oled_set_inverted(1);
        oled_print_P(PSTR(" FIRE "));
        oled_set_inverted(0);
    }
    else
    {
        oled_print_P(PSTR("NAV_B = fire"));
    }

    oled_goto(7, 0);
    oled_print_P(PSTR("SR6: pause"));

    oled_flush();
}

uint16_t live_get_seconds(void)
{
    return seconds;
}

uint8_t live_get_goals(void)
{
    return goals;
}
