#include "uart.h"
#include <avr/io.h>
#include <avr/interrupt.h>

#ifndef F_CPU
#define F_CPU 4915200UL
#endif

#ifndef BAUD
#define BAUD 9600UL
#endif

#define UBRR_VALUE ((F_CPU / (16UL * BAUD)) - 1)

#define RX_BUF_SIZE 32
#define TX_BUF_SIZE 64

static volatile uint8_t rx_buf[RX_BUF_SIZE];
static volatile uint8_t rx_head = 0;
static volatile uint8_t rx_tail = 0;

static volatile uint8_t tx_buf[TX_BUF_SIZE];
static volatile uint8_t tx_head = 0;
static volatile uint8_t tx_tail = 0;

FILE uart_stream;

void uart_init(void)
{
    UBRR0H = (uint8_t)(UBRR_VALUE >> 8);
    UBRR0L = (uint8_t)UBRR_VALUE;

    UCSR0C = (1 << URSEL0) | (1 << UCSZ01) | (1 << UCSZ00);
    UCSR0B = (1 << RXEN0) | (1 << TXEN0) | (1 << RXCIE0);

    fdev_setup_stream(&uart_stream, uart_putchar, uart_getchar, _FDEV_SETUP_RW);
    stdout = &uart_stream;
    stdin  = &uart_stream;
}

ISR(USART0_RXC_vect)
{
    uint8_t data = UDR0;
    uint8_t next_head = (rx_head + 1) % RX_BUF_SIZE;

    if (next_head != rx_tail)
    {
        rx_buf[rx_head] = data;
        rx_head = next_head;
    }
}

ISR(USART0_UDRE_vect)
{
    if (tx_tail != tx_head)
    {
        UDR0 = tx_buf[tx_tail];
        tx_tail = (tx_tail + 1) % TX_BUF_SIZE;
    }
    else
    {
        UCSR0B &= ~(1 << UDRIE0);
    }
}

int uart_putchar(char c, FILE *stream)
{
    if (c == '\n')
        uart_putchar('\r', stream);

    uint8_t next_head = (tx_head + 1) % TX_BUF_SIZE;

    while (next_head == tx_tail)
        ;

    tx_buf[tx_head] = c;
    tx_head = next_head;

    UCSR0B |= (1 << UDRIE0);

    return 0;
}

int uart_getchar(FILE *stream)
{
    while (rx_tail == rx_head)
        ;

    uint8_t data = rx_buf[rx_tail];
    rx_tail = (rx_tail + 1) % RX_BUF_SIZE;
    return data;
}

uint8_t uart_available(void)
{
    return (rx_head != rx_tail);
}
