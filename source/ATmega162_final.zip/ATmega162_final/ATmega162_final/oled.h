#ifndef OLED_H
#define OLED_H

#include <stdint.h>

#define OLED_WIDTH    128
#define OLED_HEIGHT   64
#define OLED_PAGES    (OLED_HEIGHT / 8)
#define OLED_BUF_SIZE (OLED_WIDTH * OLED_PAGES)

#define OLED_BUFFER_ADDR 0x1800

void oled_init(void);
void oled_reset(void);

void oled_clear(void);
void oled_set_pixel(uint8_t x, uint8_t y, uint8_t on);
void oled_fill_rect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t on);
void oled_draw_hline(uint8_t x, uint8_t y, uint8_t length, uint8_t on);
void oled_draw_vline(uint8_t x, uint8_t y, uint8_t length, uint8_t on);

void oled_flush(void);

void oled_write_command(uint8_t cmd);
void oled_write_data(uint8_t data);

#endif // OLED_H
