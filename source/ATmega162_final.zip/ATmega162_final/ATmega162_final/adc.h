#ifndef ADC_H
#define ADC_H

#include <stdint.h>

#define ADC_BASE_ADDR   0x1000
#define ADC_CH_JOY_Y    0
#define ADC_CH_JOY_X    1

void adc_init(void);
uint8_t adc_read_channel(uint8_t channel);
void adc_read_all(uint8_t *results);

#endif // ADC_H
