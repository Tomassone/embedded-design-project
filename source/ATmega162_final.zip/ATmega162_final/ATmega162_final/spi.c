#include "spi.h"
#include <avr/io.h>

#define SPI_DDR      DDRB
#define SPI_PORT     PORTB
#define PIN_SS_HW    PB4
#define PIN_MOSI     PB5
#define PIN_MISO     PB6
#define PIN_SCK      PB7

#define CS_DISP_PORT PORTB
#define CS_DISP_DDR  DDRB
#define PIN_CS_DISP  PB2

#define CS_IO_PORT   PORTB
#define CS_IO_DDR    DDRB
#define PIN_CS_IO    PB3

#define CS_CAN_PORT  PORTD
#define CS_CAN_DDR   DDRD
#define PIN_CS_CAN   PD3

void spi_init(void)
{
    SPI_DDR |=  (1 << PIN_MOSI) | (1 << PIN_SCK) | (1 << PIN_SS_HW);
    SPI_DDR &= ~(1 << PIN_MISO);
    SPI_PORT |= (1 << PIN_SS_HW);

    CS_DISP_DDR  |= (1 << PIN_CS_DISP);
    CS_IO_DDR    |= (1 << PIN_CS_IO);
    CS_CAN_DDR   |= (1 << PIN_CS_CAN);
    spi_deselect();

    SPCR = (1 << SPE) | (1 << MSTR) | (1 << SPR0);
    SPSR = 0;
}

void spi_deselect(void)
{
    CS_DISP_PORT |= (1 << PIN_CS_DISP);
    CS_IO_PORT   |= (1 << PIN_CS_IO);
    CS_CAN_PORT  |= (1 << PIN_CS_CAN);
}

void spi_select(spi_slave_t slave)
{
    spi_deselect();

    switch (slave)
    {
        case SPI_SLAVE_DISPLAY:
            CS_DISP_PORT &= ~(1 << PIN_CS_DISP);
            break;
        case SPI_SLAVE_IOBOARD:
            CS_IO_PORT &= ~(1 << PIN_CS_IO);
            break;
        case SPI_SLAVE_CAN:
            CS_CAN_PORT &= ~(1 << PIN_CS_CAN);
            break;
        default:
            break;
    }
}

uint8_t spi_transfer(uint8_t data)
{
    SPDR = data;

    while (!(SPSR & (1 << SPIF)))
        ;

    return SPDR;
}

void spi_write(uint8_t data)
{
    spi_transfer(data);
}

uint8_t spi_read(void)
{
    return spi_transfer(0xFF);
}

void spi_write_bytes(const uint8_t *data, uint16_t length)
{
    for (uint16_t i = 0; i < length; i++)
        spi_transfer(data[i]);
}

void spi_read_bytes(uint8_t *buffer, uint16_t length)
{
    for (uint16_t i = 0; i < length; i++)
        buffer[i] = spi_transfer(0xFF);
}
