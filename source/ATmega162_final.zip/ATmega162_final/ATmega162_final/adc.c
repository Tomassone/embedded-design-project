#ifndef F_CPU
#define F_CPU 4915200UL
#endif

#include "adc.h"
#include <avr/io.h>
#include <util/delay.h>

static volatile uint8_t *adc = (uint8_t *)ADC_BASE_ADDR;

void adc_init(void)
{
    DDRD |= (1 << PD5);
    OCR1A = 1;
    TCCR1A = (1 << COM1A0);
    TCCR1B = (1 << WGM12) | (1 << CS10);
}

uint8_t adc_read_channel(uint8_t channel)
{
    *adc = channel;
    _delay_us(10);
    return *adc;
}

void adc_read_all(uint8_t *results)
{
    *adc = 0x00;
    _delay_us(20);

    for (uint8_t i = 0; i < 4; i++)
    {
        results[i] = *adc;
    }
}
