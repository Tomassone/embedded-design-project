#ifndef F_CPU
#define F_CPU 4915200UL
#endif

#include "oled.h"
#include "spi.h"
#include <avr/io.h>
#include <util/delay.h>

#define DISP_CTRL_PORT  PORTB
#define DISP_CTRL_DDR   DDRB
#define PIN_DISP_DC     PB1
#define PIN_DISP_RES    PB0

static volatile uint8_t *framebuffer = (uint8_t *)OLED_BUFFER_ADDR;

void oled_write_command(uint8_t cmd)
{
    DISP_CTRL_PORT &= ~(1 << PIN_DISP_DC);
    spi_select(SPI_SLAVE_DISPLAY);
    spi_write(cmd);
    spi_deselect();
}

void oled_write_data(uint8_t data)
{
    DISP_CTRL_PORT |= (1 << PIN_DISP_DC);
    spi_select(SPI_SLAVE_DISPLAY);
    spi_write(data);
    spi_deselect();
}

void oled_reset(void)
{
    DISP_CTRL_PORT &= ~(1 << PIN_DISP_RES);
    _delay_ms(10);
    DISP_CTRL_PORT |= (1 << PIN_DISP_RES);
    _delay_ms(100);
}

void oled_init(void)
{
    DISP_CTRL_DDR |= (1 << PIN_DISP_DC) | (1 << PIN_DISP_RES);
    DISP_CTRL_PORT |= (1 << PIN_DISP_RES);

    oled_reset();

    oled_write_command(0xAE);
    oled_write_command(0x20);
    oled_write_command(0x00);
    oled_write_command(0x21);
    oled_write_command(0x00);
    oled_write_command(0x7F);
    oled_write_command(0x22);
    oled_write_command(0x00);
    oled_write_command(0x07);
    oled_write_command(0xA8);
    oled_write_command(0x3F);
    oled_write_command(0xD3);
    oled_write_command(0x00);
    oled_write_command(0x40);
    oled_write_command(0xA1);
    oled_write_command(0xC8);
    oled_write_command(0xDA);
    oled_write_command(0x12);
    oled_write_command(0x81);
    oled_write_command(0x7F);
    oled_write_command(0xD5);
    oled_write_command(0x70);
    oled_write_command(0xD9);
    oled_write_command(0x22);
    oled_write_command(0xDB);
    oled_write_command(0x34);

    oled_clear();
    oled_flush();

    oled_write_command(0xAF);
    _delay_ms(100);

    oled_write_command(0xA4);
    oled_write_command(0xA6);
}

void oled_clear(void)
{
    for (uint16_t i = 0; i < OLED_BUF_SIZE; i++)
        framebuffer[i] = 0x00;
}

void oled_set_pixel(uint8_t x, uint8_t y, uint8_t on)
{
    if (x >= OLED_WIDTH || y >= OLED_HEIGHT)
        return;

    uint16_t index = ((uint16_t)(y / 8) * OLED_WIDTH) + x;
    uint8_t mask = (1 << (y % 8));

    if (on)
        framebuffer[index] |= mask;
    else
        framebuffer[index] &= ~mask;
}

void oled_fill_rect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t on)
{
    for (uint8_t dy = 0; dy < h; dy++)
        for (uint8_t dx = 0; dx < w; dx++)
            oled_set_pixel(x + dx, y + dy, on);
}

void oled_draw_hline(uint8_t x, uint8_t y, uint8_t length, uint8_t on)
{
    for (uint8_t i = 0; i < length; i++)
        oled_set_pixel(x + i, y, on);
}

void oled_draw_vline(uint8_t x, uint8_t y, uint8_t length, uint8_t on)
{
    for (uint8_t i = 0; i < length; i++)
        oled_set_pixel(x, y + i, on);
}

void oled_flush(void)
{
    DISP_CTRL_PORT |= (1 << PIN_DISP_DC);
    spi_select(SPI_SLAVE_DISPLAY);

    for (uint16_t i = 0; i < OLED_BUF_SIZE; i++)
        spi_write(framebuffer[i]);

    spi_deselect();
}
