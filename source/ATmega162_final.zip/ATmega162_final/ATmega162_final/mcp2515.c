#ifndef F_CPU
#define F_CPU 4915200UL
#endif

#include "mcp2515.h"
#include "spi.h"
#include <util/delay.h>

// Every instruction is one chip-select window: select, clock the
// instruction and its operands, deselect. The deselect matters -- the
// MCP2515 only ends an instruction on the rising edge of CS.

void mcp2515_reset(void)
{
    spi_select(SPI_SLAVE_CAN);
    spi_transfer(MCP_RESET);
    spi_deselect();

    // The controller restarts its oscillator after reset and ignores
    // SPI until it is stable. A few ms is ample.
    _delay_ms(5);
}

uint8_t mcp2515_read(uint8_t address)
{
    spi_select(SPI_SLAVE_CAN);
    spi_transfer(MCP_READ);
    spi_transfer(address);
    uint8_t value = spi_read();
    spi_deselect();

    return value;
}

// The address pointer auto-increments while CS stays low, so a whole
// buffer comes out in one transaction.
void mcp2515_read_block(uint8_t address, uint8_t *buffer, uint8_t length)
{
    spi_select(SPI_SLAVE_CAN);
    spi_transfer(MCP_READ);
    spi_transfer(address);
    spi_read_bytes(buffer, length);
    spi_deselect();
}

void mcp2515_write(uint8_t address, uint8_t data)
{
    spi_select(SPI_SLAVE_CAN);
    spi_transfer(MCP_WRITE);
    spi_transfer(address);
    spi_transfer(data);
    spi_deselect();
}

void mcp2515_write_block(uint8_t address, const uint8_t *data, uint8_t length)
{
    spi_select(SPI_SLAVE_CAN);
    spi_transfer(MCP_WRITE);
    spi_transfer(address);
    spi_write_bytes(data, length);
    spi_deselect();
}

void mcp2515_request_to_send(uint8_t rts_instruction)
{
    spi_select(SPI_SLAVE_CAN);
    spi_transfer(rts_instruction);
    spi_deselect();
}

uint8_t mcp2515_read_status(void)
{
    spi_select(SPI_SLAVE_CAN);
    spi_transfer(MCP_READ_STATUS);
    uint8_t status = spi_read();
    spi_deselect();

    return status;
}

void mcp2515_bit_modify(uint8_t address, uint8_t mask, uint8_t data)
{
    spi_select(SPI_SLAVE_CAN);
    spi_transfer(MCP_BIT_MODIFY);
    spi_transfer(address);
    spi_transfer(mask);
    spi_transfer(data);
    spi_deselect();
}

uint8_t mcp2515_set_mode(uint8_t mode)
{
    mcp2515_bit_modify(MCP_CANCTRL, MCP_MODE_MASK, mode);

    // The mode change is not instant: the controller finishes any
    // ongoing bus activity first. Poll CANSTAT until it confirms.
    for (uint8_t i = 0; i < 100; i++)
    {
        if ((mcp2515_read(MCP_CANSTAT) & MCP_MODE_MASK) == mode)
            return 0;

        _delay_us(100);
    }

    return 1;
}

uint8_t mcp2515_init(void)
{
    mcp2515_reset();

    // After reset the controller must be in configuration mode. If
    // CANSTAT says anything else, it is not answering -- a floating
    // MISO line typically reads 0xFF, a dead one 0x00.
    uint8_t canstat = mcp2515_read(MCP_CANSTAT);

    if ((canstat & MCP_MODE_MASK) != MCP_MODE_CONFIG)
        return 1;

    return 0;
}
