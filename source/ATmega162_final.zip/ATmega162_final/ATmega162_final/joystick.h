#ifndef JOYSTICK_H
#define JOYSTICK_H

#include <stdint.h>

#define JOY_ADC_MIN     66
#define JOY_ADC_MAX     248
#define JOY_OUT_MAX     90

#define JOY_FILTER_SHIFT   2
#define JOY_HYSTERESIS     3
#define JOY_CENTER_SNAP    4

typedef struct {
    int16_t x;
    int16_t y;
} joystick_position_t;

typedef enum {
    JOY_NEUTRAL,
    JOY_LEFT,
    JOY_RIGHT,
    JOY_UP,
    JOY_DOWN
} joystick_direction_t;

void joystick_calibrate(void);
joystick_position_t joystick_get_position(void);
joystick_direction_t joystick_get_direction(void);
void joystick_get_raw(uint8_t *x, uint8_t *y);
void joystick_print_calibration(void);

#endif // JOYSTICK_H
