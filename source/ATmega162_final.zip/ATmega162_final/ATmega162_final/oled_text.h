#ifndef OLED_TEXT_H
#define OLED_TEXT_H

#include <stdint.h>

#define FONT_WIDTH         5
#define FONT_HEIGHT        7
#define FONT_FIRST         0x20
#define FONT_LAST          0x7E

#define OLED_CHAR_WIDTH    6
#define OLED_CHAR_HEIGHT   8

#define OLED_TEXT_COLUMNS  21
#define OLED_TEXT_LINES    8

void oled_draw_char(uint8_t x, uint8_t y, char c);
void oled_draw_string(uint8_t x, uint8_t y, const char *str);
void oled_draw_string_P(uint8_t x, uint8_t y, const char *str_P);

void oled_home(void);
void oled_goto(uint8_t line, uint8_t column);
void oled_goto_line(uint8_t line);
void oled_goto_column(uint8_t column);
void oled_clear_line(uint8_t line);

void oled_putchar(char c);
void oled_print(const char *str);
void oled_print_P(const char *str_P);

void oled_printf_P(const char *fmt_P, ...);

void oled_set_inverted(uint8_t on);

#endif // OLED_TEXT_H
