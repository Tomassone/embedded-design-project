#include "sram.h"
#include <avr/io.h>
#include <stdlib.h>
#include <stdio.h>

void xmem_init(void)
{
    MCUCR |= (1 << SRE);
    SFIOR  = (1 << XMM2);
}

uint16_t sram_test(void)
{
    volatile uint8_t *ext_ram = (uint8_t *)SRAM_BASE_ADDR;
    uint16_t write_errors = 0;
    uint16_t retrieval_errors = 0;

    printf("Starting SRAM test...\r\n");

    uint16_t seed = rand();

    srand(seed);
    for (uint16_t i = 0; i < SRAM_SIZE; i++)
    {
        uint8_t some_value = rand();
        ext_ram[i] = some_value;
        uint8_t retrieved_value = ext_ram[i];

        if (retrieved_value != some_value)
        {
            printf("Write phase error: ext_ram[%4d] = %02X (should be %02X)\r\n",
                   i, retrieved_value, some_value);
            write_errors++;
        }
    }

    srand(seed);
    for (uint16_t i = 0; i < SRAM_SIZE; i++)
    {
        uint8_t some_value = rand();
        uint8_t retrieved_value = ext_ram[i];

        if (retrieved_value != some_value)
        {
            printf("Retrieval phase error: ext_ram[%4d] = %02X (should be %02X)\r\n",
                   i, retrieved_value, some_value);
            retrieval_errors++;
        }
    }

    printf("SRAM test completed with\r\n%4d errors in write phase and\r\n%4d errors in retrieval phase\r\n\r\n",
           write_errors, retrieval_errors);

    return write_errors + retrieval_errors;
}
