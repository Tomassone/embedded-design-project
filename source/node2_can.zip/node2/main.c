#include <stdio.h>
#include "sam.h"
#include "uart.h"
#include "time.h"
#include "can.h"
#include "protocol.h"

#define F_CPU     84000000
#define BAUDRATE  9600

// ---------------------------------------------------------------------
// Loop period. Node 1 sends the joystick every 50 ms, and each receive
// mailbox holds one message, so polling has to be clearly faster than
// that. 10 ms also keeps the servo responsive.
// ---------------------------------------------------------------------
#define LOOP_MS           10

// Fail safe if node 1 goes quiet: it stops sending joystick frames as
// soon as it leaves the game, so this must not be mistaken for a fault.
#define JOYSTICK_TIMEOUT_MS   200

// Status heartbeat to node 1.
#define STATUS_PERIOD_MS  500

// ---------------------------------------------------------------------
// Servo on PB13 (Arduino D21), PWM channel 1, clock A = MCK.
//
//   CPRD = 1 680 000 = 20 ms period  (84 MHz * 0.02 s)
//   CDTY = 126 000   = 1.5 ms        centre
//          75 600    = 0.9 ms        one end
//          176 400   = 2.1 ms        other end
//
// The joystick arrives as -90..+90, so one unit is
//   (176400 - 126000) / 90 = 560 counts.
// ---------------------------------------------------------------------
#define SERVO_PERIOD      1680000u
#define SERVO_CENTRE      126000u
#define SERVO_MIN         75600u
#define SERVO_MAX         176400u
#define SERVO_PER_UNIT    560
#define JOYSTICK_RANGE    90

static node2_status_t status = NODE2_IDLE;
static uint8_t         score;


static void servo_init(void)
{
    PMC->PMC_PCER0 = (1u << ID_PIOB);           // Enable PIOB clock
    PMC->PMC_PCER1 = (1u << (ID_PWM - 32));     // Enable PWM clock

    PIOB->PIO_PDR   = PIO_PB13;                 // Release GPIO control
    PIOB->PIO_ABSR |= PIO_PB13;                 // Select peripheral B (PWMH1)

    PWM->PWM_CH_NUM[1].PWM_CMR  = 0;            // Clock A = MCK
    PWM->PWM_CH_NUM[1].PWM_CPRD = SERVO_PERIOD - 1;
    PWM->PWM_CH_NUM[1].PWM_CDTY = SERVO_CENTRE;

    PWM->PWM_ENA = (1u << 1);                   // Enable PWM channel 1
}


// Moves the servo to a joystick position. Clamped, so a corrupt or
// out-of-range frame cannot drive the servo past its mechanical limit.
static void servo_set(int8_t position)
{
    int32_t p = position;

    if (p >  JOYSTICK_RANGE) p =  JOYSTICK_RANGE;
    if (p < -JOYSTICK_RANGE) p = -JOYSTICK_RANGE;

    int32_t duty = (int32_t)SERVO_CENTRE + p * SERVO_PER_UNIT;

    if (duty < (int32_t)SERVO_MIN) duty = SERVO_MIN;
    if (duty > (int32_t)SERVO_MAX) duty = SERVO_MAX;

    // CDTYUPD, not CDTY: the channel is running, and writing CDTY
    // directly while it is enabled gives a glitched pulse.
    PWM->PWM_CH_NUM[1].PWM_CDTYUPD = (uint32_t)duty;
}


// ---------------------------------------------------------------------
// Call this when the ball gets past the paddle.
//
// TODO exercise 7: drive this from the IR beam on the ping-pong board
// instead of the UART test key below.
// ---------------------------------------------------------------------
static void report_goal(void)
{
    score++;
    protocol_send_goal(score);
    printf("GOAL -- score now %u\n\r", score);
}


static void set_status(node2_status_t s)
{
    status = s;
    protocol_send_status(status);
}


static void print_can_errors(void)
{
    CanErrors e;
    can_get_errors(&e);

    printf("CAN  TEC %u  REC %u  %s%s\n\r",
           e.tx_errors, e.rx_errors,
           e.error_passive ? "ERROR-PASSIVE " : "",
           e.bus_off ? "BUS-OFF" : (e.tx_errors || e.rx_errors ? "" : "OK"));
}


// Test keys over the serial terminal, so the whole message path can be
// checked before the ping-pong hardware exists.
static void handle_uart(void)
{
    uint8_t c;

    while (uart_rx(&c))
    {
        switch (c)
        {
            case 'g':
                report_goal();
                break;

            case 'e':
                print_can_errors();
                break;

            case 'r':
                score = 0;
                printf("Score reset\n\r");
                break;

            case 's':
            {
                const joystick_rx_t *j = protocol_joystick();
                printf("state %u  joy %s x %d y %d btn %02X  score %u\n\r",
                       status, j->valid ? "ok" : "stale",
                       j->x, j->y, j->buttons, score);
                break;
            }

            default:
                break;
        }
    }
}


int main(void)
{
    SystemInit();
    WDT->WDT_MR = WDT_MR_WDDIS;                 // Disable watchdog (lab tip 3.6.6)

    servo_init();
    uart_init(F_CPU, BAUDRATE);

    // Polling, not interrupt driven: main() is the only thing that
    // touches the game state, so nothing has to be volatile.
    can_init_default(0);

    printf("\n\r--- Node 2 ---\n\r");
    printf("CAN %lu bit/s, %u TQ/bit, BRP %u, clk %lu Hz\n\r",
           (unsigned long)CAN_BITRATE, CAN_TQ_PER_BIT,
           (unsigned)CAN_BRP, (unsigned long)CAN_CLK_HZ);
    printf("keys: g=goal  e=can errors  r=reset score  s=state\n\r");

    set_status(NODE2_IDLE);

    uint32_t since_status = 0;

    time_doPeriodic(msecs(LOOP_MS))
    {
        handle_uart();

        // Drain every pending frame. More than one can be waiting:
        // there are two receive mailboxes.
        protocol_poll();

        if (protocol_cmd_changed())
        {
            switch (protocol_game_cmd())
            {
                case GAME_CMD_START:
                    // Also sent on resume from pause, so do not reset
                    // the score here.
                    set_status(NODE2_RUNNING);
                    printf("START\n\r");
                    break;

                case GAME_CMD_PAUSE:
                    // Hold position: the paddle stays where it is.
                    set_status(NODE2_IDLE);
                    printf("PAUSE\n\r");
                    break;

                case GAME_CMD_STOP:
                    set_status(NODE2_IDLE);
                    score = 0;
                    servo_set(0);
                    printf("STOP\n\r");
                    break;
            }
        }

        // Node 1 stops sending joystick frames when it leaves the game.
        if (protocol_check_timeout(JOYSTICK_TIMEOUT_MS))
        {
            servo_set(0);
            printf("joystick timeout -- servo centred\n\r");
        }

        const joystick_rx_t *joy = protocol_joystick();

        if (status == NODE2_RUNNING && joy->valid)
            servo_set(joy->x);

        since_status += LOOP_MS;
        if (since_status >= STATUS_PERIOD_MS)
        {
            since_status = 0;
            protocol_send_status(status);
        }
    }
}
