# Node 2 — changes for CAN communication with Node 1

Everything here is Node 2 (Arduino Due / SAM3X8E). Node 1 (ATmega162)
needs no changes.

## Bugs in the starter code that prevented communication

### 1. `CanMsg.id` was `uint8_t` — `can.h`

A standard CAN identifier is 11 bits, so IDs above `0xFF` are legal, and
the protocol with node 1 uses `0x100`–`0x201`. With a `uint8_t` field
those truncate silently: `0x100` becomes `0x00`, `0x101` becomes `0x01`.

Now `uint16_t`, and `can_rx()` no longer casts the extracted ID down to
8 bits.

### 2. `CAN_MID_MIDE` was set on the transmit mailbox — `can.c`

`MIDE = 1` selects the 29-bit extended identifier of CAN 2.0B. Node 1
sends and expects 11-bit standard identifiers (`EXIDE = 0` on the
MCP2515), so the two have to agree. MIDE is now cleared on transmit.

### 3. The `CanInit` bitfields do not match `CAN_BR` — `can.h`

In the register, `PHASE1` is at bit 4 and `PROPAG` at bit 8 — see
`sam/sam3x/include/component/component_can.h` lines 187 and 191. The
struct allocates `propag` to bits 4..7 and `phase1` to bits 8..11, so
writing `.phase1 = x` lands in the PROPAG field and vice versa.

Only the sum of the segments sets the bit rate, so the starter example
still produces 125 kbit/s — but the sample point ends up at 87.5 %
instead of 62.5 %, and the sample point is exactly what has to match
between nodes.

`can_init_default()` in `protocol.c` therefore builds the register value
with the official `CAN_BR_*` macros and passes it in `.reg`. Do not use
the named bitfields.

### 4. `PMC_PCR.DIV` was left as `0/*??*/` — `can.c`

The comment in `can_init()` said DIV = 1 (MCK/2), but the bit-timing
example in `can.h` used `.brp = F_CPU/2000000-1`, which only gives 16 TQ
at 125 kbit/s if the clock is the full MCK. The two contradicted each
other.

`CAN_BRP` is now derived from `CAN_CLK_HZ`, so flipping
`CAN_PERIPH_DIV` in `can.h` from 0 to 1 keeps the bit rate correct by
itself (BRP 41 → 20). A `_Static_assert` catches a divisor that does not
divide evenly.

**Open question:** whether the SAM3X CAN controller may run on the full
84 MHz MCK. Check the datasheet; if MCK/2 is required, set
`CAN_PERIPH_DIV` to `1` and change nothing else.

### 5. Smaller fixes — `can.c`

- `#include "../../../lib/can/can.h"` → `#include "can.h"`
- `PIO_IDR` was written with `PIO_PA8A_URXD | PIO_PA9A_UTXD` (the UART
  pins) under a comment about the CAN pins. Now PA0/PA1.
- Added a bounded wait for `CAN_SR_WAKEUP` after enabling the
  controller, so a bus held dominant by a wiring fault cannot hang
  `can_init()`.

## Additions

### Two receive mailboxes — `can.c`

Each SAM3X mailbox holds one message, and the two kinds of traffic want
opposite behaviour on overrun:

| Mailbox | Accepts | Mode | Why |
|---|---|---|---|
| 0 | — | TX | |
| 1 | `0x100` only | `RX_OVERWRITE` | Joystick position is **state**; the newest value is the only one worth having |
| 2 | anything | `RX` | A game command is an **event**; losing a STOP would leave the servo running, so the waiting message is kept |

A frame goes to the lowest-numbered mailbox whose filter matches, so
joystick frames land in 1 and never reach 2.

### `can_tx_try()` — `can.c` / `can.h`

Non-blocking send. The starter `can_tx()` spins until the mailbox frees,
which stalls the loop when no other node is acknowledging. Periodic
messages use `can_tx_try()` instead.

### `can_get_errors()` — `can.c` / `can.h`

Reads TEC and REC from `CAN_ECR` and the error-passive / bus-off flags
from `CAN_SR`. These counters are what separates the two ways CAN fails:
a node alone on the bus gets no acknowledge, so TEC climbs while REC
stays at 0. Wrong bit timing drives REC up on the other node as well.

### `protocol.c` / `protocol.h` — new

The application protocol: ID table, payload layout, bit timing, and the
decode/encode functions. This mirrors `protocol.h` on node 1 and must
stay identical to it.

### `main.c`

The servo sweep is replaced by the joystick driving the servo. The PWM
setup itself is unchanged — same channel, period and duty limits.

- 10 ms loop via `time_doPeriodic()`, fast enough that the single-message
  mailboxes never overrun at node 1's 20 Hz
- `joy->x` → servo, clamped so a corrupt frame cannot drive past the
  mechanical limit
- `START` is idempotent (node 1 repeats it on resume from pause)
- `STOP` centres the servo and clears the score
- 200 ms joystick timeout centres the servo if node 1 goes quiet
- status heartbeat to node 1 every 500 ms
- `report_goal()` is the hook for the IR beam; for now it is triggered by
  the `g` test key

### `Makefile`

`can.c`, `time.c` and `protocol.c` were not in `SOURCE_FILES`, so they
were never compiled.

## Verification

- Builds with `arm-none-eabi-gcc` 13.2: 36 644 B flash, 10 104 B RAM.
  No warnings in the project's own files under `-Wall -Wextra`.
- Node 1's `CNF1=0x03 CNF2=0xB1 CNF3=0x05` and node 2's
  `CAN_BR=0x00290165` were decoded independently. Both give **16 TQ
  (1+2+7+6), TQ = 0.5 µs, 125.0 kbit/s, sample point 62.5 %**.
- All 32 761 joystick (x, y) pairs round-trip through the
  `uint8_t`/`int8_t` casts unchanged.
- All 256 possible `int8_t` inputs map to a duty cycle inside
  0.9–2.1 ms.

## Bring-up

Serial terminal at 9600 baud. The banner should print `BRP 41,
clk 84000000 Hz`; with `CAN_PERIPH_DIV = 1` it prints `BRP 20`. Either is
correct as long as `TQ/bit` says 16.

With node 1 powered and in its game:

1. `s` → `joy ok` with changing x means frames are arriving and decoding.
2. Start/stop the game on node 1 → `START` / `STOP` print here.
3. `g` → node 1's **CAN bus status** screen should increment `RX` and
   raise `score`. That closes the loop in both directions.
4. `e` → compare TEC/REC with node 1's screen. Both 0 means healthy.
   Both TECs climbing with RECs at 0 points at wiring or termination;
   RECs climbing points at bit timing.
