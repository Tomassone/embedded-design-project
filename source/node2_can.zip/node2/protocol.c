#include "protocol.h"
#include "time.h"
#include "sam.h"

static joystick_rx_t joystick;
static game_cmd_t    last_cmd = GAME_CMD_STOP;
static uint8_t       cmd_changed;
static uint64_t      joystick_last_seen;


void can_init_default(uint8_t rxInterrupt)
{
    // Built through the official CAN_BR_* macros rather than the named
    // bitfields of CanInit, whose order does not match the register --
    // see the warning in can.h.
    CanInit init = { .reg = CAN_BR_BRP(CAN_BRP)
                          | CAN_BR_PROPAG(2 - 1)      // Prop Seg   2 TQ
                          | CAN_BR_PHASE1(7 - 1)      // Phase Seg1 7 TQ
                          | CAN_BR_PHASE2(6 - 1)      // Phase Seg2 6 TQ
                          | CAN_BR_SJW(1 - 1) };      // SJW        1 TQ

    can_init(init, rxInterrupt);
}


uint8_t protocol_poll(void)
{
    CanMsg m;
    uint8_t handled = 0;

    while (can_rx(&m))
    {
        handled++;

        switch (m.id)
        {
            case CAN_ID_JOYSTICK:
                if (m.length >= 3)
                {
                    // The cast to int8_t is what makes the sign survive.
                    // Reading byte[0] as unsigned turns -1 into 255 and
                    // the servo jumps to the far end.
                    joystick.x       = (int8_t)m.byte[0];
                    joystick.y       = (int8_t)m.byte[1];
                    joystick.buttons = m.byte[2];
                    joystick.valid   = 1;
                    joystick_last_seen = time_now();
                }
                break;

            case CAN_ID_GAME_CMD:
                if (m.length >= 1 && m.byte[0] <= GAME_CMD_PAUSE)
                {
                    game_cmd_t cmd = (game_cmd_t)m.byte[0];

                    // Node 1 repeats START on resume, so only report a
                    // real change.
                    if (cmd != last_cmd)
                    {
                        last_cmd = cmd;
                        cmd_changed = 1;
                    }
                }
                break;

            default:
                // Not a message type we handle. Node 1 ignores unknown
                // IDs the same way, so either side can add message types
                // without breaking the other.
                break;
        }
    }

    return handled;
}


uint8_t protocol_check_timeout(uint32_t timeout_ms)
{
    if (!joystick.valid)
        return 0;

    if (time_now() - joystick_last_seen > msecs(timeout_ms))
    {
        joystick.valid = 0;
        joystick.x = 0;
        joystick.y = 0;
        joystick.buttons = 0;
        return 1;
    }

    return 0;
}


const joystick_rx_t *protocol_joystick(void)
{
    return &joystick;
}


game_cmd_t protocol_game_cmd(void)
{
    return last_cmd;
}


uint8_t protocol_cmd_changed(void)
{
    uint8_t c = cmd_changed;
    cmd_changed = 0;
    return c;
}


uint8_t protocol_send_goal(uint8_t score)
{
    CanMsg m = { .id = CAN_ID_GOAL, .length = 1 };
    m.byte[0] = score;
    return can_tx_try(m);
}


uint8_t protocol_send_status(node2_status_t status)
{
    CanMsg m = { .id = CAN_ID_NODE2_STATUS, .length = 1 };
    m.byte[0] = (uint8_t)status;
    return can_tx_try(m);
}
