#ifndef JOYSTICK_H
#define JOYSTICK_H

#include <stdint.h>

// ---------------------------------------------------------------------
// joystick.h -- calibrated, filtered joystick on top of the MAX156
//
// Turns two raw 8-bit ADC readings into a pair of signed values centred
// on zero. Four stages, in this order (see joystick.c):
//
//   1. average 4 conversions      kills single-sample ADC noise
//   2. first-order low pass       smooths the remaining ripple
//   3. scale about the centre     maps to -90..+90
//   4. hysteresis and snap        stops a resting stick from twitching
//
// Stages 1 and 2 were not enough on their own: the paddle still drifted
// around its centre point, because a value flickering between two
// neighbouring numbers is real noise, not noise the filter can remove.
// Stage 4 is what fixed it.
// ---------------------------------------------------------------------

// Measured limits of this joystick through this ADC. The hardware does
// not reach 0 or 255 -- the stick's potentiometers sit inside a divider
// -- so the scaling has to be told the real span or the output never
// reaches full deflection.
#define JOY_ADC_MIN     66
#define JOY_ADC_MAX     248

// Output range: -JOY_OUT_MAX .. +JOY_OUT_MAX, 0 at rest. Node 2 expects
// exactly this range and maps it to the cart's travel, so changing it
// means changing JOYSTICK_RANGE on node 2 too.
#define JOY_OUT_MAX     90

// Stage 2: new = old + (sample - old) / 2^SHIFT. Larger is smoother but
// adds lag; 2 means a quarter of the gap is closed per 50 ms frame.
#define JOY_FILTER_SHIFT   2

// Stage 4: the output only moves when the new value differs by at least
// this much, which freezes a resting stick instead of letting it
// oscillate between adjacent numbers.
#define JOY_HYSTERESIS     3

// Stage 4: anything inside this band is forced to exactly 0, so the
// paddle has a real dead centre.
#define JOY_CENTER_SNAP    4

typedef struct {
    int16_t x;
    int16_t y;
} joystick_position_t;

// Measures the resting position and takes it as zero. Call with the
// stick released: it averages 16 conversions over about 32 ms.
//
// Needed because the centre is not 128 -- on this unit it is about
// 157/156 -- and it differs between the two axes and between sticks.
void joystick_calibrate(void);

// One filtered reading. Call exactly once per frame: the low pass and
// the hysteresis both assume a fixed call rate, so calling it twice in
// one frame doubles the filter's effective speed.
joystick_position_t joystick_get_position(void);

// Unfiltered ADC bytes, for the gamepad test screen. Costs one extra
// conversion and does not disturb the filter state.
void joystick_get_raw(uint8_t *x, uint8_t *y);

// Prints the measured centre and the configured span over RS-232.
void joystick_print_calibration(void);

#endif // JOYSTICK_H
