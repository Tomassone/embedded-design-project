#ifndef MCP2515_H
#define MCP2515_H

#include <stdint.h>

// ---------------------------------------------------------------------
// Low-level driver for the MCP2515 stand-alone CAN controller.
// Implements the SPI instruction set (MCP2515 datasheet, chapter 12)
// and register access. Knows nothing about CAN messages as such --
// that is the job of the can module above it.
// ---------------------------------------------------------------------

// --- SPI instructions ---
#define MCP_RESET           0xC0
#define MCP_READ            0x03
#define MCP_WRITE           0x02
#define MCP_RTS_TX0         0x81
#define MCP_RTS_TX1         0x82
#define MCP_RTS_TX2         0x84
#define MCP_READ_STATUS     0xA0
#define MCP_BIT_MODIFY      0x05

// --- Control and status registers ---
#define MCP_CANSTAT         0x0E
#define MCP_CANCTRL         0x0F
#define MCP_CNF3            0x28
#define MCP_CNF2            0x29
#define MCP_CNF1            0x2A
#define MCP_CANINTE         0x2B
#define MCP_CANINTF         0x2C
#define MCP_EFLG            0x2D
#define MCP_TEC             0x1C    // transmit error counter
#define MCP_REC             0x1D    // receive error counter

// --- Transmit buffer 0 ---
#define MCP_TXB0CTRL        0x30
#define MCP_TXB0SIDH        0x31    // SIDH, SIDL, EID8, EID0, DLC, D0..D7

// --- Receive buffers ---
#define MCP_RXB0CTRL        0x60
#define MCP_RXB0SIDH        0x61
#define MCP_RXB1CTRL        0x70
#define MCP_RXB1SIDH        0x71

// --- Operating modes: REQOP bits in CANCTRL, OPMOD bits in CANSTAT ---
#define MCP_MODE_MASK       0xE0
#define MCP_MODE_NORMAL     0x00
#define MCP_MODE_SLEEP      0x20
#define MCP_MODE_LOOPBACK   0x40
#define MCP_MODE_LISTENONLY 0x60
#define MCP_MODE_CONFIG     0x80

// --- CANINTE / CANINTF bits ---
#define MCP_RX0IF           0x01
#define MCP_RX1IF           0x02
#define MCP_TX0IF           0x04
#define MCP_ERRIF           0x20

// --- CANCTRL bits ---
#define MCP_ABAT            0x10    // abort all pending transmissions

// --- EFLG bits ---
#define MCP_EWARN           0x01
#define MCP_RXWAR           0x02
#define MCP_TXWAR           0x04
#define MCP_RXEP            0x08    // receiver error-passive
#define MCP_TXEP            0x10    // transmitter error-passive
#define MCP_TXBO            0x20    // bus-off: node has left the bus
#define MCP_RX0OVR          0x40
#define MCP_RX1OVR          0x80

// --- TXBnCTRL bits ---
#define MCP_TXREQ           0x08

// --- RXBnCTRL bits ---
#define MCP_RXM_ANY         0x60    // RXM = 11: masks/filters off
#define MCP_BUKT            0x04    // RXB0 rolls over into RXB1 when full

// Resets the controller and checks it responds. Afterwards it is in
// configuration mode. Returns 0 on success, 1 if the controller does
// not answer (wiring, power, crystal).
uint8_t mcp2515_init(void);

void mcp2515_reset(void);

uint8_t mcp2515_read(uint8_t address);
void mcp2515_read_block(uint8_t address, uint8_t *buffer, uint8_t length);

void mcp2515_write(uint8_t address, uint8_t data);
void mcp2515_write_block(uint8_t address, const uint8_t *data, uint8_t length);

// Starts transmission of one or more TX buffers: pass MCP_RTS_TX0 etc.
void mcp2515_request_to_send(uint8_t rts_instruction);

// Quick status byte: RX/TX flags and TXREQ bits in a single transfer.
uint8_t mcp2515_read_status(void);

// Changes only the bits selected by mask. Only works on registers the
// datasheet marks as bit-modifiable.
void mcp2515_bit_modify(uint8_t address, uint8_t mask, uint8_t data);

// Requests an operating mode and waits until the controller reports
// it. Returns 0 on success, 1 on timeout.
uint8_t mcp2515_set_mode(uint8_t mode);

#endif // MCP2515_H
