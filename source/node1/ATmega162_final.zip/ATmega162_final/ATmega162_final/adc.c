#ifndef F_CPU
#define F_CPU 4915200UL
#endif

#include "adc.h"
#include <avr/io.h>
#include <util/delay.h>

// volatile is essential: these accesses must not be optimised away or
// reordered. Each read is a real bus cycle that advances the MAX156's
// channel sequence, so the compiler must not cache or merge them.
static volatile uint8_t *adc = (uint8_t *)ADC_BASE_ADDR;

void adc_init(void)
{
    // ---- Timer1 as the MAX156's clock ----
    //
    // The MAX156 needs an external conversion clock. Timer1 in CTC mode
    // toggles OC1A on every compare match, which gives a square wave on
    // PD5:
    //
    //     f = F_CPU / (2 * (1 + OCR1A))
    //       = 4 915 200 / (2 * 2)
    //       = 1.2288 MHz
    //
    // That is inside the MAX156's clock range. The pin must be an
    // output for the compare unit to drive it.
    DDRD |= (1 << PD5);

    OCR1A  = 1;
    TCCR1A = (1 << COM1A0);             // toggle OC1A on compare match
    TCCR1B = (1 << WGM12) | (1 << CS10);// CTC mode, no prescaler
}

// See the warning in adc.h: this cannot select a channel on this board.
uint8_t adc_read_channel(uint8_t channel)
{
    *adc = channel;
    _delay_us(10);
    return *adc;
}

void adc_read_all(uint8_t *results)
{
    // Any write starts a conversion of all four channels. The value
    // written is the channel field, which MODE = high makes irrelevant.
    *adc = 0x00;

    // Conversion time for all four channels. Measured generously: the
    // MAX156 needs about 3 us per channel at this clock, and polling a
    // status line is not wired up, so a fixed delay is the only option.
    _delay_us(20);

    // The four results arrive on four consecutive read cycles. The
    // order is fixed by the converter, and the loop must not be
    // unrolled into fewer bus cycles -- hence the volatile pointer.
    for (uint8_t i = 0; i < 4; i++)
    {
        results[i] = *adc;
    }
}
