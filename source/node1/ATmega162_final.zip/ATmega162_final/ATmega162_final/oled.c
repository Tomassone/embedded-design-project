#ifndef F_CPU
#define F_CPU 4915200UL
#endif

#include "oled.h"
#include "spi.h"
#include <avr/io.h>
#include <util/delay.h>

// The two control pins beside the SPI bus. CS is handled by spi.c.
#define DISP_CTRL_PORT  PORTB
#define DISP_CTRL_DDR   DDRB
#define PIN_DISP_DC     PB1     // 0 = command, 1 = display data
#define PIN_DISP_RES    PB0     // active low

// The framebuffer, in external SRAM. volatile because it is outside the
// internal address space: the compiler must emit real bus cycles and
// must not assume it has exclusive knowledge of the contents.
static volatile uint8_t *framebuffer = (uint8_t *)OLED_BUFFER_ADDR;

void oled_write_command(uint8_t cmd)
{
    DISP_CTRL_PORT &= ~(1 << PIN_DISP_DC);      // D/C low = command
    spi_select(SPI_SLAVE_DISPLAY);
    spi_write(cmd);
    spi_deselect();
}

void oled_write_data(uint8_t data)
{
    DISP_CTRL_PORT |= (1 << PIN_DISP_DC);       // D/C high = data
    spi_select(SPI_SLAVE_DISPLAY);
    spi_write(data);
    spi_deselect();
}

void oled_reset(void)
{
    DISP_CTRL_PORT &= ~(1 << PIN_DISP_RES);
    _delay_ms(10);
    DISP_CTRL_PORT |= (1 << PIN_DISP_RES);
    _delay_ms(100);         // the controller needs time before commands
}

// ---------------------------------------------------------------------
// Initialisation sequence, from the SSD1309 datasheet.
//
// Two details caused a blank screen during development and are worth
// knowing:
//
//  1. Addressing mode. The reset default is PAGE addressing, where the
//     column pointer wraps at the end of a page and does not advance to
//     the next one. oled_flush() streams all 1024 bytes in one go, so
//     HORIZONTAL addressing (0x20, 0x00) is mandatory -- otherwise only
//     the first page ever fills.
//
//  2. Command order. 0xA4 (resume from RAM) and 0xA6 (normal, not
//     inverted) must come AFTER 0xAF (display on). Sent before it they
//     have no lasting effect and the panel stays dark or all-on.
// ---------------------------------------------------------------------
void oled_init(void)
{
    DISP_CTRL_DDR |= (1 << PIN_DISP_DC) | (1 << PIN_DISP_RES);
    DISP_CTRL_PORT |= (1 << PIN_DISP_RES);      // idle high

    oled_reset();

    oled_write_command(0xAE);   // display off while configuring

    oled_write_command(0x20);   // memory addressing mode...
    oled_write_command(0x00);   // ...horizontal -- see note 1 above

    oled_write_command(0x21);   // column address range...
    oled_write_command(0x00);   // ...start 0
    oled_write_command(0x7F);   // ...end 127

    oled_write_command(0x22);   // page address range...
    oled_write_command(0x00);   // ...start 0
    oled_write_command(0x07);   // ...end 7

    oled_write_command(0xA8);   // multiplex ratio...
    oled_write_command(0x3F);   // ...64 rows

    oled_write_command(0xD3);   // display offset...
    oled_write_command(0x00);   // ...none

    oled_write_command(0x40);   // start line 0

    // Orientation. 0xA1 mirrors the columns and 0xC8 reverses the row
    // scan; together they rotate the image 180 degrees, which is how
    // the panel is mounted on this board. Use 0xA0 / 0xC0 if the image
    // comes out upside down.
    oled_write_command(0xA1);   // segment remap
    oled_write_command(0xC8);   // COM scan direction, reversed

    oled_write_command(0xDA);   // COM pin configuration...
    oled_write_command(0x12);   // ...alternative, no left/right remap

    oled_write_command(0x81);   // contrast...
    oled_write_command(0x7F);   // ...mid scale

    oled_write_command(0xD5);   // display clock divide / frequency
    oled_write_command(0x70);

    oled_write_command(0xD9);   // pre-charge period
    oled_write_command(0x22);

    oled_write_command(0xDB);   // VCOMH deselect level
    oled_write_command(0x34);

    // Clear the panel's RAM before switching on, otherwise the first
    // frame is whatever the controller powered up with.
    oled_clear();
    oled_flush();

    oled_write_command(0xAF);   // display on
    _delay_ms(100);             // charge pump settle

    oled_write_command(0xA4);   // resume from RAM -- see note 2 above
    oled_write_command(0xA6);   // normal, not inverted
}

void oled_clear(void)
{
    for (uint16_t i = 0; i < OLED_BUF_SIZE; i++)
        framebuffer[i] = 0x00;
}

void oled_set_pixel(uint8_t x, uint8_t y, uint8_t on)
{
    // Clip rather than wrap. Drawing code at the edges relies on this,
    // for example the position bars in livegame.c.
    if (x >= OLED_WIDTH || y >= OLED_HEIGHT)
        return;

    // y / 8 is the page, y % 8 the bit within the byte. Both divisions
    // are by 8, so the compiler turns them into a shift and a mask.
    uint16_t index = ((uint16_t)(y / 8) * OLED_WIDTH) + x;
    uint8_t mask = (1 << (y % 8));

    if (on)
        framebuffer[index] |= mask;
    else
        framebuffer[index] &= ~mask;
}

// Per-pixel rather than per-byte. A byte-wise version would be several
// times faster, but these are only used for a handful of bars and
// outlines per frame, where the 27 ms flush dominates anyway.
void oled_fill_rect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t on)
{
    for (uint8_t dy = 0; dy < h; dy++)
        for (uint8_t dx = 0; dx < w; dx++)
            oled_set_pixel(x + dx, y + dy, on);
}

void oled_draw_hline(uint8_t x, uint8_t y, uint8_t length, uint8_t on)
{
    for (uint8_t i = 0; i < length; i++)
        oled_set_pixel(x + i, y, on);
}

void oled_draw_vline(uint8_t x, uint8_t y, uint8_t length, uint8_t on)
{
    for (uint8_t i = 0; i < length; i++)
        oled_set_pixel(x, y + i, on);
}

void oled_flush(void)
{
    // One CS window for all 1024 bytes. The column and page pointers
    // auto-increment in horizontal addressing mode, so no addressing
    // commands are needed in between -- that is what makes a single
    // stream possible.
    DISP_CTRL_PORT |= (1 << PIN_DISP_DC);       // data, not command
    spi_select(SPI_SLAVE_DISPLAY);

    for (uint16_t i = 0; i < OLED_BUF_SIZE; i++)
        spi_write(framebuffer[i]);

    spi_deselect();
}
