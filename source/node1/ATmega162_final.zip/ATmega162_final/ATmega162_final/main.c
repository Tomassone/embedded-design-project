#define F_CPU 4915200UL
#define BAUD 9600UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/delay.h>
#include <stdio.h>
#include "uart.h"
#include "sram.h"
#include "adc.h"
#include "joystick.h"
#include "spi.h"
#include "oled.h"
#include "oled_text.h"
#include "ioboard.h"
#include "timer.h"
#include "input.h"
#include "menu.h"
#include "game.h"
#include "livegame.h"
#include "highscore.h"
#include "lightbar.h"
#include "can.h"
#include "protocol.h"

// ---------------------------------------------------------------------
// main.c -- node 1: input, display, menus and the game rules
//
// A cooperative state machine, one pass per fixed 50 ms frame. Nothing
// here blocks: every screen is drawn in one pass and every wait is a
// timestamp comparison, so one slow state cannot stall another.
//
// The frame budget is dominated by one item -- oled_flush() pushes 1024
// bytes over SPI at 307 kHz, about 27 ms. That is why the period is
// 50 ms and why the test screens redraw every second frame.
//
// Division of work with node 2:
//
//   node 1  joystick, buttons, display, menus, highscores, and the
//           rules of a round (three goals ends it)
//   node 2  the machine itself -- cart via PID, servo, solenoid, and
//           the IR beam that detects a goal
//
// So in live play node 1 sends the joystick at 20 Hz and receives a
// score; it has no sensors of its own on the table. The console game
// is the opposite: entirely local, nothing sent.
//
// On a frame overrun the loop resynchronises to the current time rather
// than catching up, so a late frame is dropped instead of producing a
// burst of back-to-back frames.
// ---------------------------------------------------------------------

// One frame = one pass through the state machine. A full display flush
// takes ~27 ms at the current SPI clock, so 50 ms leaves headroom.
#define FRAME_MS            50

// Live test screens redraw every 2nd frame (100 ms). Fast enough to
// feel responsive, slow enough to leave the frame room for the flush.
#define TEST_DIVIDER        2

// In pause: holding SR6 this long stops the game, a shorter press
// resumes.
#define STOP_HOLD_MS        2500

// Node 2 is considered absent if nothing has arrived for this long.
#define NODE2_TIMEOUT_MS    1000

typedef enum {
    STATE_MAIN_MENU,
    STATE_LIVE,             // real machine on node 2
    STATE_GAME,             // console game, local only
    STATE_PAUSED,
    STATE_GAME_OVER,
    STATE_HIGHSCORES,
    STATE_TEST_MENU,
    STATE_GAMEPAD_TEST,
    STATE_CAN_STATUS,
    STATE_MESSAGE           // info screen, returns to the test menu
} app_state_t;

// Which game is running or paused. The pause and game-over screens are
// shared, so they need to know which one they are showing.
typedef enum {
    MODE_LIVE,
    MODE_CONSOLE
} play_mode_t;

// ---------------------------------------------------------------------
// Menu definitions -- all text in flash.
// ---------------------------------------------------------------------
static const char str_main_title[]  PROGMEM = "PONG";
static const char str_live[]        PROGMEM = "Live play";
static const char str_console[]     PROGMEM = "Console game";
static const char str_highscores[]  PROGMEM = "Highscores";
static const char str_cal_test[]    PROGMEM = "Calibration & Test";

static const char * const main_items[] PROGMEM = {
    str_live, str_console, str_highscores, str_cal_test
};

enum { MAIN_LIVE, MAIN_CONSOLE, MAIN_HIGHSCORES, MAIN_CAL_TEST };

static const menu_t main_menu = { str_main_title, main_items, 4 };

static const char str_test_title[]  PROGMEM = "CALIBRATION & TEST";
static const char str_calibrate[]   PROGMEM = "Calibrate joystick";
static const char str_gamepad[]     PROGMEM = "Gamepad test";
static const char str_sram_test[]   PROGMEM = "SRAM test";
static const char str_can_test[]    PROGMEM = "CAN loopback test";
static const char str_can_status[]  PROGMEM = "CAN bus status";
static const char str_reset_hs[]    PROGMEM = "Reset highscores";
static const char str_back[]        PROGMEM = "Back";

static const char * const test_items[] PROGMEM = {
    str_calibrate, str_gamepad, str_sram_test, str_can_test,
    str_can_status, str_reset_hs, str_back
};

enum { TEST_CALIBRATE, TEST_GAMEPAD, TEST_SRAM, TEST_CAN,
       TEST_CAN_STATUS, TEST_RESET_HS, TEST_BACK };

static const menu_t test_menu = { str_test_title, test_items, 7 };

// Screen text used on more than one screen. PSTR() creates a fresh copy
// in every function it appears in, so a footer used on five screens was
// stored five times. Flash is the scarce resource on this part.
static const char ftr_back[]   PROGMEM = "SR6: back";
static const char t_scores[]   PROGMEM = "HIGHSCORES";

// ---------------------------------------------------------------------
// State
// ---------------------------------------------------------------------
static app_state_t state;
static menu_nav_t nav;
static uint8_t draw_counter;

static play_mode_t play_mode;       // game currently running or paused

static uint8_t pause_holding;       // SR6 currently held down in pause
static uint16_t pause_press_start;

static uint8_t gamepad_page;        // 0 or 1
static uint16_t fire_presses;       // counted on the gamepad test screen

static uint16_t can_tx_count;
static uint16_t can_rx_count;
static uint16_t can_tx_failed;
static uint8_t can_mode_loopback;

static uint16_t node2_last_seen;
static uint8_t node2_fresh;         // decided once per frame, see below

static uint8_t fire_level;          // NAV_B, sampled once per frame

// ---------------------------------------------------------------------
// Input diagnostics over RS-232, 2 Hz. One line covers both input
// subsystems, which reach the ATmega162 by completely separate routes:
//
//   raw  joystick, MAX156 ADC on the XMEM bus at 0x1000
//   pos  the same values after calibration and filtering
//   BTN  IO board buttons, read over SPI
//
// It needs no menu navigation, so it still works when neither input
// responds. Set to 1 to bring it back -- it costs about 130 bytes of
// flash and this part is nearly full.
// ---------------------------------------------------------------------
#define DUMP_INPUTS         0
#define DUMP_PERIOD_MS      500

#if DUMP_INPUTS
static void dump_inputs(uint16_t now, int16_t pos_x, int16_t pos_y)
{
    static uint16_t next;

    if ((int16_t)(now - next) < 0)
        return;

    next = now + DUMP_PERIOD_MS;

    uint8_t raw_x, raw_y;
    joystick_get_raw(&raw_x, &raw_y);

    const ioboard_buttons_t *b = input_buttons();

    printf_P(PSTR("IN raw %3u,%3u  pos %4d,%4d  BTN R%02X L%02X N%02X\r\n"),
             raw_x, raw_y, pos_x, pos_y, b->right, b->left, b->nav);
}
#endif

// ---------------------------------------------------------------------
// Whether node 2 is still talking. Must be decided once per frame.
//
// The tempting one-liner -- (uint16_t)(now - node2_last_seen) < timeout
// -- is wrong on demand: timer_millis() wraps every 65.5 s, so once
// node 2 has been quiet for about a minute the difference aliases back
// under the timeout and a dead node reports alive again. Evaluating it
// every frame, while the difference is still small, removes the alias.
// ---------------------------------------------------------------------
static void node2_update(uint16_t now, uint8_t heard)
{
    if (heard)
    {
        node2_last_seen = now;
        node2_fresh = 1;
    }
    else if (node2_fresh &&
             (uint16_t)(now - node2_last_seen) >= NODE2_TIMEOUT_MS)
    {
        node2_fresh = 0;
    }
}

// Screens that do nothing but wait to be dismissed.
static uint8_t dismissed(input_event_t event)
{
    return event == INPUT_SELECT || event == INPUT_LEFT;
}

// ---------------------------------------------------------------------
// Screens
// ---------------------------------------------------------------------

// The pause and game-over screens both report whichever game is
// running, so the choice of what "score" means lives in one place.
static void print_play_stats(uint8_t line, uint8_t column)
{
    oled_goto(line, column);

    if (play_mode == MODE_LIVE)
        oled_printf_P(PSTR("Goals %u   %u s"),
                      live_get_goals(), live_get_seconds());
    else
        oled_printf_P(PSTR("Score: %u"), game_get_score());
}

// Two tables side by side: live play is scored in seconds survived,
// the console game in Pong points.
static void show_highscores(void)
{
    screen_begin(t_scores);

    oled_goto(1, 0);
    oled_print_P(PSTR("    LIVE   CONSOLE"));

    for (uint8_t i = 0; i < HIGHSCORE_COUNT; i++)
    {
        oled_goto(2 + i, 0);
        oled_printf_P(PSTR("%u  %4us    %6u"),
                      i + 1,
                      highscore_get(HS_LIVE, i),
                      highscore_get(HS_CONSOLE, i));
    }

    screen_end(ftr_back);
}

// Pause screen. fill = hold progress towards stopping, 0..100 pixels.
static void show_pause(uint8_t fill)
{
    static const char title[] PROGMEM = "PAUSED";

    screen_begin(title);
    print_play_stats(2, 1);

    oled_goto(4, 1);
    oled_print_P(PSTR("SR6 tap : resume"));
    oled_goto(5, 1);
    oled_print_P(PSTR("SR6 hold: stop game"));

    // Progress bar: outline 102 x 8 px, fills while SR6 is held.
    oled_draw_hline(13, 52, 102, 1);
    oled_draw_hline(13, 59, 102, 1);
    oled_draw_vline(13, 52, 8, 1);
    oled_draw_vline(114, 52, 8, 1);

    if (fill > 0)
        oled_fill_rect(14, 54, fill, 4, 1);

    screen_end(0);
}

static void show_game_over(uint8_t stopped, int8_t rank)
{
    static const char over[] PROGMEM = "GAME OVER";
    static const char stop[] PROGMEM = "GAME STOPPED";

    screen_begin(stopped ? stop : over);
    print_play_stats(2, 2);

    if (rank >= 0)
    {
        oled_goto(4, 2);
        oled_printf_P(PSTR("New highscore! #%d"), rank + 1);
    }

    screen_end(PSTR("SR6: continue"));
}

// Generic two-line message screen, used by the test menu actions.
static void show_message(const char *title_P, const char *line_P)
{
    screen_begin(title_P);

    oled_goto(2, 1);
    oled_print_P(line_P);

    screen_end(ftr_back);
}

// ---------------------------------------------------------------------
// Gamepad test -- every input node 1 actually uses, on two pages.
//
// Page 1 shows the inputs in use with their function. Page 2 shows every
// button by name, so a button whose position is unknown can be found by
// pressing it and reading which marker lights up.
//
// Both pages are left with the joystick, not with SR6, so that SR6
// itself stays testable.
// ---------------------------------------------------------------------
static const char lbl_sr[] PROGMEM = "SR 1 2 3 4 5 6";
static const char lbl_sl[] PROGMEM = "SL 1 2 3 4 5 6 7";
static const char lbl_nv[] PROGMEM = "NV B R D L U";

static const char * const btn_labels[] PROGMEM = { lbl_sr, lbl_sl, lbl_nv };
static const uint8_t btn_counts[] PROGMEM = { 6, 7, 5 };

static const char ftr_pages[] PROGMEM = "up/dn page  left=back";

static void print_bits(uint8_t value, uint8_t count)
{
    for (uint8_t i = 0; i < count; i++)
    {
        oled_putchar((value & (1 << i)) ? '#' : '.');
        oled_putchar(' ');
    }
}

static void draw_gamepad_test(int16_t pos_x, int16_t pos_y)
{
    static const char title1[] PROGMEM = "GAMEPAD TEST 1/2";
    static const char title2[] PROGMEM = "GAMEPAD TEST 2/2";
    static const char down[]   PROGMEM = "DOWN";
    static const char up[]     PROGMEM = "--  ";

    const ioboard_buttons_t *b = input_buttons();

    if (gamepad_page == 0)
    {
        uint8_t raw_x, raw_y;
        joystick_get_raw(&raw_x, &raw_y);

        ioboard_slider_t slider = ioboard_read_slider();
        ioboard_touchpad_t pad = ioboard_read_touchpad();

        screen_begin(title1);

        oled_goto(1, 0);
        oled_printf_P(PSTR("Joy raw  X%3u Y%3u"), raw_x, raw_y);
        oled_goto(2, 0);
        oled_printf_P(PSTR("Joy pos  X%4d Y%4d"), pos_x, pos_y);

        oled_goto(3, 0);
        oled_printf_P(PSTR("MENU SR6    %S"),
                      input_select_state() ? down : up);
        oled_goto(4, 0);
        oled_printf_P(PSTR("FIRE NAV_B  %S"), fire_level ? down : up);

        oled_goto(5, 0);
        oled_printf_P(PSTR("Fire presses %u"), fire_presses);

        oled_goto(6, 0);
        oled_printf_P(PSTR("Sld%3u Pad%3u,%3u"), slider.x, pad.x, pad.y);
    }
    else
    {
        // The three button bytes differ only in label and bit count, so
        // one loop over a table replaces three near-identical blocks.
        const uint8_t bytes[3] = { b->right, b->left, b->nav };

        screen_begin(title2);

        for (uint8_t i = 0; i < 3; i++)
        {
            oled_goto(1 + i * 2, 0);
            oled_print_P((const char *)pgm_read_word(&btn_labels[i]));

            oled_goto(2 + i * 2, 3);
            print_bits(bytes[i], pgm_read_byte(&btn_counts[i]));
        }
    }

    screen_end(ftr_pages);
}

// ---------------------------------------------------------------------
// Live bus diagnostics. The error counters are what distinguishes the
// two ways CAN fails: a node alone on the bus gets no acknowledge, so
// TEC climbs steadily. Wrong bit timing produces the same symptom but
// also drives REC up on the other node.
// ---------------------------------------------------------------------
static void draw_can_status(void)
{
    static const char title[] PROGMEM = "CAN BUS STATUS";

    can_error_t err;
    can_get_errors(&err);

    screen_begin(title);

    oled_goto(1, 0);
    oled_printf_P(PSTR("Mode: %S"),
                  can_mode_loopback ? PSTR("loopback") : PSTR("normal"));

    oled_goto(2, 0);
    oled_printf_P(PSTR("TX %5u  fail %5u"), can_tx_count, can_tx_failed);

    oled_goto(3, 0);
    oled_printf_P(PSTR("RX %5u  cmdq %u"), can_rx_count,
                  protocol_cmd_pending());

    oled_goto(4, 0);
    oled_printf_P(PSTR("TEC %3u   REC %3u"), err.tx_errors, err.rx_errors);

    oled_goto(5, 0);
    if (err.bus_off)
        oled_print_P(PSTR("BUS OFF - no node 2?"));
    else if (err.error_passive)
        oled_print_P(PSTR("Error passive"));
    else if (err.rx_errors == 0 && err.tx_errors == 0)
        oled_print_P(PSTR("Bus OK"));
    else
        oled_print_P(PSTR("Errors present"));

    oled_goto(6, 0);
    oled_printf_P(PSTR("N2 %S  score %u"),
                  node2_fresh ? PSTR("alive") : PSTR("quiet"),
                  protocol_node2()->score);

    screen_end(PSTR("SR6 back  up=recover"));
}

// ---------------------------------------------------------------------
// CAN loopback test: sends three messages with different IDs and
// lengths (including the 0- and 8-byte edge cases) and checks that
// each comes back unchanged. Also reports whether the MCP2515
// interrupt line reached INT0.
// ---------------------------------------------------------------------
static void run_can_test(void)
{
    static const char title[] PROGMEM = "CAN LOOPBACK";

    screen_begin(title);

    // Only the mode changes -- bit timing and filters stay as they are.
    can_mode_loopback = 1;

    if (can_set_mode(CAN_MODE_LOOPBACK) != 0)
    {
        oled_goto(2, 1);
        oled_print_P(PSTR("MCP2515 no answer"));
        oled_goto(3, 1);
        oled_print_P(PSTR("Check SPI, CS, xtal"));
        screen_end(ftr_back);
        return;
    }

    const uint16_t ids[3]    = { 0x001, 0x123, 0x7FF };
    const uint8_t lengths[3] = { 0, 3, 8 };

    uint8_t passed = 0;
    uint8_t int_seen = 0;

    for (uint8_t t = 0; t < 3; t++)
    {
        can_message_t tx;
        can_message_t rx;

        tx.id = ids[t];
        tx.length = lengths[t];
        for (uint8_t i = 0; i < tx.length; i++)
            tx.data[i] = 0xA0 + (t << 4) + i;

        uint8_t ok = 0;

        if (can_send(&tx) == 0)
        {
            // Wait up to 20 ms for the interrupt. One 8-byte frame
            // takes under 1 ms at 125 kbit/s.
            for (uint8_t ms = 0; ms < 20 && !can_rx_pending(); ms++)
                _delay_ms(1);

            if (can_rx_pending())
                int_seen = 1;

            // Read regardless of the interrupt, so a missing INT
            // connection shows up separately from a failed transfer.
            if (can_receive(&rx) &&
                rx.id == tx.id && rx.length == tx.length)
            {
                ok = 1;
                for (uint8_t i = 0; i < tx.length; i++)
                    if (rx.data[i] != tx.data[i])
                        ok = 0;
            }
        }

        if (ok)
            passed++;

        oled_goto(2 + t, 1);
        oled_printf_P(PSTR("ID %03X len %u  %S"),
                      tx.id, tx.length, ok ? PSTR("OK") : PSTR("FAIL"));
    }

    oled_goto(5, 1);
    oled_printf_P(PSTR("INT line: %S"), int_seen ? PSTR("OK") : PSTR("none"));

    oled_goto(6, 1);
    oled_printf_P(PSTR("%u of 3 passed"), passed);

    // Back to normal mode, otherwise the bus stays disconnected.
    can_set_mode(CAN_MODE_NORMAL);
    can_mode_loopback = 0;

    screen_end(ftr_back);
}

// ---------------------------------------------------------------------
// State transitions
// ---------------------------------------------------------------------
static void enter_main_menu(void)
{
    state = STATE_MAIN_MENU;
    menu_open(&nav, &main_menu);
}

static void enter_test_menu(void)
{
    state = STATE_TEST_MENU;
    menu_open(&nav, &test_menu);
}

static void start_live(uint16_t now)
{
    state = STATE_LIVE;
    play_mode = MODE_LIVE;
    live_start(now);
    lightbar_start();
}

static void start_console(void)
{
    state = STATE_GAME;
    play_mode = MODE_CONSOLE;
    game_start();
    lightbar_start();
    game_draw();
}

static void pause_game(void)
{
    state = STATE_PAUSED;
    pause_holding = 0;

    // Only live play has anything to pause on the other node.
    if (play_mode == MODE_LIVE)
        protocol_send_command(GAME_CMD_PAUSE);

    lightbar_off();
    show_pause(0);
}

static void resume_game(uint16_t now)
{
    pause_holding = 0;
    lightbar_start();

    if (play_mode == MODE_LIVE)
    {
        state = STATE_LIVE;
        live_resume(now);
    }
    else
    {
        state = STATE_GAME;
        game_draw();
    }
}

static void end_game(uint8_t stopped)
{
    lightbar_off();

    int8_t rank;

    if (play_mode == MODE_LIVE)
    {
        // STOP switches node 2's motor off and clears its score.
        protocol_send_command(GAME_CMD_STOP);
        rank = highscore_submit(HS_LIVE, live_get_seconds());
    }
    else
    {
        rank = highscore_submit(HS_CONSOLE, game_get_score());
    }

    state = STATE_GAME_OVER;
    show_game_over(stopped, rank);
}

static void run_test_action(uint8_t action, int16_t pos_x, int16_t pos_y)
{
    static const char t_cal[]  PROGMEM = "CALIBRATION";
    static const char t_sram[] PROGMEM = "SRAM TEST";

    switch (action)
    {
        case TEST_CALIBRATE:
            show_message(t_cal, PSTR("Release joystick..."));
            _delay_ms(800);
            joystick_calibrate();
            joystick_print_calibration();
            show_message(t_cal, PSTR("Centre calibrated."));
            state = STATE_MESSAGE;
            break;

        case TEST_GAMEPAD:
            state = STATE_GAMEPAD_TEST;
            gamepad_page = 0;
            draw_counter = 0;
            fire_presses = 0;
            draw_gamepad_test(pos_x, pos_y);
            break;

        case TEST_SRAM:
        {
            show_message(t_sram, PSTR("Running..."));

            // The test overwrites 0x1800..0x1FFF, which includes the
            // framebuffer -- the screen is rebuilt from scratch below.
            uint16_t errors = sram_test();

            screen_begin(t_sram);
            oled_goto(2, 1);
            oled_printf_P(PSTR("Errors: %u"), errors);
            screen_end(ftr_back);

            state = STATE_MESSAGE;
            break;
        }

        case TEST_CAN:
            run_can_test();
            state = STATE_MESSAGE;
            break;

        case TEST_CAN_STATUS:
            state = STATE_CAN_STATUS;
            draw_counter = 0;
            draw_can_status();      // draw at once, not one frame later
            break;

        case TEST_RESET_HS:
            highscore_reset();
            show_message(t_scores, PSTR("Both lists cleared."));
            state = STATE_MESSAGE;
            break;

        default:            // Back
            enter_main_menu();
            break;
    }
}

// ---------------------------------------------------------------------
// Sends the current joystick position to node 2 and keeps the counters.
//
// Bit 0 of the button byte is the solenoid trigger, and node 2 reads it
// as a LEVEL: it does its own edge detection and enforces a cooldown,
// so node 1 must not try to send a one-shot pulse here.
//
// Joystick data is periodic state, not a queue of events: if the
// previous frame is somehow still waiting for the bus, the newer
// position supersedes it. So a stuck transmission is aborted rather
// than waited on -- otherwise a single unacknowledged frame would
// block the buffer forever, since the controller keeps retrying.
// ---------------------------------------------------------------------
static void send_joystick(int16_t x, int16_t y)
{
    static uint8_t busy_frames = 0;

    uint8_t buttons = 0;

    if (fire_level)
        buttons |= JOY_BTN_FIRE;            // NAV_B -> solenoid
    if (input_select_state())
        buttons |= JOY_BTN_MENU;            // SR6, diagnostics only

    uint8_t result = protocol_send_joystick((int8_t)x, (int8_t)y, buttons);

    if (result == 1)
    {
        can_tx_failed++;

        // One busy frame can happen; two in a row means nobody is
        // acknowledging and the controller is still retrying.
        if (++busy_frames >= 2)
        {
            can_abort_tx();
            busy_frames = 0;
        }
        return;
    }

    // Success, or deferred in favour of a queued command. Aborting on a
    // deferral would cancel the very command we are waiting for -- that
    // is how GAME_CMD_START used to get lost. A deferral counts as
    // neither sent nor failed: the bus was used, by a higher priority
    // message.
    busy_frames = 0;

    if (result == 0)
        can_tx_count++;
}

// ---------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------
int main(void)
{
    DDRE |= (1 << PE2);   // heartbeat LED

    uart_init();
    timer_init();
    sei();

    xmem_init();          // framebuffer lives in external SRAM
    adc_init();
    spi_init();
    oled_init();
    input_init();
    highscore_init();
    lightbar_off();       // IO board LEDs may still be on from before a reset

    protocol_reset_state();

    if (can_init(CAN_MODE_NORMAL) == 0)
        printf_P(PSTR("CAN ready, 125 kbit/s, normal mode\r\n"));
    else
        printf_P(PSTR("CAN controller not responding\r\n"));

    joystick_calibrate();

    // Node 2 may still be driving its motor from an earlier session.
    protocol_send_command(GAME_CMD_STOP);

    printf_P(PSTR("\r\nNode 1 -- MENU=SR6 FIRE=NAV_B\r\n"));

    enter_main_menu();

    uint16_t last_frame = timer_millis();
    uint16_t last_heartbeat = last_frame;

    while (1)
    {
        uint16_t now = timer_millis();

        if ((uint16_t)(now - last_frame) < FRAME_MS)
            continue;

        // Resynchronise to the current time rather than adding FRAME_MS:
        // if a frame overruns, the loop drops it instead of trying to
        // catch up with a burst of back-to-back frames.
        last_frame = now;

        joystick_position_t pos = joystick_get_position();

        // input_poll() is the only reader of the IO board buttons, so it
        // runs every frame regardless of state.
        input_event_t event = input_poll(now, pos.x, pos.y);

        fire_level = input_fire_state();
        if (input_fire_pressed())       // consumed exactly once per frame
            fire_presses++;

#if DUMP_INPUTS
        dump_inputs(now, pos.x, pos.y);
#endif

        // Drain anything node 2 has sent. More than one frame can be
        // waiting, since the controller buffers two.
        uint8_t heard = 0;

        while (protocol_poll())
        {
            can_rx_count++;
            heard = 1;
        }

        node2_update(now, heard);

        // Retry any command still waiting for the transmit buffer. This
        // has to happen in every state: the STOP sent on the way out of
        // a game would otherwise never be retried, because the game-over
        // screen sends no joystick frames.
        protocol_tick();

        switch (state)
        {
            case STATE_MAIN_MENU:
            {
                int8_t choice = menu_handle(&nav, event);

                if (choice == MAIN_LIVE)
                    start_live(now);
                else if (choice == MAIN_CONSOLE)
                    start_console();
                else if (choice == MAIN_HIGHSCORES)
                {
                    state = STATE_HIGHSCORES;
                    show_highscores();
                }
                else if (choice == MAIN_CAL_TEST)
                    enter_test_menu();
                break;
            }

            // --- Live play: node 2 runs the machine, node 1 the rules.
            case STATE_LIVE:
                if (event == INPUT_SELECT)
                {
                    pause_game();
                    break;
                }

                // live_update() queues GAME_CMD_START when arming ends,
                // so it must run BEFORE the joystick send: the queue is
                // what gives the command priority over the 20 Hz stream.
                if (live_update(now) == LIVE_OVER)
                {
                    end_game(0);
                    break;
                }

                send_joystick(pos.x, pos.y);
                live_draw(pos.x, pos.y, fire_level, node2_fresh);
                lightbar_update();
                break;

            // --- Console game: entirely local. No joystick frames go
            // out, so the real cart stays where it is.
            case STATE_GAME:
                if (event == INPUT_SELECT)
                {
                    pause_game();
                    break;
                }

                if (game_update(pos.x) == GAME_OVER)
                {
                    end_game(0);
                    break;
                }

                game_draw();
                lightbar_update();
                break;

            case STATE_PAUSED:
                // A new press starts the hold timer. The press that
                // paused the game does not count: it happened before
                // this state was entered.
                if (event == INPUT_SELECT)
                {
                    pause_holding = 1;
                    pause_press_start = now;
                    break;
                }

                if (pause_holding)
                {
                    uint16_t held = now - pause_press_start;

                    if (!input_select_state())
                    {
                        resume_game(now);   // released early: resume
                        break;
                    }

                    if (held >= STOP_HOLD_MS)
                    {
                        end_game(1);        // held long enough: stop
                        break;
                    }

                    show_pause((uint8_t)(held / (STOP_HOLD_MS / 100)));
                }
                break;

            case STATE_GAME_OVER:
            case STATE_HIGHSCORES:
                if (dismissed(event))
                    enter_main_menu();
                break;

            case STATE_MESSAGE:
                if (dismissed(event))
                    enter_test_menu();
                break;

            case STATE_TEST_MENU:
            {
                int8_t choice = menu_handle(&nav, event);

                if (choice == MENU_BACK)
                    enter_main_menu();
                else if (choice >= 0)
                    run_test_action((uint8_t)choice, pos.x, pos.y);
                break;
            }

            // --- Gamepad test: left exits, so SR6 stays testable.
            case STATE_GAMEPAD_TEST:
                if (event == INPUT_LEFT)
                {
                    enter_test_menu();
                    break;
                }

                if (event == INPUT_UP || event == INPUT_DOWN)
                    gamepad_page ^= 1;

                if (++draw_counter >= TEST_DIVIDER)
                {
                    draw_counter = 0;
                    draw_gamepad_test(pos.x, pos.y);
                }
                break;

            case STATE_CAN_STATUS:
                if (dismissed(event))
                {
                    enter_test_menu();
                    break;
                }

                // Joystick up clears a bus-off condition by resetting
                // and reconfiguring the controller.
                if (event == INPUT_UP)
                {
                    can_recover();
                    can_mode_loopback = 0;
                    can_tx_count = 0;
                    can_rx_count = 0;
                    can_tx_failed = 0;
                }

                // Keep a heartbeat on the bus so the counters move even
                // outside a game, which is what makes this screen
                // useful for finding wiring and timing faults.
                send_joystick(pos.x, pos.y);

                if (++draw_counter >= TEST_DIVIDER)
                {
                    draw_counter = 0;
                    draw_can_status();
                }
                break;
        }

        if ((uint16_t)(now - last_heartbeat) >= 250)
        {
            last_heartbeat = now;
            PORTE ^= (1 << PE2);
        }
    }
}
