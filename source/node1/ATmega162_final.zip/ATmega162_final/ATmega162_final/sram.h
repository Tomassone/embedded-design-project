#ifndef SRAM_H
#define SRAM_H

#include <stdint.h>

// ---------------------------------------------------------------------
// sram.h -- external SRAM on the XMEM bus (exercise 2)
//
// An IDT7164 (8 KiB) behind a 74ALS573 address latch. The ATmega162
// multiplexes the low address byte with the data byte on port A, so the
// latch holds A0..A7 while the data phase uses the same pins. ALE
// clocks it.
//
// Address decoding uses a single address bit, A11, inverted by one gate
// of the 74HC00:
//
//     A11 = 1  ->  0x1000..0x17FF  MAX156 ADC
//     A11 = 0  ->  0x1800..0x1FFF  SRAM
//
// That is partial decoding: the SRAM responds to a 2 KiB window only,
// which is all the project needs and all the chip selects allow.
// ---------------------------------------------------------------------

#define SRAM_BASE_ADDR   0x1800
#define SRAM_SIZE        0x800      // 2 KiB

// Enables the external memory interface. Must run before any access to
// SRAM_BASE_ADDR or the ADC, and before oled_init(), because the
// framebuffer lives in this SRAM.
//
// NOTE: the enable bit SRE is in MCUCR, but the address-mask bits XMM
// are in SFIOR -- not in EMCUCR, which holds the wait-state and ISC2
// bits. Mixing those two up is a classic way to get a dead bus.
void xmem_init(void);

// Writes a pseudo-random pattern over the whole window, reads it back
// immediately, then reads the whole block a second time. Returns the
// total number of mismatches; 0 means the bus, the latch and the chip
// are all working.
//
// WARNING: this overwrites 0x1800..0x1FFF, which includes the OLED
// framebuffer (OLED_BUFFER_ADDR). The caller must redraw the screen
// afterwards.
uint16_t sram_test(void);

#endif // SRAM_H
