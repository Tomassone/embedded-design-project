#include "highscore.h"
#include <avr/eeprom.h>

// Marks the EEPROM content as valid. A fresh or erased EEPROM reads
// 0xFF everywhere, which would otherwise show up as scores of 65535.
//
// Bumped from 0xA7 when the second table was added: the old layout held
// one list, so an EEPROM written by the previous firmware must be
// reinitialised rather than reinterpreted.
#define HIGHSCORE_MAGIC  0xA8

typedef struct {
    uint8_t magic;
    uint16_t scores[HS_LISTS][HIGHSCORE_COUNT];
} highscore_store_t;

static highscore_store_t EEMEM store;                   // in EEPROM
static uint16_t scores[HS_LISTS][HIGHSCORE_COUNT];      // RAM copy

static void save(void)
{
    // update_ only writes bytes that changed -- EEPROM cells survive
    // about 100 000 writes, so skipping unchanged ones is worthwhile.
    eeprom_update_block(scores, store.scores, sizeof(scores));
    eeprom_update_byte(&store.magic, HIGHSCORE_MAGIC);
}

void highscore_init(void)
{
    if (eeprom_read_byte(&store.magic) != HIGHSCORE_MAGIC)
    {
        highscore_reset();
        return;
    }

    eeprom_read_block(scores, store.scores, sizeof(scores));
}

uint16_t highscore_get(highscore_list_t list, uint8_t rank)
{
    if (list >= HS_LISTS || rank >= HIGHSCORE_COUNT)
        return 0;

    return scores[list][rank];
}

int8_t highscore_submit(highscore_list_t list, uint16_t score)
{
    if (list >= HS_LISTS || score == 0)
        return -1;

    for (uint8_t rank = 0; rank < HIGHSCORE_COUNT; rank++)
    {
        if (score > scores[list][rank])
        {
            // Shift the lower entries down one place to make room.
            for (uint8_t i = HIGHSCORE_COUNT - 1; i > rank; i--)
                scores[list][i] = scores[list][i - 1];

            scores[list][rank] = score;
            save();
            return (int8_t)rank;
        }
    }

    return -1;
}

void highscore_reset(void)
{
    for (uint8_t l = 0; l < HS_LISTS; l++)
        for (uint8_t i = 0; i < HIGHSCORE_COUNT; i++)
            scores[l][i] = 0;

    save();
}
