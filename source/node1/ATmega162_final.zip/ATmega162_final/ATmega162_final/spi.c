#include "spi.h"
#include <avr/io.h>

// ---------------------------------------------------------------------
// Hardware SPI pins on the ATmega162. These are fixed by the
// peripheral and cannot be moved.
// ---------------------------------------------------------------------
#define SPI_DDR      DDRB
#define SPI_PORT     PORTB
#define PIN_SS_HW    PB4        // hardware slave select -- see spi_init()
#define PIN_MOSI     PB5
#define PIN_MISO     PB6
#define PIN_SCK      PB7

// Chip selects. These are ordinary GPIOs, so they are free choices.
// All three are active low.
#define CS_DISP_PORT PORTB
#define CS_DISP_DDR  DDRB
#define PIN_CS_DISP  PB2

#define CS_IO_PORT   PORTB
#define CS_IO_DDR    DDRB
#define PIN_CS_IO    PB3

#define CS_CAN_PORT  PORTD
#define CS_CAN_DDR   DDRD
#define PIN_CS_CAN   PD3

void spi_init(void)
{
    // MOSI and SCK are driven by the master. MISO stays an input.
    //
    // PB4 is configured as an OUTPUT although nothing is connected to
    // it. In master mode the hardware SS pin is an input, and if
    // anything pulls it low the peripheral clears MSTR and drops out of
    // master mode by itself. Driving it removes that possibility.
    SPI_DDR |=  (1 << PIN_MOSI) | (1 << PIN_SCK) | (1 << PIN_SS_HW);
    SPI_DDR &= ~(1 << PIN_MISO);
    SPI_PORT |= (1 << PIN_SS_HW);

    CS_DISP_DDR  |= (1 << PIN_CS_DISP);
    CS_IO_DDR    |= (1 << PIN_CS_IO);
    CS_CAN_DDR   |= (1 << PIN_CS_CAN);

    // Deselect before enabling the peripheral, so no slave sees the
    // first clock edges.
    spi_deselect();

    // SPE   enable
    // MSTR  master
    // SPR0  f_osc / 16 = 4.9152 MHz / 16 = 307 kHz
    //
    // CPOL and CPHA are left at 0, which is SPI mode 0: sample on the
    // rising edge, data stable before it. The SSD1309, the IO board and
    // the MCP2515 all expect mode 0.
    SPCR = (1 << SPE) | (1 << MSTR) | (1 << SPR0);
    SPSR = 0;               // SPI2X off; doubling would give 614 kHz
}

void spi_deselect(void)
{
    CS_DISP_PORT |= (1 << PIN_CS_DISP);
    CS_IO_PORT   |= (1 << PIN_CS_IO);
    CS_CAN_PORT  |= (1 << PIN_CS_CAN);
}

void spi_select(spi_slave_t slave)
{
    // Deselect everything first. Two slaves driving MISO at once is a
    // bus fight, and doing this here makes that impossible by
    // construction rather than by discipline at every call site.
    spi_deselect();

    switch (slave)
    {
        case SPI_SLAVE_DISPLAY:
            CS_DISP_PORT &= ~(1 << PIN_CS_DISP);
            break;
        case SPI_SLAVE_IOBOARD:
            CS_IO_PORT &= ~(1 << PIN_CS_IO);
            break;
        case SPI_SLAVE_CAN:
            CS_CAN_PORT &= ~(1 << PIN_CS_CAN);
            break;
        default:
            break;          // SPI_SLAVE_NONE: leave all deselected
    }
}

uint8_t spi_transfer(uint8_t data)
{
    // Writing SPDR starts the transfer. SPIF is set when all eight bits
    // have been shifted, and reading SPDR clears it.
    SPDR = data;

    while (!(SPSR & (1 << SPIF)))
        ;

    return SPDR;
}

void spi_write(uint8_t data)
{
    spi_transfer(data);     // the byte shifted in is not wanted
}

uint8_t spi_read(void)
{
    // To clock eight bits in, eight bits must go out. 0xFF leaves the
    // line recessive and is what the MCP2515 and the IO board expect
    // during a read.
    return spi_transfer(0xFF);
}

void spi_write_bytes(const uint8_t *data, uint16_t length)
{
    for (uint16_t i = 0; i < length; i++)
        spi_transfer(data[i]);
}

void spi_read_bytes(uint8_t *buffer, uint16_t length)
{
    for (uint16_t i = 0; i < length; i++)
        buffer[i] = spi_transfer(0xFF);
}
