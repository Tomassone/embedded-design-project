#ifndef IOBOARD_H
#define IOBOARD_H

#include <stdint.h>

// ---------------------------------------------------------------------
// ioboard.h -- the gamepad board over SPI (exercise 4)
//
// A small microcontroller board carrying the touch pad, the slider, a
// joystick, the push buttons and six LEDs. It answers a one-byte
// command with a fixed number of data bytes.
//
// It is a microcontroller, not a shift register, so it needs time to
// prepare its answer: see the two delays in ioboard.c. Reading it
// faster than that returns stale or zero bytes.
// ---------------------------------------------------------------------

#define IOB_CMD_TOUCHPAD   0x01     // -> x, y, size
#define IOB_CMD_SLIDER     0x02     // -> x, size
#define IOB_CMD_JOYSTICK   0x03     // -> x, y, button
#define IOB_CMD_BUTTONS    0x04     // -> right, left, nav
#define IOB_CMD_LED        0x05     // <- led index, on/off
#define IOB_CMD_LED_PWM    0x06     // <- led index, duty 0..255
#define IOB_CMD_INFO       0x07     // -> 35 bytes of version text

#define IOB_INFO_LENGTH    35
#define IOB_LED_COUNT      6

typedef struct { uint8_t x; uint8_t y; uint8_t size; } ioboard_touchpad_t;
typedef struct { uint8_t x; uint8_t size; } ioboard_slider_t;
typedef struct { uint8_t x; uint8_t y; uint8_t btn; } ioboard_joystick_t;

// ---------------------------------------------------------------------
// Button state: three bytes, one per group, each bit a button. 1 means
// pressed. The unions let the same data be read either as a whole byte
// -- which is what the gamepad test screen displays -- or by name.
//
// The bit order below is the assumption this project makes about which
// silkscreen label sits in which bit. It is NOT taken from a document.
// "Calibration & Test" -> "Gamepad test", page 2 shows every bit live,
// so a button can be identified by pressing it. input.c then maps two
// of them:
//
//     SR6   (right, bit 5)  menu confirm
//     NAV_B (nav,   bit 0)  solenoid trigger, sent to node 2
// ---------------------------------------------------------------------
typedef struct __attribute__((packed)) {
    union {
        uint8_t right;
        struct {
            uint8_t R1:1; uint8_t R2:1; uint8_t R3:1;
            uint8_t R4:1; uint8_t R5:1; uint8_t R6:1;
        };
    };
    union {
        uint8_t left;
        struct {
            uint8_t L1:1; uint8_t L2:1; uint8_t L3:1; uint8_t L4:1;
            uint8_t L5:1; uint8_t L6:1; uint8_t L7:1;
        };
    };
    union {
        uint8_t nav;
        struct {
            uint8_t NB:1;   // button, pressed in
            uint8_t NR:1; uint8_t ND:1; uint8_t NL:1; uint8_t NU:1;
        };
    };
} ioboard_buttons_t;

ioboard_touchpad_t ioboard_read_touchpad(void);
ioboard_slider_t   ioboard_read_slider(void);

// The gamepad's own joystick. Not used: node 1 reads the joystick
// through its own MAX156 ADC instead, which is what exercise 3 asked
// for. Kept because it completes the board's interface.
ioboard_joystick_t ioboard_read_joystick(void);

// Read once per frame by input_poll(), which is the only caller --
// every other part of the program uses the cached copy from
// input_buttons() so the board is not polled twice.
ioboard_buttons_t  ioboard_read_buttons(void);

// LEDs 0..5, used by lightbar.c for the pulsing bar during a game.
void ioboard_set_led(uint8_t led, uint8_t on);
void ioboard_set_led_pwm(uint8_t led, uint8_t width);

// Version string. Unused; useful as a liveness check if the board ever
// stops answering.
void ioboard_read_info(uint8_t *buffer);

#endif // IOBOARD_H
