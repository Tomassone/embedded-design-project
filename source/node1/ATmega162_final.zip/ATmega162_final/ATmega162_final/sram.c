#include "sram.h"
#include "timer.h"
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <stdio.h>

// How many individual faults each phase reports before it stops
// printing and only counts. A completely dead SRAM produces 2048
// errors per phase, and at 9600 baud printing them all takes minutes.
#define MAX_REPORTED   8

void xmem_init(void)
{
    MCUCR |= (1 << SRE);
    SFIOR  = (1 << XMM2);
}

// ---------------------------------------------------------------------
// 16-bit xorshift. The test needs the same byte sequence twice -- once
// to write, once to verify -- which any seedable generator gives.
// avr-libc's rand() does too, but costs 178 bytes of flash for a
// quality nothing here depends on.
// ---------------------------------------------------------------------
static uint16_t rng;

static void rng_seed(uint16_t seed)
{
    rng = seed ? seed : 1;      // 0 is a fixed point of xorshift
}

static uint8_t rng_byte(void)
{
    rng ^= (uint16_t)(rng << 7);
    rng ^= (uint16_t)(rng >> 9);
    rng ^= (uint16_t)(rng << 8);
    return (uint8_t)rng;
}

uint16_t sram_test(void)
{
    volatile uint8_t *ext_ram = (uint8_t *)SRAM_BASE_ADDR;
    uint16_t write_errors = 0;
    uint16_t retrieval_errors = 0;

    // A seed that changes between runs exposes address- and
    // pattern-dependent faults that one fixed pattern can hide.
    uint16_t seed = timer_millis();

    printf_P(PSTR("SRAM test at %04X, %u bytes\r\n"),
             SRAM_BASE_ADDR, SRAM_SIZE);

    // Phase 1: write and read back immediately. This catches data bus
    // and control line faults.
    rng_seed(seed);
    for (uint16_t i = 0; i < SRAM_SIZE; i++)
    {
        uint8_t expected = rng_byte();

        ext_ram[i] = expected;

        uint8_t got = ext_ram[i];

        if (got != expected)
        {
            if (write_errors < MAX_REPORTED)
                printf_P(PSTR("  write %04X: %02X != %02X\r\n"),
                         SRAM_BASE_ADDR + i, got, expected);
            write_errors++;
        }
    }

    // Phase 2: read the whole block again. This catches cells that do
    // not hold their value, and address lines that alias.
    rng_seed(seed);
    for (uint16_t i = 0; i < SRAM_SIZE; i++)
    {
        uint8_t expected = rng_byte();
        uint8_t got = ext_ram[i];

        if (got != expected)
        {
            if (retrieval_errors < MAX_REPORTED)
                printf_P(PSTR("  recall %04X: %02X != %02X\r\n"),
                         SRAM_BASE_ADDR + i, got, expected);
            retrieval_errors++;
        }
    }

    printf_P(PSTR("SRAM test: %u write, %u recall errors\r\n"),
             write_errors, retrieval_errors);

    return write_errors + retrieval_errors;
}
