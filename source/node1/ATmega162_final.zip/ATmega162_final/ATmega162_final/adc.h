#ifndef ADC_H
#define ADC_H

#include <stdint.h>

// ---------------------------------------------------------------------
// adc.h -- MAX156 external ADC on the XMEM bus (exercise 3)
//
// The MAX156 is a 4-channel 8-bit ADC wired as a memory-mapped device:
// writing to ADC_BASE_ADDR starts a conversion, reading from it returns
// a result byte. Address decoding puts it in the window selected by
// A11 = 1 (see the schematic and the 74HC00 decoder), so any address in
// 0x1000..0x17FF reaches it.
//
// It has no internal oscillator. Timer1 generates its clock on PD5 --
// see adc_init().
// ---------------------------------------------------------------------

#define ADC_BASE_ADDR   0x1000

// Channel order in the array adc_read_all() fills. This is the order
// the MAX156 produces them in, not a free choice, and it is swapped
// relative to the joystick's X/Y labelling on the gamepad.
#define ADC_CH_JOY_Y    0
#define ADC_CH_JOY_X    1
// Channels 2 and 3 are the touch pads, unused by the game.

// Starts Timer1 as the ADC's clock source. Call once at startup.
void adc_init(void);

// DO NOT USE. Kept only because the lab's interface lists it.
//
// It assumes the channel can be selected by writing its number, which
// is true only when the MAX156's MODE pin is driven by software. On
// this board MODE is tied high, so the converter always digitises all
// four channels and hands them back on CONSECUTIVE reads. Selecting a
// channel is therefore impossible, and this function returns whichever
// channel happens to be next in that sequence.
//
// This cost a long debugging session: both joystick axes read the same
// value because each call consumed one step of the sequence. Use
// adc_read_all() instead.
uint8_t adc_read_channel(uint8_t channel);

// Starts one conversion and reads all four channels into results[0..3].
// This is the only correct way to read the MAX156 on this board.
void adc_read_all(uint8_t *results);

#endif // ADC_H
