#ifndef OLED_H
#define OLED_H

#include <stdint.h>

// ---------------------------------------------------------------------
// oled.h -- SSD1309 128x64 OLED over 4-wire SPI (exercise 4)
//
// Memory layout. The panel is organised as 8 PAGES of 128 columns. One
// byte is 8 vertical pixels of one column, bit 0 at the top:
//
//     byte at (page p, column x)   covers   y = p*8 .. p*8+7
//     bit 0 -> topmost of those rows,  bit 7 -> bottom
//
// Why a framebuffer. 4-wire SPI is write-only -- there is no MISO from
// the panel, so its RAM cannot be read back. Changing one pixel would
// otherwise mean rewriting a whole byte without knowing the other seven
// bits. So all drawing happens in a buffer here and oled_flush() sends
// the whole thing.
//
// Where it lives. OLED_BUFFER_ADDR puts the 1024-byte buffer in the
// EXTERNAL SRAM. The ATmega162 has only 1 KiB of internal RAM, which
// the buffer would consume entirely. xmem_init() must therefore run
// before oled_init().
//
// The D/C and RESET pins are plain GPIOs on PB1 and PB0, handled in
// oled.c.
// ---------------------------------------------------------------------

#define OLED_WIDTH    128
#define OLED_HEIGHT   64
#define OLED_PAGES    (OLED_HEIGHT / 8)
#define OLED_BUF_SIZE (OLED_WIDTH * OLED_PAGES)     // 1024 bytes

// Start of the framebuffer in external SRAM. Shares the SRAM window
// with sram_test(), which overwrites it -- see sram.h.
#define OLED_BUFFER_ADDR 0x1800

// Hardware reset, then the full initialisation sequence. Requires
// spi_init() and xmem_init() to have run.
void oled_init(void);

// Pulses the RESET pin. oled_init() calls this; exposed for recovery.
void oled_reset(void);

// ---- Drawing: these only touch the framebuffer, never the panel -----
void oled_clear(void);
void oled_set_pixel(uint8_t x, uint8_t y, uint8_t on);
void oled_fill_rect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t on);
void oled_draw_hline(uint8_t x, uint8_t y, uint8_t length, uint8_t on);
void oled_draw_vline(uint8_t x, uint8_t y, uint8_t length, uint8_t on);

// Sends the whole framebuffer to the panel. 1024 bytes at 307 kHz is
// about 27 ms, which is the single largest item in the 50 ms frame --
// so call it once per frame, not once per change.
void oled_flush(void);

// Low level, for the init sequence. D/C low = command, high = data.
void oled_write_command(uint8_t cmd);
void oled_write_data(uint8_t data);     // unused: oled_flush() is faster

#endif // OLED_H
