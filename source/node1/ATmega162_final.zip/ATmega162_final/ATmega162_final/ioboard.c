#ifndef F_CPU
#define F_CPU 4915200UL
#endif

#include "ioboard.h"
#include "spi.h"
#include <util/delay.h>

// ---------------------------------------------------------------------
// Timing the board requires. These are the reason every access goes
// through one helper rather than calling spi_transfer() directly.
//
// The board runs its own firmware: it has to receive the command,
// decide what was asked, sample the hardware and load its SPI data
// register. Clocking the first data byte out before that is finished
// returns whatever was left in the register.
// ---------------------------------------------------------------------
#define IOB_CMD_TO_DATA_US   40     // command byte -> first data byte
#define IOB_DATA_TO_DATA_US   2     // between consecutive data bytes

// One complete exchange: assert CS, send the command, wait, then clock
// `length` bytes in and/or out.
//
// tx = 0 sends zeros (a pure read), rx = 0 discards what comes back
// (a pure write). Both directions are always clocked, because SPI has
// no way to do otherwise.
static void ioboard_transaction(uint8_t cmd, const uint8_t *tx,
                                uint8_t *rx, uint8_t length)
{
    spi_select(SPI_SLAVE_IOBOARD);

    spi_transfer(cmd);
    _delay_us(IOB_CMD_TO_DATA_US);

    for (uint8_t i = 0; i < length; i++)
    {
        uint8_t out = (tx != 0) ? tx[i] : 0x00;
        uint8_t in  = spi_transfer(out);

        if (rx != 0)
            rx[i] = in;

        // No delay after the last byte: CS is about to go high anyway,
        // and the frame budget is tight enough to care. This saves
        // 2 us per transaction, which matters because the buttons are
        // read every 50 ms frame.
        if (i < length - 1)
            _delay_us(IOB_DATA_TO_DATA_US);
    }

    spi_deselect();
}

ioboard_touchpad_t ioboard_read_touchpad(void)
{
    uint8_t buf[3];
    ioboard_touchpad_t t;
    ioboard_transaction(IOB_CMD_TOUCHPAD, 0, buf, 3);
    t.x = buf[0]; t.y = buf[1]; t.size = buf[2];
    return t;
}

ioboard_slider_t ioboard_read_slider(void)
{
    uint8_t buf[2];
    ioboard_slider_t s;
    ioboard_transaction(IOB_CMD_SLIDER, 0, buf, 2);
    s.x = buf[0]; s.size = buf[1];
    return s;
}

ioboard_joystick_t ioboard_read_joystick(void)
{
    uint8_t buf[3];
    ioboard_joystick_t j;
    ioboard_transaction(IOB_CMD_JOYSTICK, 0, buf, 3);
    j.x = buf[0]; j.y = buf[1]; j.btn = buf[2];
    return j;
}

ioboard_buttons_t ioboard_read_buttons(void)
{
    uint8_t buf[3];
    ioboard_buttons_t b;

    // The three bytes arrive in this order: right, left, nav.
    ioboard_transaction(IOB_CMD_BUTTONS, 0, buf, 3);
    b.right = buf[0]; b.left = buf[1]; b.nav = buf[2];
    return b;
}

void ioboard_set_led(uint8_t led, uint8_t on)
{
    // Silently ignore an out-of-range index. The board's behaviour on
    // one is not documented, so it is not worth finding out.
    if (led >= IOB_LED_COUNT) return;

    uint8_t buf[2] = { led, on };
    ioboard_transaction(IOB_CMD_LED, buf, 0, 2);
}

void ioboard_set_led_pwm(uint8_t led, uint8_t width)
{
    if (led >= IOB_LED_COUNT) return;

    uint8_t buf[2] = { led, width };
    ioboard_transaction(IOB_CMD_LED_PWM, buf, 0, 2);
}

void ioboard_read_info(uint8_t *buffer)
{
    ioboard_transaction(IOB_CMD_INFO, 0, buffer, IOB_INFO_LENGTH);
}
