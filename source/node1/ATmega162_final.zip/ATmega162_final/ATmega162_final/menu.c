#include "menu.h"
#include "oled.h"
#include "oled_text.h"
#include <avr/pgmspace.h>

// Entries start on text line 2, leaving line 0 for the title and
// line 1 as a gap. That leaves 6 visible entries.
#define MENU_FIRST_LINE     2
#define MENU_VISIBLE        (OLED_TEXT_LINES - MENU_FIRST_LINE)

// Prints a flash string and pads it with spaces to the end of the line,
// so inverted text becomes a full-width bar.
static void print_padded_P(const char *str_P, uint8_t start_column)
{
    uint8_t column = start_column;
    char c;

    while ((c = pgm_read_byte(str_P++)) != '\0' && column < OLED_TEXT_COLUMNS)
    {
        oled_putchar(c);
        column++;
    }

    while (column < OLED_TEXT_COLUMNS)
    {
        oled_putchar(' ');
        column++;
    }
}

void menu_draw_title(const char *title_P)
{
    oled_goto(0, 0);
    oled_set_inverted(1);
    oled_putchar(' ');
    print_padded_P(title_P, 1);
    oled_set_inverted(0);
}

void screen_begin(const char *title_P)
{
    oled_clear();
    menu_draw_title(title_P);
}

void screen_end(const char *footer_P)
{
    if (footer_P != 0)
    {
        oled_goto(OLED_TEXT_LINES - 1, 0);
        oled_print_P(footer_P);
    }

    oled_flush();
}

void menu_draw(const menu_nav_t *nav)
{
    const menu_t *menu = nav->menu;

    oled_clear();
    menu_draw_title(menu->title_P);

    for (uint8_t row = 0; row < MENU_VISIBLE; row++)
    {
        uint8_t index = nav->first_visible + row;
        if (index >= menu->count)
            break;

        // The item array itself is in flash, so the pointer to each
        // string has to be read out of flash before the string can be.
        const char *item_P = (const char *)pgm_read_word(&menu->items_P[index]);

        oled_goto(MENU_FIRST_LINE + row, 0);

        if (index == nav->selected)
        {
            oled_set_inverted(1);
            oled_putchar('>');
            oled_putchar(' ');
            print_padded_P(item_P, 2);
            oled_set_inverted(0);
        }
        else
        {
            oled_putchar(' ');
            oled_putchar(' ');
            print_padded_P(item_P, 2);
        }
    }

    // Scroll hints when the list is longer than the screen.
    if (nav->first_visible > 0)
        oled_draw_char(OLED_WIDTH - OLED_CHAR_WIDTH, MENU_FIRST_LINE * OLED_CHAR_HEIGHT, '^');
    if (nav->first_visible + MENU_VISIBLE < menu->count)
        oled_draw_char(OLED_WIDTH - OLED_CHAR_WIDTH, (OLED_TEXT_LINES - 1) * OLED_CHAR_HEIGHT, 'v');

    oled_flush();
}

void menu_open(menu_nav_t *nav, const menu_t *menu)
{
    nav->menu = menu;
    nav->selected = 0;
    nav->first_visible = 0;
    menu_draw(nav);
}

int8_t menu_handle(menu_nav_t *nav, input_event_t event)
{
    uint8_t count = nav->menu->count;

    switch (event)
    {
        case INPUT_UP:
            // Wrap from the first entry to the last.
            nav->selected = (nav->selected == 0) ? count - 1 : nav->selected - 1;
            break;

        case INPUT_DOWN:
            nav->selected = (nav->selected + 1 >= count) ? 0 : nav->selected + 1;
            break;

        // Joystick right confirms, as well as SR6. Without this a
        // wrongly mapped menu button locks the whole UI: nothing can be
        // selected, so the gamepad test -- the one screen that
        // identifies the right button -- cannot be reached either.
        case INPUT_SELECT:
        case INPUT_RIGHT:
            return (int8_t)nav->selected;

        case INPUT_LEFT:
            return MENU_BACK;

        default:
            return MENU_NONE;
    }

    // Keep the selection inside the visible window.
    if (nav->selected < nav->first_visible)
        nav->first_visible = nav->selected;
    else if (nav->selected >= nav->first_visible + MENU_VISIBLE)
        nav->first_visible = nav->selected - MENU_VISIBLE + 1;

    menu_draw(nav);
    return MENU_NONE;
}
