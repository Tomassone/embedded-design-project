#ifndef LIVEGAME_H
#define LIVEGAME_H

#include <stdint.h>

// ---------------------------------------------------------------------
// Live play: the real ping-pong machine on node 2.
//
// Node 1 contributes only input and the scoreboard. The joystick goes
// out over CAN -- x drives the cart through node 2's PID loop, y the
// servo -- and NAV_B goes out on bit 0, where node 2 fires the solenoid
// with its own cooldown. Goals come back from node 2's IR beam.
//
// So there is no physics here, unlike game.c. What this module owns is
// the rule set: three goals end the round, and the score is how long
// the player survived.
// ---------------------------------------------------------------------

#define LIVE_MAX_GOALS   3

typedef enum {
    LIVE_ARMING,        // STOP sent, waiting before START
    LIVE_RUNNING,
    LIVE_OVER
} live_status_t;

// Sends STOP to clear node 2's score and begins the arming delay.
void live_start(uint16_t now);

// Advances one frame. Sends START when arming finishes, counts the
// playing time and reads the goal count out of the node 2 state.
live_status_t live_update(uint16_t now);

// Resumes after a pause: sends START again and restarts the clock from
// now, so the paused time is not counted as playing time.
void live_resume(uint16_t now);

// Renders the scoreboard. joy_x / joy_y are drawn as cart and servo
// position bars, so the screen shows what is actually being sent.
void live_draw(int16_t joy_x, int16_t joy_y, uint8_t fire_level,
               uint8_t link_ok);

// Seconds survived -- this is what goes into the highscore table.
uint16_t live_get_seconds(void);

uint8_t live_get_goals(void);

#endif // LIVEGAME_H
