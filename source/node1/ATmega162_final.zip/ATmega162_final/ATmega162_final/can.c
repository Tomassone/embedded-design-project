#include "can.h"
#include "mcp2515.h"
#include <avr/io.h>
#include <avr/interrupt.h>

// ---------------------------------------------------------------------
// Bit timing for a 16 MHz crystal on the MCP2515.
//
// One bit = 16 time quanta (TQ):
//   SyncSeg 1 + PropSeg 2 + PhaseSeg1 7 + PhaseSeg2 6
//   Sample point after 10 of 16 TQ = 62.5 %
//
//   TQ       = 2 * (BRP + 1) / F_OSC = 2 * 4 / 16 MHz = 0.5 us
//   Bit time = 16 * 0.5 us = 8 us  ->  125 kbit/s
//
// The register fields store (value - 1), hence PHSEG1 = 6 for 7 TQ.
//
// Node 2 must match this EXACTLY -- not just the bit rate, but the
// number of TQ per segment, so both nodes sample at the same point
// in the bit. With a 4.9152 MHz crystal the same CNF values would
// give 38.4 kbit/s instead.
// ---------------------------------------------------------------------
#define CAN_CNF1   0x03     // SJW = 1 TQ, BRP = 3
#define CAN_CNF2   0xB1     // BTLMODE = 1, SAM = 0, PHSEG1 = 7 TQ, PRSEG = 2 TQ
#define CAN_CNF3   0x05     // PHSEG2 = 6 TQ

// Set by the INT0 interrupt when the MCP2515 pulls its INT line low.
// The ISR does NOT talk to the controller itself: the SPI bus is shared
// with the display and the IO board, and an SPI transfer started from
// an interrupt could land in the middle of an ongoing display flush.
static volatile uint8_t rx_pending = 0;

ISR(INT0_vect)
{
    rx_pending = 1;
}

static void interrupt_init(void)
{
    DDRD &= ~(1 << PD2);                 // CAN_INT as input

    // Falling edge on INT0. MCUCR also holds SRE for the external
    // memory interface, so only the ISC0x bits may be touched.
    MCUCR = (MCUCR & ~((1 << ISC01) | (1 << ISC00))) | (1 << ISC01);

    GIFR = (1 << INTF0);                 // discard a stale flag
    GICR |= (1 << INT0);
}

// Writes the timing and filter configuration. Only valid while the
// controller is in configuration mode.
static void configure(void)
{
    mcp2515_write(MCP_CNF1, CAN_CNF1);
    mcp2515_write(MCP_CNF2, CAN_CNF2);
    mcp2515_write(MCP_CNF3, CAN_CNF3);

    // Accept every message in both receive buffers. RXB0 rolls over
    // into RXB1 when it is still full, so a burst of two survives.
    mcp2515_write(MCP_RXB0CTRL, MCP_RXM_ANY | MCP_BUKT);
    mcp2515_write(MCP_RXB1CTRL, MCP_RXM_ANY);

    // Interrupt on reception into either buffer.
    mcp2515_write(MCP_CANINTF, 0x00);
    mcp2515_write(MCP_CANINTE, MCP_RX0IF | MCP_RX1IF);
}

uint8_t can_init(can_mode_t mode)
{
    if (mcp2515_init() != 0)
        return 1;

    // mcp2515_init() leaves the controller in configuration mode,
    // which is the only mode where the CNF registers are writable.
    configure();

    interrupt_init();

    return can_set_mode(mode);
}

uint8_t can_set_mode(can_mode_t mode)
{
    uint8_t target = (mode == CAN_MODE_LOOPBACK) ? MCP_MODE_LOOPBACK
                                                 : MCP_MODE_NORMAL;

    return mcp2515_set_mode(target) ? 2 : 0;
}

uint8_t can_send(const can_message_t *msg)
{
    // Previous message still waiting for the bus?
    if (mcp2515_read(MCP_TXB0CTRL) & MCP_TXREQ)
        return 1;

    uint8_t length = (msg->length > CAN_MAX_DATA) ? CAN_MAX_DATA : msg->length;

    // TX buffer layout from TXB0SIDH onwards:
    //   SIDH  SIDL  EID8  EID0  DLC  D0..D7
    // Standard 11-bit ID: SIDH holds ID[10:3], SIDL bits 7..5 hold
    // ID[2:0]. EXIDE (SIDL bit 3) stays 0 = standard frame.
    uint8_t buffer[5 + CAN_MAX_DATA];

    buffer[0] = (uint8_t)(msg->id >> 3);
    buffer[1] = (uint8_t)((msg->id & 0x07) << 5);
    buffer[2] = 0;
    buffer[3] = 0;
    buffer[4] = length;                      // RTR bit 0 = data frame

    for (uint8_t i = 0; i < length; i++)
        buffer[5 + i] = msg->data[i];

    mcp2515_write_block(MCP_TXB0SIDH, buffer, 5 + length);
    mcp2515_request_to_send(MCP_RTS_TX0);

    return 0;
}

// Reads one receive buffer into msg and releases it.
static void read_rx_buffer(uint8_t sidh_address, uint8_t flag, can_message_t *msg)
{
    uint8_t buffer[5 + CAN_MAX_DATA];

    mcp2515_read_block(sidh_address, buffer, sizeof(buffer));

    msg->id = ((uint16_t)buffer[0] << 3) | (buffer[1] >> 5);
    msg->length = buffer[4] & 0x0F;
    if (msg->length > CAN_MAX_DATA)
        msg->length = CAN_MAX_DATA;

    for (uint8_t i = 0; i < msg->length; i++)
        msg->data[i] = buffer[5 + i];

    // Clearing the flag frees the buffer for the next message and
    // releases the INT line once no other flag is set.
    mcp2515_bit_modify(MCP_CANINTF, flag, 0x00);
}

uint8_t can_receive(can_message_t *msg)
{
    rx_pending = 0;

    // READ STATUS gives both RX flags in one short transfer:
    // bit 0 = RX0IF, bit 1 = RX1IF.
    uint8_t status = mcp2515_read_status();

    if (status & MCP_RX0IF)
    {
        read_rx_buffer(MCP_RXB0SIDH, MCP_RX0IF, msg);
        return 1;
    }

    if (status & MCP_RX1IF)
    {
        read_rx_buffer(MCP_RXB1SIDH, MCP_RX1IF, msg);
        return 1;
    }

    return 0;
}

uint8_t can_rx_pending(void)
{
    return rx_pending;
}

void can_get_errors(can_error_t *err)
{
    uint8_t eflg = mcp2515_read(MCP_EFLG);

    err->tx_errors     = mcp2515_read(MCP_TEC);
    err->rx_errors     = mcp2515_read(MCP_REC);
    err->bus_off       = (eflg & MCP_TXBO) ? 1 : 0;
    err->error_passive = (eflg & (MCP_TXEP | MCP_RXEP)) ? 1 : 0;
    err->rx_overflow   = (eflg & (MCP_RX0OVR | MCP_RX1OVR)) ? 1 : 0;

    // Overflow flags are sticky: clear them so the next read reports
    // only new overflows.
    if (err->rx_overflow)
        mcp2515_bit_modify(MCP_EFLG, MCP_RX0OVR | MCP_RX1OVR, 0x00);
}

void can_abort_tx(void)
{
    // ABAT cancels every pending transmission. It has to be cleared
    // again, otherwise the controller refuses all further sends.
    mcp2515_bit_modify(MCP_CANCTRL, MCP_ABAT, MCP_ABAT);
    mcp2515_bit_modify(MCP_CANCTRL, MCP_ABAT, 0x00);
}

uint8_t can_recover(void)
{
    // A reset is the reliable way out of bus-off: it zeroes the error
    // counters. The configuration has to be written again afterwards,
    // since the reset restores the register defaults.
    if (mcp2515_init() != 0)
        return 1;

    configure();

    return can_set_mode(CAN_MODE_NORMAL);
}
