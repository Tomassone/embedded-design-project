#include "input.h"

// ---------------------------------------------------------------------
// Two IO board buttons, read over SPI with command 0x04. The reply is
// three bytes -- right, left, nav -- laid out like this:
//
//   right : [ -  -  SR6 SR5 SR4 SR3 SR2 SR1 ]
//   left  : [ -  SL7 SL6 SL5 SL4 SL3 SL2 SL1 ]
//   nav   : [ -  -  -  NAV_U NAV_L NAV_D NAV_R NAV_B ]
//
//   MENU  = SR6    confirms a menu entry, pauses a running game
//   FIRE  = NAV_B  triggers the solenoid on node 2
//
// If a button turns out to sit elsewhere on your board, open
// "Calibration & Test" -> "Gamepad test", go to page 2, press it and
// read off which name lights up. Then correct the four defines below.
// Page 2 is left with the joystick, not with SR6, so SR6 itself can be
// tested there.
// ---------------------------------------------------------------------
#define BTN_BYTE_RIGHT      0
#define BTN_BYTE_LEFT       1
#define BTN_BYTE_NAV        2

#define MENU_BYTE           BTN_BYTE_RIGHT
#define MENU_MASK           0x20        // SR6 = bit 5 of the right byte

#define FIRE_BYTE           BTN_BYTE_NAV
#define FIRE_MASK           0x01        // NAV_B = bit 0 of the nav byte

// Navigation thresholds, in joystick output units (-90..+90).
// Press and release differ so a stick held near the threshold does not
// fire a stream of events.
#define NAV_PRESS_THRESHOLD      50
#define NAV_RELEASE_THRESHOLD    30

#define NAV_REPEAT_DELAY_MS      400
#define NAV_REPEAT_RATE_MS       150

static ioboard_buttons_t buttons;    // last read, shared with the test screen

static uint8_t menu_stable, menu_last_raw;
static uint8_t fire_stable, fire_last_raw;
static uint8_t fire_edge;            // set on press, cleared by reading

static input_event_t nav_held = INPUT_NONE;
static uint16_t nav_next_repeat;

static uint8_t byte_of(uint8_t which)
{
    switch (which)
    {
        case BTN_BYTE_RIGHT: return buttons.right;
        case BTN_BYTE_LEFT:  return buttons.left;
        default:             return buttons.nav;
    }
}

// Debounce over two consecutive samples. Returns 1 on the press edge.
static uint8_t debounce(uint8_t raw, uint8_t *last_raw, uint8_t *stable)
{
    uint8_t pressed = 0;

    if (raw == *last_raw && raw != *stable)
    {
        *stable = raw;
        if (raw)
            pressed = 1;
    }

    *last_raw = raw;
    return pressed;
}

void input_init(void)
{
    // Take the current state as the starting point, so a button held
    // during power-up does not register as a press.
    // Requires spi_init() to have run -- the buttons are read over SPI.
    buttons = ioboard_read_buttons();

    menu_last_raw = (byte_of(MENU_BYTE) & MENU_MASK) ? 1 : 0;
    menu_stable   = menu_last_raw;

    fire_last_raw = (byte_of(FIRE_BYTE) & FIRE_MASK) ? 1 : 0;
    fire_stable   = fire_last_raw;

    fire_edge = 0;
}

// Direction the stick currently points, with hysteresis: a held
// direction stays active until the stick falls back below the release
// threshold on that axis.
static input_event_t stick_direction(int16_t x, int16_t y)
{
    switch (nav_held)
    {
        case INPUT_UP:    if (y >=  NAV_RELEASE_THRESHOLD) return INPUT_UP;    break;
        case INPUT_DOWN:  if (y <= -NAV_RELEASE_THRESHOLD) return INPUT_DOWN;  break;
        case INPUT_RIGHT: if (x >=  NAV_RELEASE_THRESHOLD) return INPUT_RIGHT; break;
        case INPUT_LEFT:  if (x <= -NAV_RELEASE_THRESHOLD) return INPUT_LEFT;  break;
        default: break;
    }

    int16_t ax = (x < 0) ? -x : x;
    int16_t ay = (y < 0) ? -y : y;

    if (ax < NAV_PRESS_THRESHOLD && ay < NAV_PRESS_THRESHOLD)
        return INPUT_NONE;

    if (ax > ay)
        return (x > 0) ? INPUT_RIGHT : INPUT_LEFT;
    else
        return (y > 0) ? INPUT_UP : INPUT_DOWN;
}

input_event_t input_poll(uint16_t now, int16_t joy_x, int16_t joy_y)
{
    input_event_t select_event = INPUT_NONE;
    input_event_t nav_event = INPUT_NONE;

    // One SPI transaction per frame serves both buttons and the test
    // screen. The IO board reply is slow (40 us command-to-data), so
    // reading it twice would be wasteful.
    buttons = ioboard_read_buttons();

    if (debounce((byte_of(MENU_BYTE) & MENU_MASK) ? 1 : 0,
                 &menu_last_raw, &menu_stable))
        select_event = INPUT_SELECT;

    if (debounce((byte_of(FIRE_BYTE) & FIRE_MASK) ? 1 : 0,
                 &fire_last_raw, &fire_stable))
        fire_edge = 1;

    // --- Navigation: fire on push, then auto-repeat while held.
    input_event_t dir = stick_direction(joy_x, joy_y);

    if (dir != nav_held)
    {
        nav_held = dir;
        if (dir != INPUT_NONE)
        {
            nav_event = dir;
            nav_next_repeat = now + NAV_REPEAT_DELAY_MS;
        }
    }
    else if (dir != INPUT_NONE && (int16_t)(now - nav_next_repeat) >= 0)
    {
        nav_event = dir;
        nav_next_repeat = now + NAV_REPEAT_RATE_MS;
    }

    return (select_event != INPUT_NONE) ? select_event : nav_event;
}

uint8_t input_select_state(void)
{
    return menu_stable;
}

uint8_t input_fire_state(void)
{
    return fire_stable;
}

uint8_t input_fire_pressed(void)
{
    uint8_t e = fire_edge;
    fire_edge = 0;
    return e;
}

const ioboard_buttons_t *input_buttons(void)
{
    return &buttons;
}
