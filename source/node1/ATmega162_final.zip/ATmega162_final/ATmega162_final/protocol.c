#include "protocol.h"
#include "can.h"

static node2_state_t node2;

// ---------------------------------------------------------------------
// Command queue.
//
// The MCP2515 has ONE transmit buffer, and node 1 streams joystick
// frames at 20 Hz. The two kinds of traffic are not equally important:
//
//   Joystick position is STATE. If a frame cannot go out, the next one
//   50 ms later carries a newer position and nothing is lost.
//
//   A game command is an EVENT. Dropping GAME_CMD_START leaves node 2
//   in NODE2_IDLE, where it ignores the joystick and will not fire the
//   solenoid -- the node 1 side looks perfectly healthy while nothing
//   on the machine responds.
//
// So commands are queued and retried until they are actually accepted,
// and a joystick send defers while anything is pending. Four entries is
// more than enough: the deepest real burst is STOP followed by START.
// ---------------------------------------------------------------------
#define CMD_QUEUE_LEN   4
#define CMD_QUEUE_MASK  (CMD_QUEUE_LEN - 1)

static uint8_t cmd_queue[CMD_QUEUE_LEN];
static uint8_t cmd_head, cmd_tail;      // free-running, masked on use

static uint8_t cmd_depth(void)
{
    return (uint8_t)(cmd_tail - cmd_head);
}

// Tries to hand the oldest queued command to the controller.
// Returns the number of commands still waiting afterwards.
static uint8_t flush_commands(void)
{
    if (cmd_depth() == 0)
        return 0;

    can_message_t msg;

    msg.id = CAN_ID_GAME_CMD;
    msg.length = 1;
    msg.data[0] = cmd_queue[cmd_head & CMD_QUEUE_MASK];

    if (can_send(&msg) == 0)
        cmd_head++;

    return cmd_depth();
}

uint8_t protocol_tick(void)
{
    return flush_commands();
}

uint8_t protocol_send_command(game_cmd_t cmd)
{
    if (cmd_depth() >= CMD_QUEUE_LEN)
        return 1;               // queue full, caller may retry

    cmd_queue[cmd_tail & CMD_QUEUE_MASK] = (uint8_t)cmd;
    cmd_tail++;

    // Try immediately, so a command sent from a state with no further
    // joystick traffic still goes out without waiting for the next tick.
    flush_commands();

    return 0;
}

uint8_t protocol_cmd_pending(void)
{
    return cmd_depth();
}

uint8_t protocol_send_joystick(int8_t x, int8_t y, uint8_t buttons)
{
    // A queued command outranks periodic state. Returning
    // PROTOCOL_TX_DEFERRED rather than 1 matters: the caller must not
    // treat this as a stuck transmission and abort it, because what is
    // occupying the buffer is the command we want delivered.
    if (flush_commands() != 0)
        return PROTOCOL_TX_DEFERRED;

    can_message_t msg;

    msg.id = CAN_ID_JOYSTICK;
    msg.length = 3;
    msg.data[0] = (uint8_t)x;       // two's complement survives the cast
    msg.data[1] = (uint8_t)y;
    msg.data[2] = buttons;

    return can_send(&msg);
}

uint8_t protocol_poll(void)
{
    can_message_t msg;

    if (!can_receive(&msg))
        return 0;

    switch (msg.id)
    {
        case CAN_ID_GOAL:
            if (msg.length >= 1)
                node2.score = msg.data[0];
            node2.seen = 1;
            break;

        case CAN_ID_NODE2_STATUS:
            if (msg.length >= 1)
                node2.status = msg.data[0];
            node2.seen = 1;
            break;

        default:
            // Unknown ID. In normal mode node 1 also receives its own
            // bus traffic only if another node transmits it, so this
            // is simply a message type we do not handle yet.
            break;
    }

    return 1;
}

const node2_state_t *protocol_node2(void)
{
    return &node2;
}

void protocol_reset_state(void)
{
    node2.score = 0;
    node2.status = NODE2_IDLE;
    node2.seen = 0;
}
