#ifndef UART_H
#define UART_H

#include <stdio.h>
#include <stdint.h>

// ---------------------------------------------------------------------
// uart.h -- USART0 with printf support (exercise 1)
//
// Interrupt driven in both directions, with a ring buffer each way, so
// printf() does not block the state machine while bytes go out at
// 9600 baud. The MAX233 level shifter converts the 5 V logic levels to
// RS-232 for the DB9 connector; it needs no configuration.
//
// uart_init() attaches this port to stdout and stdin, which is what
// makes printf(), printf_P() and scanf() work.
// ---------------------------------------------------------------------

// The stream stdout and stdin are pointed at. Exposed because the
// FILE object has to live somewhere with static storage.
extern FILE uart_stream;

// Sets the baud rate, enables the transmitter, the receiver and the
// receive interrupt, then redirects stdout and stdin here.
void uart_init(void);

// 1 if at least one received byte is waiting in the ring buffer.
// Use this before uart_getchar(), which otherwise blocks.
uint8_t uart_available(void);

// The two stdio hooks. Call them through printf()/getchar() rather than
// directly.
//
// uart_putchar() expands '\n' to "\r\n" and blocks only when the
// transmit buffer is full. uart_getchar() blocks until a byte arrives.
int uart_putchar(char c, FILE *stream);
int uart_getchar(FILE *stream);

#endif // UART_H
