#ifndef OLED_TEXT_H
#define OLED_TEXT_H

#include <stdint.h>

// ---------------------------------------------------------------------
// oled_text.h -- 5x7 ASCII font and a text cursor on top of oled.c
//
// Two ways to put text on the screen:
//
//   oled_draw_*  pixel coordinates, for anything positioned freely
//   oled_goto + oled_print*/printf  a character grid, like a terminal
//
// Everything here writes into the framebuffer only. Nothing appears
// until oled_flush() is called.
//
// The font lives in PROGMEM: 95 printable characters at 5 bytes each is
// 475 bytes, which would be half the internal RAM if it were a normal
// array.
// ---------------------------------------------------------------------

#define FONT_WIDTH         5        // bytes (columns) stored per glyph
#define FONT_HEIGHT        7        // pixels used of the 8 in each byte
#define FONT_FIRST         0x20     // space
#define FONT_LAST          0x7E     // tilde

// One blank column after each glyph, so characters do not touch. The
// 8th pixel row is likewise left blank as the line gap.
#define OLED_CHAR_WIDTH    6
#define OLED_CHAR_HEIGHT   8

// The text grid: 128 / 6 = 21 columns, 64 / 8 = 8 lines.
//
// 21 is a hard limit. Anything longer is wrapped by oled_putchar(), so
// a format string that overruns it reappears on the next line and
// overwrites whatever was there.
#define OLED_TEXT_COLUMNS  21
#define OLED_TEXT_LINES    8

// ---- Free positioning, in pixels ------------------------------------
void oled_draw_char(uint8_t x, uint8_t y, char c);
void oled_draw_string(uint8_t x, uint8_t y, const char *str);
void oled_draw_string_P(uint8_t x, uint8_t y, const char *str_P);

// ---- Cursor, in character cells -------------------------------------
void oled_home(void);
void oled_goto(uint8_t line, uint8_t column);
void oled_goto_line(uint8_t line);
void oled_goto_column(uint8_t column);
void oled_clear_line(uint8_t line);

// ---- Writing at the cursor ------------------------------------------
// Handles '\n' and '\r', and wraps at column 21.
void oled_putchar(char c);
void oled_print(const char *str);

// The _P variants take a string in flash, from PSTR() or a PROGMEM
// array. Almost all text in this project uses these: a RAM copy of
// every string would not fit in 1 KiB.
void oled_print_P(const char *str_P);
void oled_printf_P(const char *fmt_P, ...);

// Inverts subsequent characters -- white on black. Used for title bars
// and the selected menu row. Stays on until switched off.
void oled_set_inverted(uint8_t on);

#endif // OLED_TEXT_H
