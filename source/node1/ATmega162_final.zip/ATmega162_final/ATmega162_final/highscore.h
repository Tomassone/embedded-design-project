#ifndef HIGHSCORE_H
#define HIGHSCORE_H

#include <stdint.h>

#define HIGHSCORE_COUNT  5

// Two separate tables, because the two games do not measure the same
// thing. Live play records how long the player survived in seconds;
// the console game records Pong points. Ranking them in one list would
// be meaningless.
typedef enum {
    HS_LIVE    = 0,
    HS_CONSOLE = 1,
    HS_LISTS   = 2
} highscore_list_t;

// Highscores are kept in the ATmega162's internal EEPROM, so they
// survive power cycles. Loads them, or initialises the tables on first
// use. Call once at startup.
void highscore_init(void);

// Score at a rank, 0 = best.
uint16_t highscore_get(highscore_list_t list, uint8_t rank);

// Enters a score if it makes the table. Returns its rank (0 = best),
// or -1 if it did not qualify. Higher is better in both lists.
int8_t highscore_submit(highscore_list_t list, uint16_t score);

// Clears both tables.
void highscore_reset(void);

#endif // HIGHSCORE_H
