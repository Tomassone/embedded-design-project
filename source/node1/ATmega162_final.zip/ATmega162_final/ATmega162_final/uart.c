#include "uart.h"
#include <avr/io.h>
#include <avr/interrupt.h>

#ifndef F_CPU
#define F_CPU 4915200UL
#endif

#ifndef BAUD
#define BAUD 9600UL
#endif

// ---------------------------------------------------------------------
// Baud rate divider for asynchronous normal mode (U2X = 0):
//
//     UBRR = F_CPU / (16 * baud) - 1
//
// 4.9152 MHz is a crystal chosen for exactly this: 4915200 / (16 * 9600)
// is 32 with no remainder, so UBRR = 31 and the baud rate error is
// zero. A 4 MHz or 8 MHz crystal cannot hit 9600 exactly.
// ---------------------------------------------------------------------
#define UBRR_VALUE ((F_CPU / (16UL * BAUD)) - 1)

// Ring buffer sizes. Powers of two would let the compiler use a mask
// instead of the modulo below, but these are small enough not to matter
// at 50 ms frames.
#define RX_BUF_SIZE 32
#define TX_BUF_SIZE 64

// head = where the producer writes, tail = where the consumer reads.
// Each buffer has exactly one writer and one reader, which is what
// makes them safe without disabling interrupts:
//   rx: the ISR moves head, the main loop moves tail
//   tx: the main loop moves head, the ISR moves tail
// volatile because the other side of each pair is an interrupt.
static volatile uint8_t rx_buf[RX_BUF_SIZE];
static volatile uint8_t rx_head = 0;
static volatile uint8_t rx_tail = 0;

static volatile uint8_t tx_buf[TX_BUF_SIZE];
static volatile uint8_t tx_head = 0;
static volatile uint8_t tx_tail = 0;

FILE uart_stream;

void uart_init(void)
{
    UBRR0H = (uint8_t)(UBRR_VALUE >> 8);
    UBRR0L = (uint8_t)UBRR_VALUE;

    // URSEL0 is the trap on this part: UCSR0C and UBRR0H share one I/O
    // address. URSEL = 1 in the written byte means "this is UCSRC";
    // without it the write would land in UBRR0H and destroy the baud
    // rate set two lines above.
    //
    // UCSZ01 | UCSZ00 = 8 data bits. Parity and stop bits stay at the
    // reset default: no parity, 1 stop bit -- so 8N1.
    UCSR0C = (1 << URSEL0) | (1 << UCSZ01) | (1 << UCSZ00);

    // Receiver, transmitter and the receive-complete interrupt. The
    // data-register-empty interrupt (UDRIE0) is switched on only while
    // there is something to send, see uart_putchar().
    UCSR0B = (1 << RXEN0) | (1 << TXEN0) | (1 << RXCIE0);

    // Hand the port to avr-libc's stdio. From here on printf() goes out
    // over RS-232 and getchar() comes in from it.
    fdev_setup_stream(&uart_stream, uart_putchar, uart_getchar, _FDEV_SETUP_RW);
    stdout = &uart_stream;
    stdin  = &uart_stream;
}

// A byte arrived. Reading UDR0 clears the interrupt flag.
ISR(USART0_RXC_vect)
{
    uint8_t data = UDR0;
    uint8_t next_head = (rx_head + 1) % RX_BUF_SIZE;

    // Buffer full: drop the new byte rather than overwrite an unread
    // one. Advancing head onto tail would make the buffer look empty
    // and lose everything in it.
    if (next_head != rx_tail)
    {
        rx_buf[rx_head] = data;
        rx_head = next_head;
    }
}

// The transmit register is free. This interrupt fires repeatedly as
// long as it is enabled, so it must switch itself off when the buffer
// runs dry -- otherwise the CPU would spend all its time in here.
ISR(USART0_UDRE_vect)
{
    if (tx_tail != tx_head)
    {
        UDR0 = tx_buf[tx_tail];
        tx_tail = (tx_tail + 1) % TX_BUF_SIZE;
    }
    else
    {
        UCSR0B &= ~(1 << UDRIE0);
    }
}

int uart_putchar(char c, FILE *stream)
{
    // Terminals expect CR LF. printf("\n") alone leaves the cursor in
    // column 0 of the same line on some of them.
    if (c == '\n')
        uart_putchar('\r', stream);

    uint8_t next_head = (tx_head + 1) % TX_BUF_SIZE;

    // Buffer full: wait for the ISR to drain one byte. This is the only
    // place printf() can block, and it takes about 1 ms per byte at
    // 9600 baud. 64 bytes is enough for the longest line here.
    while (next_head == tx_tail)
        ;

    tx_buf[tx_head] = c;
    tx_head = next_head;

    // Enabling UDRIE0 starts the chain: the register is already empty,
    // so the interrupt fires immediately and keeps firing until the
    // buffer is drained.
    UCSR0B |= (1 << UDRIE0);

    return 0;
}

int uart_getchar(FILE *stream)
{
    (void)stream;

    // Blocks until a byte arrives. Call uart_available() first if the
    // caller cannot afford to wait -- the game loop never calls this.
    while (rx_tail == rx_head)
        ;

    uint8_t data = rx_buf[rx_tail];
    rx_tail = (rx_tail + 1) % RX_BUF_SIZE;
    return data;
}

uint8_t uart_available(void)
{
    return (rx_head != rx_tail);
}
