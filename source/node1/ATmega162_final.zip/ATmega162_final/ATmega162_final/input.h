#ifndef INPUT_H
#define INPUT_H

#include <stdint.h>
#include "ioboard.h"

typedef enum {
    INPUT_NONE,
    INPUT_UP,
    INPUT_DOWN,
    INPUT_LEFT,
    INPUT_RIGHT,
    INPUT_SELECT        // SR6 -- menu confirm
} input_event_t;

void input_init(void);

// Turns raw joystick position and button state into discrete events.
// Call once per frame with the current time and joystick position.
// Returns at most one event per call; SELECT takes priority.
//
// Navigation fires once when the stick is pushed, then repeats after
// a short hold -- like a keyboard key.
//
// This is also the only place the IO board buttons are read, so it must
// be called once per frame even in states that ignore its return value.
input_event_t input_poll(uint16_t now, int16_t joy_x, int16_t joy_y);

// --- SR6: menu confirm -----------------------------------------------
// Debounced level. INPUT_SELECT is the press edge of this.
uint8_t input_select_state(void);

// --- NAV_B: solenoid trigger -----------------------------------------
// Debounced level. This is what goes out on CAN bit 0, where node 2
// does its own edge detection and cooldown.
uint8_t input_fire_state(void);

// 1 once per NAV_B press, cleared by reading. For the UI only -- node 2
// decides when the solenoid actually fires.
uint8_t input_fire_pressed(void);

// The button bytes from the last input_poll(), for the gamepad test
// screen. Reusing them costs no further SPI traffic.
const ioboard_buttons_t *input_buttons(void);

#endif // INPUT_H
