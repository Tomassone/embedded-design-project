#ifndef SPI_H
#define SPI_H

#include <stdint.h>

// ---------------------------------------------------------------------
// spi.h -- SPI master for the three slaves on node 1
//
// One bus, three chip selects: the OLED display, the IO board and the
// MCP2515 CAN controller. All three work in SPI mode 0, which is why a
// single configuration serves them.
//
// This layer knows nothing about any of the three devices. It only
// shifts bytes and drives chip selects.
// ---------------------------------------------------------------------

typedef enum {
    SPI_SLAVE_NONE,
    SPI_SLAVE_DISPLAY,      // SSD1309 OLED,  CS on PB2
    SPI_SLAVE_IOBOARD,      // gamepad board, CS on PB3
    SPI_SLAVE_CAN           // MCP2515,       CS on PD3
} spi_slave_t;

// Sets the pin directions, deselects every slave and enables the SPI
// peripheral as master. Call before any other function here.
void spi_init(void);

// Asserts one chip select. Every other slave is deselected first, so
// two slaves can never drive MISO at the same time.
void spi_select(spi_slave_t slave);

// Deasserts all three chip selects. For the MCP2515 this also ends the
// current instruction -- it terminates on the rising edge of CS, not
// after a byte count.
void spi_deselect(void);

// Exchanges one byte. SPI has no separate read or write: eight bits go
// out while eight bits come in, so every transfer is both.
uint8_t spi_transfer(uint8_t data);

// Transfer with the unwanted direction ignored. spi_read() sends 0xFF,
// which leaves MOSI recessive while the slave answers.
void spi_write(uint8_t data);
uint8_t spi_read(void);

void spi_write_bytes(const uint8_t *data, uint16_t length);
void spi_read_bytes(uint8_t *buffer, uint16_t length);

#endif // SPI_H
