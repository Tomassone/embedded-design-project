#define F_CPU 4915200UL
#define BAUD 9600UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include "uart.h"
#include "sram.h"
#include "adc.h"
#include "joystick.h"

static const char *direction_name(joystick_direction_t dir)
{
	switch (dir)
	{
		case JOY_LEFT:  return "LEFT";
		case JOY_RIGHT: return "RIGHT";
		case JOY_UP:    return "UP";
		case JOY_DOWN:  return "DOWN";
		default:        return "NEUTRAL";
	}
}

int main(void)
{
	DDRB |= (1 << PB0);   // heartbeat LED

	uart_init();
	sei();

	xmem_init();
	adc_init();

	joystick_calibrate();

	printf("\r\nNode 1 test menu\r\n");
	joystick_print_calibration();
	printf("  t = SRAM test\r\n");
	printf("  j = joystick position (-90..+90)\r\n");
	printf("  d = joystick direction\r\n");
	printf("  r = raw ADC values\r\n");
	printf("  c = recalibrate centre\r\n");
	printf("  s = toggle streaming\r\n");

	uint8_t streaming = 0;

	while (1)
	{
		if (uart_available())
		{
			char c = getchar();

			switch (c)
			{
				case 't':
				case 'T':
				sram_test();
				break;

				case 'j':
				case 'J':
				{
					joystick_position_t p = joystick_get_position();
					printf("X = %4d   Y = %4d\r\n", p.x, p.y);
					break;
				}

				case 'd':
				case 'D':
				printf("Direction: %s\r\n",
				direction_name(joystick_get_direction()));
				break;

				case 'r':
				case 'R':
				{
					uint8_t rx, ry;
					joystick_get_raw(&rx, &ry);
					printf("Raw X = %3u   Raw Y = %3u\r\n", rx, ry);
					break;
				}

				case 'c':
				case 'C':
				joystick_calibrate();
				joystick_print_calibration();
				break;

				case 's':
				case 'S':
				streaming = !streaming;
				printf("Streaming %s\r\n", streaming ? "on" : "off");
				break;

				default:
				printf("Invalid input: '%c'\r\n", c);
				break;
			}
		}

		if (streaming)
		{
			joystick_position_t p = joystick_get_position();
			printf("X = %4d  Y = %4d  %s\r\n",
			p.x, p.y, direction_name(joystick_get_direction()));
			_delay_ms(100);
		}

		PORTB ^= (1 << PB0);
		_delay_ms(50);
	}
}