#ifndef CAN_H
#define CAN_H

#include <stdint.h>

// ---------------------------------------------------------------------
// High-level CAN messaging. The interface uses no MCP2515 types or
// registers, so node 2 can offer the same functions on top of its own
// controller and the application code stays the same on both nodes.
// ---------------------------------------------------------------------

#define CAN_MAX_DATA  8

typedef struct {
	uint16_t id;                    // 11-bit standard identifier
	uint8_t length;                 // number of data bytes, 0..8
	uint8_t data[CAN_MAX_DATA];
} can_message_t;

typedef enum {
	CAN_MODE_NORMAL,
	CAN_MODE_LOOPBACK               // messages are received by the sender
} can_mode_t;

// Initialises the controller: bit timing, receive all messages,
// receive interrupt on INT0, then switches to the given mode.
// Returns 0 on success, nonzero if the controller did not respond.
uint8_t can_init(can_mode_t mode);

// Queues a message for sending. Returns 0 on success, 1 if the
// transmit buffer is still busy with the previous message.
uint8_t can_send(const can_message_t *msg);

// Fetches a received message if one is waiting.
// Returns 1 and fills msg if there was one, else returns 0.
uint8_t can_receive(can_message_t *msg);

// Nonzero if the controller has signalled a received message via its
// interrupt line since the last can_receive(). Cheap to call: no SPI.
uint8_t can_rx_pending(void);

#endif // CAN_H