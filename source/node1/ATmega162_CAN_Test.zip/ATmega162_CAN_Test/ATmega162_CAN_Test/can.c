#include "can.h"
#include "mcp2515.h"
#include <avr/io.h>
#include <avr/interrupt.h>

// ---------------------------------------------------------------------
// Bit timing. One bit = 16 time quanta (TQ):
//   Sync 1 + PropSeg 2 + PhaseSeg1 7 + PhaseSeg2 6, sample point 62.5 %
//   TQ = 2 * (BRP + 1) / F_OSC
//
// With a 16 MHz crystal and BRP = 3:  TQ = 0.5 us, bit rate 125 kbit/s.
// With the current 4.9152 MHz crystal the same settings give 38.4
// kbit/s -- fine for loopback, but node 2 must use identical timing in
// exercise 6, so fit the 16 MHz crystal and agree on values then.
// ---------------------------------------------------------------------
#define CAN_CNF1   0x03     // SJW = 1 TQ, BRP = 3
#define CAN_CNF2   0xB1     // BTLMODE = 1, SAM = 0, PHSEG1 = 7 TQ, PRSEG = 2 TQ
#define CAN_CNF3   0x05     // PHSEG2 = 6 TQ

// Set by the INT0 interrupt when the MCP2515 pulls its INT line low.
// The ISR does NOT talk to the controller itself: the SPI bus is shared
// with the display and the IO board, and an SPI transfer started from
// an interrupt could land in the middle of an ongoing display flush.
static volatile uint8_t rx_pending = 0;

ISR(INT0_vect)
{
	rx_pending = 1;
}

static void interrupt_init(void)
{
	DDRD &= ~(1 << PD2);                 // CAN_INT as input

	// Falling edge on INT0. MCUCR also holds SRE for the external
	// memory interface, so only the ISC0x bits may be touched.
	MCUCR = (MCUCR & ~((1 << ISC01) | (1 << ISC00))) | (1 << ISC01);

	GIFR = (1 << INTF0);                 // discard a stale flag
	GICR |= (1 << INT0);
}

uint8_t can_init(can_mode_t mode)
{
	if (mcp2515_init() != 0)
	return 1;

	// CNF registers are only writable in configuration mode, where
	// mcp2515_init() has left the controller.
	mcp2515_write(MCP_CNF1, CAN_CNF1);
	mcp2515_write(MCP_CNF2, CAN_CNF2);
	mcp2515_write(MCP_CNF3, CAN_CNF3);

	// Accept every message in both receive buffers. RXB0 rolls over
	// into RXB1 when it is still full, so a burst of two survives.
	mcp2515_write(MCP_RXB0CTRL, MCP_RXM_ANY | MCP_BUKT);
	mcp2515_write(MCP_RXB1CTRL, MCP_RXM_ANY);

	// Interrupt on reception into either buffer.
	mcp2515_write(MCP_CANINTF, 0x00);
	mcp2515_write(MCP_CANINTE, MCP_RX0IF | MCP_RX1IF);

	interrupt_init();

	uint8_t target = (mode == CAN_MODE_LOOPBACK) ? MCP_MODE_LOOPBACK
	: MCP_MODE_NORMAL;

	return mcp2515_set_mode(target) ? 2 : 0;
}

uint8_t can_send(const can_message_t *msg)
{
	// Previous message still waiting for the bus?
	if (mcp2515_read(MCP_TXB0CTRL) & MCP_TXREQ)
	return 1;

	uint8_t length = (msg->length > CAN_MAX_DATA) ? CAN_MAX_DATA : msg->length;

	// TX buffer layout from TXB0SIDH onwards:
	//   SIDH  SIDL  EID8  EID0  DLC  D0..D7
	// Standard 11-bit ID: SIDH holds ID[10:3], SIDL bits 7..5 hold
	// ID[2:0]. EXIDE (SIDL bit 3) stays 0 = standard frame.
	uint8_t buffer[5 + CAN_MAX_DATA];

	buffer[0] = (uint8_t)(msg->id >> 3);
	buffer[1] = (uint8_t)((msg->id & 0x07) << 5);
	buffer[2] = 0;
	buffer[3] = 0;
	buffer[4] = length;                      // RTR bit 0 = data frame

	for (uint8_t i = 0; i < length; i++)
	buffer[5 + i] = msg->data[i];

	mcp2515_write_block(MCP_TXB0SIDH, buffer, 5 + length);
	mcp2515_request_to_send(MCP_RTS_TX0);

	return 0;
}

// Reads one receive buffer into msg and releases it.
static void read_rx_buffer(uint8_t sidh_address, uint8_t flag, can_message_t *msg)
{
	uint8_t buffer[5 + CAN_MAX_DATA];

	mcp2515_read_block(sidh_address, buffer, sizeof(buffer));

	msg->id = ((uint16_t)buffer[0] << 3) | (buffer[1] >> 5);
	msg->length = buffer[4] & 0x0F;
	if (msg->length > CAN_MAX_DATA)
	msg->length = CAN_MAX_DATA;

	for (uint8_t i = 0; i < msg->length; i++)
	msg->data[i] = buffer[5 + i];

	// Clearing the flag frees the buffer for the next message and
	// releases the INT line once no other flag is set.
	mcp2515_bit_modify(MCP_CANINTF, flag, 0x00);
}

uint8_t can_receive(can_message_t *msg)
{
	rx_pending = 0;

	// READ STATUS gives both RX flags in one short transfer:
	// bit 0 = RX0IF, bit 1 = RX1IF.
	uint8_t status = mcp2515_read_status();

	if (status & MCP_RX0IF)
	{
		read_rx_buffer(MCP_RXB0SIDH, MCP_RX0IF, msg);
		return 1;
	}

	if (status & MCP_RX1IF)
	{
		read_rx_buffer(MCP_RXB1SIDH, MCP_RX1IF, msg);
		return 1;
	}

	return 0;
}

uint8_t can_rx_pending(void)
{
	return rx_pending;
}