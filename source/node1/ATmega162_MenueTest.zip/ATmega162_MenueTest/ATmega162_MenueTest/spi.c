#include "spi.h"
#include <avr/io.h>

// Pin assignment as wired on the breadboard.
// PB4 is the hardware SS pin: unconnected, but it MUST be configured as
// an output. If left as an input and pulled low, the SPI hardware
// clears MSTR and silently drops out of master mode mid-transfer.
#define SPI_DDR      DDRB
#define SPI_PORT     PORTB
#define PIN_SS_HW    PB4
#define PIN_MOSI     PB5
#define PIN_MISO     PB6
#define PIN_SCK      PB7

#define CS_DISP_PORT PORTB
#define CS_DISP_DDR  DDRB
#define PIN_CS_DISP  PB2

#define CS_IO_PORT   PORTB
#define CS_IO_DDR    DDRB
#define PIN_CS_IO    PB3

#define CS_CAN_PORT  PORTD
#define CS_CAN_DDR   DDRD
#define PIN_CS_CAN   PD3

void spi_init(void)
{
	// MOSI, SCK and the hardware SS pin as outputs; MISO stays an input.
	SPI_DDR |=  (1 << PIN_MOSI) | (1 << PIN_SCK) | (1 << PIN_SS_HW);
	SPI_DDR &= ~(1 << PIN_MISO);
	SPI_PORT |= (1 << PIN_SS_HW);   // idle high

	// Slave selects as outputs, all idle high (deasserted).
	CS_DISP_DDR  |= (1 << PIN_CS_DISP);
	CS_IO_DDR    |= (1 << PIN_CS_IO);
	CS_CAN_DDR   |= (1 << PIN_CS_CAN);
	spi_deselect();

	// Enable SPI, master mode, fosc/16 -> 4.9152 MHz / 16 = 307 kHz.
	// Deliberately slow to start with: breadboard wiring is not kind to
	// fast edges. Once everything works, try SPR0 = 0 (fosc/4) for a
	// 4x speed-up, which matters once you are pushing 1 KiB frames.
	//
	// VERIFY against the SSD1309 datasheet: SPI mode 0 (CPOL=0, CPHA=0)
	// is assumed here. If the display expects mode 3, set CPOL and CPHA.
	SPCR = (1 << SPE) | (1 << MSTR) | (1 << SPR0);
	SPSR = 0;
}

void spi_deselect(void)
{
	CS_DISP_PORT |= (1 << PIN_CS_DISP);
	CS_IO_PORT   |= (1 << PIN_CS_IO);
	CS_CAN_PORT  |= (1 << PIN_CS_CAN);
}

void spi_select(spi_slave_t slave)
{
	spi_deselect();   // never two at once -- both would drive MISO

	switch (slave)
	{
		case SPI_SLAVE_DISPLAY:
		CS_DISP_PORT &= ~(1 << PIN_CS_DISP);
		break;
		case SPI_SLAVE_IOBOARD:
		CS_IO_PORT &= ~(1 << PIN_CS_IO);
		break;
		case SPI_SLAVE_CAN:
		CS_CAN_PORT &= ~(1 << PIN_CS_CAN);
		break;
		default:
		break;
	}
}

uint8_t spi_transfer(uint8_t data)
{
	SPDR = data;                        // writing SPDR starts the clock

	while (!(SPSR & (1 << SPIF)))
	;                               // wait for the 8 clocks to finish

	return SPDR;                        // the byte clocked in from MISO
}

void spi_write(uint8_t data)
{
	spi_transfer(data);
}

uint8_t spi_read(void)
{
	return spi_transfer(0xFF);          // dummy byte to generate clocks
}

void spi_write_bytes(const uint8_t *data, uint16_t length)
{
	for (uint16_t i = 0; i < length; i++)
	spi_transfer(data[i]);
}

void spi_read_bytes(uint8_t *buffer, uint16_t length)
{
	for (uint16_t i = 0; i < length; i++)
	buffer[i] = spi_transfer(0xFF);
}