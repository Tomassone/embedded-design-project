#ifndef F_CPU
#define F_CPU 4915200UL
#endif

#include "timer.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/atomic.h>

static volatile uint16_t millis = 0;

void timer_init(void)
{
    // CTC mode (WGM32 set, TOP = OCR3A), no prescaler.
    // 4 915 200 Hz / 4915 = 1000.04 Hz.
    OCR3A  = (F_CPU / 1000UL) - 1;
    TCCR3A = 0;
    TCCR3B = (1 << WGM32) | (1 << CS30);

    // Timer3 interrupts live in ETIMSK on the ATmega162, not TIMSK.
    ETIMSK |= (1 << OCIE3A);
}

ISR(TIMER3_COMPA_vect)
{
    millis++;
}

uint16_t timer_millis(void)
{
    uint16_t m;

    // A 16-bit read takes two instructions; without this the ISR could
    // update the value between the two bytes.
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
    {
        m = millis;
    }

    return m;
}
