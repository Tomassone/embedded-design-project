#ifndef OLED_H
#define OLED_H

#include <stdint.h>

#define OLED_WIDTH    128
#define OLED_HEIGHT   64
#define OLED_PAGES    (OLED_HEIGHT / 8)          // 8 pages of 8 pixel rows
#define OLED_BUF_SIZE (OLED_WIDTH * OLED_PAGES)  // 1024 bytes

// The framebuffer lives in external SRAM at 0x1800, sharing the region
// with sram_test(). Running that test will corrupt the display contents.
#define OLED_BUFFER_ADDR 0x1800

void oled_init(void);
void oled_reset(void);

// --- Framebuffer operations: these touch SRAM only, nothing is sent
// --- to the display until oled_flush() is called.
void oled_clear(void);
void oled_set_pixel(uint8_t x, uint8_t y, uint8_t on);
void oled_fill_rect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t on);
void oled_draw_hline(uint8_t x, uint8_t y, uint8_t length, uint8_t on);
void oled_draw_vline(uint8_t x, uint8_t y, uint8_t length, uint8_t on);

// Pushes the whole framebuffer to the display. At fosc/16 this takes
// roughly 30 ms, so about 30 fps is the practical ceiling.
void oled_flush(void);

// Direct command access, for the init sequence and for anything the
// helpers above do not cover.
void oled_write_command(uint8_t cmd);
void oled_write_data(uint8_t data);

#endif // OLED_H