#include "input.h"
#include "ioboard.h"

// ---------------------------------------------------------------------
// "B1" -- the IO board button that confirms a menu entry and stops the
// game. It is read over SPI from the IO board controller (command 0x04).
//
// The button reply is three bytes: right, left, nav. Pick the byte and
// the bit mask for your button:
//
//   SELECT_BYTE_RIGHT : [0 0 R6 R5 R4 R3 R2 R1]
//   SELECT_BYTE_LEFT  : [0 L7 L6 L5 L4 L3 L2 L1]
//   SELECT_BYTE_NAV   : [0 0 0 Up Down Left Right Btn]
//
// Set to the nav switch push (NAV_B): bit 0 of the nav byte. For a
// different button, open "Calibration & Test" -> "Live input test",
// press it and watch which of R/L/N changes. Enter that here.
// ---------------------------------------------------------------------
#define SELECT_BYTE_RIGHT        0
#define SELECT_BYTE_LEFT         1
#define SELECT_BYTE_NAV          2

#define SELECT_BYTE              SELECT_BYTE_NAV
#define SELECT_MASK              0x01

// Navigation thresholds, in joystick output units (-90..+90).
// Press and release differ so a stick held near the threshold does not
// fire a stream of events.
#define NAV_PRESS_THRESHOLD      50
#define NAV_RELEASE_THRESHOLD    30

#define NAV_REPEAT_DELAY_MS      400
#define NAV_REPEAT_RATE_MS       150

static uint8_t select_stable;       // debounced state
static uint8_t select_last_raw;     // previous raw sample

static input_event_t nav_held = INPUT_NONE;
static uint16_t nav_next_repeat;

static uint8_t select_raw(void)
{
	ioboard_buttons_t b = ioboard_read_buttons();
	uint8_t value;

	#if SELECT_BYTE == SELECT_BYTE_RIGHT
	value = b.right;
	#elif SELECT_BYTE == SELECT_BYTE_LEFT
	value = b.left;
	#else
	value = b.nav;
	#endif

	return (value & SELECT_MASK) ? 1 : 0;
}

void input_init(void)
{
	// Take the current state as the starting point, so a button held
	// during power-up does not register as a press.
	// Requires spi_init() to have run -- the button is read over SPI.
	select_last_raw = select_raw();
	select_stable = select_last_raw;
}

// Direction the stick currently points, with hysteresis: a held
// direction stays active until the stick falls back below the release
// threshold on that axis.
static input_event_t stick_direction(int16_t x, int16_t y)
{
	switch (nav_held)
	{
		case INPUT_UP:    if (y >=  NAV_RELEASE_THRESHOLD) return INPUT_UP;    break;
		case INPUT_DOWN:  if (y <= -NAV_RELEASE_THRESHOLD) return INPUT_DOWN;  break;
		case INPUT_RIGHT: if (x >=  NAV_RELEASE_THRESHOLD) return INPUT_RIGHT; break;
		case INPUT_LEFT:  if (x <= -NAV_RELEASE_THRESHOLD) return INPUT_LEFT;  break;
		default: break;
	}

	int16_t ax = (x < 0) ? -x : x;
	int16_t ay = (y < 0) ? -y : y;

	if (ax < NAV_PRESS_THRESHOLD && ay < NAV_PRESS_THRESHOLD)
	return INPUT_NONE;

	if (ax > ay)
	return (x > 0) ? INPUT_RIGHT : INPUT_LEFT;
	else
	return (y > 0) ? INPUT_UP : INPUT_DOWN;
}

input_event_t input_poll(uint16_t now, int16_t joy_x, int16_t joy_y)
{
	input_event_t select_event = INPUT_NONE;
	input_event_t nav_event = INPUT_NONE;

	// --- Select: debounced over two consecutive samples, fires on press.
	uint8_t raw = select_raw();

	if (raw == select_last_raw && raw != select_stable)
	{
		select_stable = raw;
		if (raw)
		select_event = INPUT_SELECT;
	}
	select_last_raw = raw;

	// --- Navigation: fire on push, then auto-repeat while held.
	input_event_t dir = stick_direction(joy_x, joy_y);

	if (dir != nav_held)
	{
		nav_held = dir;
		if (dir != INPUT_NONE)
		{
			nav_event = dir;
			nav_next_repeat = now + NAV_REPEAT_DELAY_MS;
		}
	}
	else if (dir != INPUT_NONE && (int16_t)(now - nav_next_repeat) >= 0)
	{
		nav_event = dir;
		nav_next_repeat = now + NAV_REPEAT_RATE_MS;
	}

	return (select_event != INPUT_NONE) ? select_event : nav_event;
}

uint8_t input_select_state(void)
{
	return select_stable;
}