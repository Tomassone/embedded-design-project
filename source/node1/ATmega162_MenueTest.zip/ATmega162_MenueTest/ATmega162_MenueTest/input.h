#ifndef INPUT_H
#define INPUT_H

#include <stdint.h>

typedef enum {
    INPUT_NONE,
    INPUT_UP,
    INPUT_DOWN,
    INPUT_LEFT,
    INPUT_RIGHT,
    INPUT_SELECT        // "B1"
} input_event_t;

void input_init(void);

// Turns raw joystick position and button state into discrete events.
// Call once per frame with the current time and joystick position.
// Returns at most one event per call; SELECT takes priority.
//
// Navigation fires once when the stick is pushed, then repeats after
// a short hold -- like a keyboard key.
input_event_t input_poll(uint16_t now, int16_t joy_x, int16_t joy_y);

// Raw, debounced state of the select button, for live test displays.
uint8_t input_select_state(void);

#endif // INPUT_H
