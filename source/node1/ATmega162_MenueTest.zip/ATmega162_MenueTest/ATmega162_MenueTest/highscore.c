#include "highscore.h"
#include <avr/eeprom.h>

// Marks the EEPROM content as valid. A fresh or erased EEPROM reads
// 0xFF everywhere, which would otherwise show up as scores of 65535.
#define HIGHSCORE_MAGIC  0xA7

typedef struct {
    uint8_t magic;
    uint16_t scores[HIGHSCORE_COUNT];
} highscore_store_t;

static highscore_store_t EEMEM store;           // in EEPROM
static uint16_t scores[HIGHSCORE_COUNT];        // RAM copy

static void save(void)
{
    // update_ only writes bytes that changed -- EEPROM cells survive
    // about 100 000 writes, so skipping unchanged ones is worthwhile.
    eeprom_update_block(scores, store.scores, sizeof(scores));
    eeprom_update_byte(&store.magic, HIGHSCORE_MAGIC);
}

void highscore_init(void)
{
    if (eeprom_read_byte(&store.magic) != HIGHSCORE_MAGIC)
    {
        highscore_reset();
        return;
    }

    eeprom_read_block(scores, store.scores, sizeof(scores));
}

uint16_t highscore_get(uint8_t rank)
{
    return (rank < HIGHSCORE_COUNT) ? scores[rank] : 0;
}

int8_t highscore_submit(uint16_t score)
{
    if (score == 0)
        return -1;

    for (uint8_t rank = 0; rank < HIGHSCORE_COUNT; rank++)
    {
        if (score > scores[rank])
        {
            // Shift the lower entries down one place to make room.
            for (uint8_t i = HIGHSCORE_COUNT - 1; i > rank; i--)
                scores[i] = scores[i - 1];

            scores[rank] = score;
            save();
            return (int8_t)rank;
        }
    }

    return -1;
}

void highscore_reset(void)
{
    for (uint8_t i = 0; i < HIGHSCORE_COUNT; i++)
        scores[i] = 0;

    save();
}
