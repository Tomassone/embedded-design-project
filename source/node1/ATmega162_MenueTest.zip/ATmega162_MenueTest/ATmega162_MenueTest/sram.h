#ifndef SRAM_H
#define SRAM_H

#include <stdint.h>

// Start address of the SRAM in the external memory map.
// Memory map: ADC at 0x1000-0x17FF, SRAM at 0x1800-0x1FFF.
#define SRAM_BASE_ADDR   0x1800

// Usable size with the simple (single-NAND) address decoder: 2 KiB.
#define SRAM_SIZE        0x800

// Enables the external memory interface (XMEM) and masks the top 4
// address bits (PC7-PC4) so they stay free for JTAG.
// Must be called once before any external memory access.
void xmem_init(void);

// Writes a pseudo-random pattern across the whole SRAM range and
// verifies it twice (immediately after each write, then again over
// the full range). Progress and errors are printed via printf, so
// uart_init() must have been called first.
// Returns the total error count (0 = no errors).
uint16_t sram_test(void);

#endif // SRAM_H