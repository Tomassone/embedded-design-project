#ifndef JOYSTICK_H
#define JOYSTICK_H

#include <stdint.h>

// Measured converter limits for this joystick -- the potentiometers
// never reach either rail, so the usable span is 66..248.
#define JOY_ADC_MIN     66
#define JOY_ADC_MAX     248

// Output range of joystick_get_position(), per axis.
#define JOY_OUT_MAX     90

// --- Filter tuning -----------------------------------------------------
// Low-pass strength: each new sample moves the filtered value by
// 1/2^JOY_FILTER_SHIFT of the difference. 2 = 1/4 (responsive),
// 3 = 1/8 (smoother, more lag).
#define JOY_FILTER_SHIFT   2

// Hysteresis: the output only changes when the filtered value has
// moved at least this far (in output units, -90..+90) from the last
// reported value. Blocks the small wobble that survives the filter.
#define JOY_HYSTERESIS     3

// Centre snap: filtered values within this band report exactly 0,
// so a resting stick gives a perfectly still paddle.
#define JOY_CENTER_SNAP    4

typedef struct {
	int16_t x;
	int16_t y;
} joystick_position_t;

typedef enum {
	JOY_NEUTRAL,
	JOY_LEFT,
	JOY_RIGHT,
	JOY_UP,
	JOY_DOWN
} joystick_direction_t;

// Samples the resting position and stores it as centre. Takes ~50 ms.
// Leave the stick untouched while it runs. Also resets the filter.
void joystick_calibrate(void);

// Filtered position, -90..+90 per axis, 0 = centre.
// Call regularly: the filter state advances once per call.
joystick_position_t joystick_get_position(void);

joystick_direction_t joystick_get_direction(void);
void joystick_get_raw(uint8_t *x, uint8_t *y);
void joystick_print_calibration(void);

#endif // JOYSTICK_H