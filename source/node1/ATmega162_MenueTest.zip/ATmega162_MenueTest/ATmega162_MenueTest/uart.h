#ifndef UART_H
#define UART_H

#include <stdio.h>
#include <stdint.h>

// Global stdio stream connected to UART0 (usable as stdout/stdin after uart_init())
extern FILE uart_stream;

// Initialize USART0 (interrupt-driven, 8N1) and set up stdout/stdin.
// F_CPU and BAUD must be defined before including this header, or
// passed via project settings (see uart.c for the default values).
void uart_init(void);

// Non-blocking check: is there at least one received byte waiting?
uint8_t uart_available(void);

// Low-level put/get functions (normally not called directly -- use printf/getchar instead)
int uart_putchar(char c, FILE *stream);
int uart_getchar(FILE *stream);

#endif // UART_H