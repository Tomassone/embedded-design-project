#include "sram.h"
#include <avr/io.h>
#include <stdlib.h>
#include <stdio.h>

// ---------------------------------------------------------------------
// xmem_init()
// SRE (external memory enable) lives in MCUCR.
// The XMM bits live in SFIOR -- NOT in EMCUCR, which holds the
// wait-state and ISC2 bits instead.
// XMM2:0 = 100 masks the 4 MSBs of the address bus, releasing
// PC7-PC4 back to JTAG and leaving PC3-PC0 as A11-A8.
// ---------------------------------------------------------------------
void xmem_init(void)
{
	MCUCR |= (1 << SRE);
	SFIOR  = (1 << XMM2);
}

// ---------------------------------------------------------------------
// sram_test()
//
// Write phase: writes a pseudo-random byte to each address and reads
// it back immediately -- catches addressing and data-line faults.
//
// Retrieval phase: re-seeds the PRNG to reproduce the exact same
// sequence, then re-reads the whole range -- catches values that were
// corrupted *after* being written (noise, decoder glitches, another
// device driving the bus).
// ---------------------------------------------------------------------
uint16_t sram_test(void)
{
	volatile uint8_t *ext_ram = (uint8_t *)SRAM_BASE_ADDR;
	uint16_t write_errors = 0;
	uint16_t retrieval_errors = 0;

	printf("Starting SRAM test...\r\n");

	// rand() carries internal state, so seeding explicitly lets us
	// reproduce the identical sequence in the retrieval phase.
	uint16_t seed = rand();

	// --- Write phase ---
	srand(seed);
	for (uint16_t i = 0; i < SRAM_SIZE; i++)
	{
		uint8_t some_value = rand();
		ext_ram[i] = some_value;
		uint8_t retrieved_value = ext_ram[i];

		if (retrieved_value != some_value)
		{
			printf("Write phase error: ext_ram[%4d] = %02X (should be %02X)\r\n",
			i, retrieved_value, some_value);
			write_errors++;
		}
	}

	// --- Retrieval phase ---
	srand(seed);   // reset PRNG to the state it had before the write phase
	for (uint16_t i = 0; i < SRAM_SIZE; i++)
	{
		uint8_t some_value = rand();
		uint8_t retrieved_value = ext_ram[i];

		if (retrieved_value != some_value)
		{
			printf("Retrieval phase error: ext_ram[%4d] = %02X (should be %02X)\r\n",
			i, retrieved_value, some_value);
			retrieval_errors++;
		}
	}

	printf("SRAM test completed with\r\n%4d errors in write phase and\r\n%4d errors in retrieval phase\r\n\r\n",
	write_errors, retrieval_errors);

	return write_errors + retrieval_errors;
}