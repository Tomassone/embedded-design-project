#include "game.h"
#include "joystick.h"
#include "oled.h"
#include "oled_text.h"
#include <avr/pgmspace.h>
#include <stdlib.h>

// --- Geometry --------------------------------------------------------
// Text line 0 holds the score; the field starts below it.
#define FIELD_TOP        9
#define WALL_LEFT        0
#define WALL_RIGHT       (OLED_WIDTH - 1)

#define PADDLE_WIDTH     24
#define PADDLE_HEIGHT    4
#define PADDLE_Y         (OLED_HEIGHT - PADDLE_HEIGHT)

#define BALL_SIZE        3

// --- Motion ----------------------------------------------------------
// Ball position and speed are kept in fixed point with 4 fractional
// bits (1/16 pixel), so speeds between whole pixels per frame are
// possible without floating point.
#define FP_SHIFT         4
#define FP(px)           ((int16_t)(px) << FP_SHIFT)
#define PX(fp)           ((int16_t)(fp) >> FP_SHIFT)

// Vertical speed in 1/16 px per frame. At 50 ms per frame, 20 = 25 px/s.
// The maximum must stay below PADDLE_HEIGHT pixels per frame, otherwise
// the ball could pass through the paddle between two frames.
#define SPEED_START      20
#define SPEED_STEP       2
#define SPEED_MAX        48

// Horizontal speed per pixel of offset from the paddle centre: hitting
// near an edge sends the ball off at a steeper angle.
#define ANGLE_FACTOR     2

#define START_LIVES      3
#define SERVE_FRAMES     20      // pause before each serve, ~1 s

static int16_t ball_x, ball_y;   // top-left corner, fixed point
static int16_t vel_x, vel_y;
static int16_t speed;
static uint8_t paddle_x;
static uint16_t score;
static uint8_t lives;
static uint8_t serve_timer;

static uint8_t paddle_from_joystick(int16_t joy_x)
{
    int16_t travel = OLED_WIDTH - PADDLE_WIDTH;
    int16_t pos = ((joy_x + JOY_OUT_MAX) * travel) / (2 * JOY_OUT_MAX);

    if (pos < 0) pos = 0;
    if (pos > travel) pos = travel;

    return (uint8_t)pos;
}

static void serve(void)
{
    ball_x = FP((OLED_WIDTH - BALL_SIZE) / 2);
    ball_y = FP(FIELD_TOP + 4);

    speed = SPEED_START;
    vel_y = speed;                          // towards the player
    vel_x = (int16_t)(rand() % 33) - 16;    // random angle, +-1 px/frame

    serve_timer = SERVE_FRAMES;
}

void game_start(void)
{
    score = 0;
    lives = START_LIVES;
    paddle_x = (OLED_WIDTH - PADDLE_WIDTH) / 2;
    serve();
}

game_status_t game_update(int16_t joy_x)
{
    paddle_x = paddle_from_joystick(joy_x);

    // The paddle can move during the serve pause, the ball cannot.
    if (serve_timer > 0)
    {
        serve_timer--;
        return GAME_RUNNING;
    }

    int16_t prev_bottom = PX(ball_y) + BALL_SIZE;

    ball_x += vel_x;
    ball_y += vel_y;

    // Side walls
    if (ball_x < FP(WALL_LEFT + 1))
    {
        ball_x = FP(WALL_LEFT + 1);
        vel_x = -vel_x;
    }
    else if (ball_x > FP(WALL_RIGHT - BALL_SIZE))
    {
        ball_x = FP(WALL_RIGHT - BALL_SIZE);
        vel_x = -vel_x;
    }

    // Top wall
    if (ball_y < FP(FIELD_TOP + 1))
    {
        ball_y = FP(FIELD_TOP + 1);
        vel_y = -vel_y;
    }

    // Paddle: only when the ball's bottom edge crosses the paddle's top
    // edge in this frame. Checking overlap alone would let a paddle
    // swept under an already-missed ball scoop it back up.
    int16_t bottom = PX(ball_y) + BALL_SIZE;

    if (vel_y > 0 && prev_bottom <= PADDLE_Y && bottom >= PADDLE_Y)
    {
        int16_t left = PX(ball_x);

        if (left + BALL_SIZE > paddle_x && left < paddle_x + PADDLE_WIDTH)
        {
            ball_y = FP(PADDLE_Y - BALL_SIZE);

            if (speed + SPEED_STEP <= SPEED_MAX)
                speed += SPEED_STEP;
            vel_y = -speed;

            int16_t offset = (left + BALL_SIZE / 2) - (paddle_x + PADDLE_WIDTH / 2);
            vel_x = offset * ANGLE_FACTOR;

            score++;
        }
    }

    // Missed: ball has left the bottom of the screen.
    if (PX(ball_y) >= OLED_HEIGHT)
    {
        if (lives > 0)
            lives--;

        if (lives == 0)
            return GAME_OVER;

        serve();
    }

    return GAME_RUNNING;
}

void game_draw(void)
{
    oled_clear();

    oled_goto(0, 0);
    oled_printf_P(PSTR("SCORE %4u   LIVES %u"), score, lives);

    oled_draw_hline(0, FIELD_TOP, OLED_WIDTH, 1);
    oled_draw_vline(WALL_LEFT, FIELD_TOP, OLED_HEIGHT - FIELD_TOP, 1);
    oled_draw_vline(WALL_RIGHT, FIELD_TOP, OLED_HEIGHT - FIELD_TOP, 1);

    oled_fill_rect(paddle_x, PADDLE_Y, PADDLE_WIDTH, PADDLE_HEIGHT, 1);
    oled_fill_rect(PX(ball_x), PX(ball_y), BALL_SIZE, BALL_SIZE, 1);

    if (serve_timer > 0)
        oled_draw_string_P((OLED_WIDTH - 5 * OLED_CHAR_WIDTH) / 2, 32, PSTR("READY"));

    oled_flush();
}

uint16_t game_get_score(void)
{
    return score;
}
