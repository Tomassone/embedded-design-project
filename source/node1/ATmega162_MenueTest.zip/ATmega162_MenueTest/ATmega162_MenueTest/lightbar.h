#ifndef LIGHTBAR_H
#define LIGHTBAR_H

// Pulse running from the two middle LEDs of the IO board outwards,
// driven by the LED PWM command. Call lightbar_update() once per frame
// while the game runs.
void lightbar_start(void);
void lightbar_update(void);
void lightbar_off(void);

#endif // LIGHTBAR_H
