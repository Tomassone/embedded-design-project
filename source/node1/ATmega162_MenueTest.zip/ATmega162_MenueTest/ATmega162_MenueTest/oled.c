#ifndef F_CPU
#define F_CPU 4915200UL
#endif

#include "oled.h"
#include "spi.h"
#include <avr/io.h>
#include <util/delay.h>

// D/!C and RESET are not part of SPI proper -- they are plain GPIO
// lines the display samples alongside the SPI traffic.
#define DISP_CTRL_PORT  PORTB
#define DISP_CTRL_DDR   DDRB
#define PIN_DISP_DC     PB1
#define PIN_DISP_RES    PB0

// The framebuffer. volatile because it lives in external memory: the
// compiler must not cache or reorder these accesses.
static volatile uint8_t *framebuffer = (uint8_t *)OLED_BUFFER_ADDR;

void oled_write_command(uint8_t cmd)
{
	DISP_CTRL_PORT &= ~(1 << PIN_DISP_DC);   // D/!C low = command
	spi_select(SPI_SLAVE_DISPLAY);
	spi_write(cmd);
	spi_deselect();
}

void oled_write_data(uint8_t data)
{
	DISP_CTRL_PORT |= (1 << PIN_DISP_DC);    // D/!C high = data
	spi_select(SPI_SLAVE_DISPLAY);
	spi_write(data);
	spi_deselect();
}

void oled_reset(void)
{
	DISP_CTRL_PORT &= ~(1 << PIN_DISP_RES);
	_delay_ms(10);
	DISP_CTRL_PORT |= (1 << PIN_DISP_RES);
	_delay_ms(100);   // give the controller time to come up
}

void oled_init(void)
{
	DISP_CTRL_DDR |= (1 << PIN_DISP_DC) | (1 << PIN_DISP_RES);
	DISP_CTRL_PORT |= (1 << PIN_DISP_RES);

	oled_reset();

	// =================================================================
	// Init sequence, SSD1309 Rev 1.1.
	//
	// Section 8.4 lists the reset state: display off, 128x64 mode,
	// SEG0 -> column 0, COM0 -> row 0, start line 0, contrast 7Fh,
	// normal display. Most settings are therefore already correct after
	// reset; they are sent explicitly so this sequence is self-contained.
	//
	// The one that MUST be sent is the addressing mode: Table 9-3 gives
	// page addressing as the reset default, while oled_flush() streams
	// all 1024 bytes in one go, which requires horizontal mode.
	// =================================================================

	oled_write_command(0xAE);   // Display OFF while configuring (Table 9-1)

	// Memory addressing mode (Table 9-3, cmd 20h):
	//   A[1:0] = 00b horizontal, 01b vertical, 10b page (RESET)
	oled_write_command(0x20);
	oled_write_command(0x00);

	// Column address range 0..127 (Table 9-3, cmd 21h). Reset values,
	// but sending them also resets the internal pointer.
	oled_write_command(0x21);
	oled_write_command(0x00);
	oled_write_command(0x7F);

	// Page address range 0..7 (Table 9-3, cmd 22h).
	oled_write_command(0x22);
	oled_write_command(0x00);
	oled_write_command(0x07);

	// Multiplex ratio: MUX = N+1, so 3Fh = 63 -> 64 MUX (Table 9-4).
	oled_write_command(0xA8);
	oled_write_command(0x3F);

	// Display offset: no vertical shift (Table 9-4, cmd D3h).
	oled_write_command(0xD3);
	oled_write_command(0x00);

	// Display start line 0 (Table 9-4, cmd 40h~7Fh).
	oled_write_command(0x40);

	// Orientation. A1h maps column 127 to SEG0, C8h scans COM[N-1] to
	// COM0 (Table 9-4) -- together a 180 degree rotation relative to
	// reset. If the image comes out upside down, use A0h and C0h.
	oled_write_command(0xA1);
	oled_write_command(0xC8);

	// COM pins hardware configuration (Table 9-4, cmd DAh).
	// A[4]=1 alternative COM pin config, A[5]=0 no L/R remap.
	oled_write_command(0xDA);
	oled_write_command(0x12);

	// Contrast (Table 9-1, cmd 81h). RESET = 7Fh.
	oled_write_command(0x81);
	oled_write_command(0x7F);

	// Display clock divide ratio / oscillator frequency (Table 9-5,
	// cmd D5h). 70h = reset divide ratio of 1, reset FOSC of 7.
	oled_write_command(0xD5);
	oled_write_command(0x70);

	// Pre-charge period (Table 9-5, cmd D9h). RESET = 22h.
	oled_write_command(0xD9);
	oled_write_command(0x22);

	// VCOMH deselect level (Table 9-5, cmd DBh). 34h = ~0.78 x VCC.
	oled_write_command(0xDB);
	oled_write_command(0x34);

	// Clear the buffer before switching the panel on, so power-on
	// noise in RAM is never displayed.
	oled_clear();
	oled_flush();

	// Display ON. Section 8.8: SEG/COM come on ~100 ms after AFh.
	oled_write_command(0xAF);
	_delay_ms(100);

	// A4h (follow RAM) and A6h (normal, non-inverted) are sent AFTER
	// AFh deliberately: issued while the panel was off they did not
	// take effect on this module, leaving it stuck in A5h all-on mode.
	oled_write_command(0xA4);
	oled_write_command(0xA6);
}

void oled_clear(void)
{
	for (uint16_t i = 0; i < OLED_BUF_SIZE; i++)
	framebuffer[i] = 0x00;
}

// ---------------------------------------------------------------------
// Pixel addressing: the display is organised as 8 pages, each 8 pixel
// rows tall and 128 columns wide. One byte covers 8 vertically stacked
// pixels in a single column, with bit 0 at the top of the page.
//
//   page  = y / 8       (which band of 8 rows)
//   bit   = y % 8       (which row within that band)
//   index = page * 128 + x
// ---------------------------------------------------------------------
void oled_set_pixel(uint8_t x, uint8_t y, uint8_t on)
{
	if (x >= OLED_WIDTH || y >= OLED_HEIGHT)
	return;

	uint16_t index = ((uint16_t)(y / 8) * OLED_WIDTH) + x;
	uint8_t mask = (1 << (y % 8));

	if (on)
	framebuffer[index] |= mask;
	else
	framebuffer[index] &= ~mask;
}

void oled_fill_rect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t on)
{
	for (uint8_t dy = 0; dy < h; dy++)
	for (uint8_t dx = 0; dx < w; dx++)
	oled_set_pixel(x + dx, y + dy, on);
}

void oled_draw_hline(uint8_t x, uint8_t y, uint8_t length, uint8_t on)
{
	for (uint8_t i = 0; i < length; i++)
	oled_set_pixel(x + i, y, on);
}

void oled_draw_vline(uint8_t x, uint8_t y, uint8_t length, uint8_t on)
{
	for (uint8_t i = 0; i < length; i++)
	oled_set_pixel(x, y + i, on);
}

// ---------------------------------------------------------------------
// Sends the framebuffer in one transaction: chip select is asserted
// once for all 1024 bytes rather than per byte, roughly halving the
// transfer time compared to calling oled_write_data() in a loop.
//
// Assumes horizontal addressing mode -- set by 20h/00h in oled_init().
// ---------------------------------------------------------------------
void oled_flush(void)
{
	DISP_CTRL_PORT |= (1 << PIN_DISP_DC);    // data mode
	spi_select(SPI_SLAVE_DISPLAY);

	for (uint16_t i = 0; i < OLED_BUF_SIZE; i++)
	spi_write(framebuffer[i]);

	spi_deselect();
}