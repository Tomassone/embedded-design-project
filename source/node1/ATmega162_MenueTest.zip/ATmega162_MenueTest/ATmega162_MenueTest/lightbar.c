#include "lightbar.h"
#include "ioboard.h"

// Physical left-to-right order of the six IO board LEDs. If the pulse
// does not start in the middle on your board, reorder these numbers.
static const uint8_t led_order[IOB_LED_COUNT] = { 0, 1, 2, 3, 4, 5 };

// Three rings: middle pair, next pair, outer pair.
#define LIGHTBAR_RINGS      3

// Phase advance per frame, out of 256 per cycle. At 50 ms frames,
// 8 gives one pulse every 1.6 s.
#define LIGHTBAR_SPEED      8

// Delay between rings, out of 256. Larger = slower outward travel.
#define LIGHTBAR_RING_DELAY 40

static uint8_t phase;

// Triangle wave 0..255..0 over one phase cycle, squared so the LEDs
// fade more naturally -- perceived brightness is far from linear.
static uint8_t pulse_level(uint8_t p)
{
    uint8_t tri = (p < 128) ? (uint8_t)(p << 1) : (uint8_t)((255 - p) << 1);
    return (uint8_t)(((uint16_t)tri * tri) >> 8);
}

void lightbar_start(void)
{
    phase = 0;

    for (uint8_t i = 0; i < IOB_LED_COUNT; i++)
    {
        ioboard_set_led_pwm(i, 0);
        ioboard_set_led(i, 1);
    }
}

void lightbar_update(void)
{
    phase += LIGHTBAR_SPEED;    // wraps at 256 by design

    for (uint8_t ring = 0; ring < LIGHTBAR_RINGS; ring++)
    {
        // Each ring runs behind the one inside it, so the pulse travels
        // from the middle outwards.
        uint8_t level = pulse_level(phase - ring * LIGHTBAR_RING_DELAY);

        uint8_t left  = (IOB_LED_COUNT / 2 - 1) - ring;   // 2, 1, 0
        uint8_t right = (IOB_LED_COUNT / 2) + ring;       // 3, 4, 5

        ioboard_set_led_pwm(led_order[left], level);
        ioboard_set_led_pwm(led_order[right], level);
    }
}

void lightbar_off(void)
{
    for (uint8_t i = 0; i < IOB_LED_COUNT; i++)
    {
        ioboard_set_led_pwm(i, 0);
        ioboard_set_led(i, 0);
    }
}
