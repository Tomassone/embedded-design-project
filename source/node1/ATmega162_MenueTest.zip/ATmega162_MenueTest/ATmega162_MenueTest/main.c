#define F_CPU 4915200UL
#define BAUD 9600UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/delay.h>
#include <stdio.h>
#include "uart.h"
#include "sram.h"
#include "adc.h"
#include "joystick.h"
#include "spi.h"
#include "oled.h"
#include "oled_text.h"
#include "ioboard.h"
#include "timer.h"
#include "input.h"
#include "menu.h"
#include "game.h"
#include "highscore.h"
#include "lightbar.h"

// One frame = one pass through the state machine. A full display flush
// takes ~27 ms at the current SPI clock, so 50 ms leaves headroom.
#define FRAME_MS            50

// The live test screen redraws every 5th frame (250 ms) -- fast enough
// to follow the stick, slow enough to read.
#define LIVE_TEST_DIVIDER   5

// In pause: holding B1 this long stops the game, a shorter press resumes.
#define STOP_HOLD_MS        2500

typedef enum {
	STATE_MAIN_MENU,
	STATE_GAME,
	STATE_PAUSED,
	STATE_GAME_OVER,
	STATE_HIGHSCORES,
	STATE_TEST_MENU,
	STATE_LIVE_TEST,
	STATE_MESSAGE           // info screen, returns to the test menu
} app_state_t;

// ---------------------------------------------------------------------
// Menu definitions -- all text in flash.
// ---------------------------------------------------------------------
static const char str_main_title[]  PROGMEM = "PONG";
static const char str_start[]       PROGMEM = "Start game";
static const char str_highscores[]  PROGMEM = "Highscores";
static const char str_cal_test[]    PROGMEM = "Calibration & Test";

static const char * const main_items[] PROGMEM = {
	str_start, str_highscores, str_cal_test
};

enum { MAIN_START, MAIN_HIGHSCORES, MAIN_CAL_TEST };

static const menu_t main_menu = { str_main_title, main_items, 3 };

static const char str_test_title[]  PROGMEM = "CALIBRATION & TEST";
static const char str_calibrate[]   PROGMEM = "Calibrate joystick";
static const char str_live_test[]   PROGMEM = "Live input test";
static const char str_sram_test[]   PROGMEM = "SRAM test";
static const char str_reset_hs[]    PROGMEM = "Reset highscores";
static const char str_back[]        PROGMEM = "Back";

static const char * const test_items[] PROGMEM = {
	str_calibrate, str_live_test, str_sram_test, str_reset_hs, str_back
};

enum { TEST_CALIBRATE, TEST_LIVE, TEST_SRAM, TEST_RESET_HS, TEST_BACK };

static const menu_t test_menu = { str_test_title, test_items, 5 };

// ---------------------------------------------------------------------
// State
// ---------------------------------------------------------------------
static app_state_t state;
static menu_nav_t nav;
static uint8_t live_counter;

static uint8_t pause_holding;       // B1 currently held down in pause
static uint16_t pause_press_start;  // time of that press

// ---------------------------------------------------------------------
// Screens
// ---------------------------------------------------------------------
static void draw_footer_P(const char *text_P)
{
	oled_goto(OLED_TEXT_LINES - 1, 0);
	oled_print_P(text_P);
}

static void show_highscores(void)
{
	static const char title[] PROGMEM = "HIGHSCORES";

	oled_clear();
	menu_draw_title(title);

	for (uint8_t i = 0; i < HIGHSCORE_COUNT; i++)
	{
		oled_goto(1 + i, 2);
		oled_printf_P(PSTR("%u.  %5u"), i + 1, highscore_get(i));
	}

	draw_footer_P(PSTR("B1: back"));
	oled_flush();
}

// Pause screen. fill = hold progress towards stopping, 0..100 pixels.
static void show_pause(uint8_t fill)
{
	static const char title[] PROGMEM = "PAUSED";

	oled_clear();
	menu_draw_title(title);

	oled_goto(2, 1);
	oled_printf_P(PSTR("Score: %u"), game_get_score());

	oled_goto(4, 1);
	oled_print_P(PSTR("B1 tap : resume"));
	oled_goto(5, 1);
	oled_print_P(PSTR("B1 hold: stop game"));

	// Progress bar: outline 102 x 8 px, fills while B1 is held.
	oled_draw_hline(13, 52, 102, 1);
	oled_draw_hline(13, 59, 102, 1);
	oled_draw_vline(13, 52, 8, 1);
	oled_draw_vline(114, 52, 8, 1);

	if (fill > 0)
	oled_fill_rect(14, 54, fill, 4, 1);

	oled_flush();
}

static void show_game_over(uint8_t stopped, uint16_t score, int8_t rank)
{
	static const char over[] PROGMEM = "GAME OVER";
	static const char stop[] PROGMEM = "GAME STOPPED";

	oled_clear();
	menu_draw_title(stopped ? stop : over);

	oled_goto(2, 2);
	oled_printf_P(PSTR("Score: %u"), score);

	if (rank >= 0)
	{
		oled_goto(4, 2);
		oled_printf_P(PSTR("New highscore! #%d"), rank + 1);
	}

	draw_footer_P(PSTR("B1: continue"));
	oled_flush();
}

// Generic two-line message screen, used by the test menu actions.
static void show_message(const char *title_P, const char *line_P)
{
	oled_clear();
	menu_draw_title(title_P);

	oled_goto(2, 1);
	oled_print_P(line_P);

	draw_footer_P(PSTR("B1: back"));
	oled_flush();
}

static void draw_live_test(void)
{
	static const char title[] PROGMEM = "LIVE INPUT TEST";

	uint8_t raw_x, raw_y;
	joystick_get_raw(&raw_x, &raw_y);

	ioboard_slider_t slider = ioboard_read_slider();
	ioboard_touchpad_t pad = ioboard_read_touchpad();
	ioboard_buttons_t btn = ioboard_read_buttons();

	oled_clear();
	menu_draw_title(title);

	oled_goto(1, 0);
	oled_printf_P(PSTR("Joy raw  X%3u Y%3u"), raw_x, raw_y);
	oled_goto(3, 0);
	oled_printf_P(PSTR("Slider   %3u"), slider.x);
	oled_goto(4, 0);
	oled_printf_P(PSTR("Pad      X%3u Y%3u"), pad.x, pad.y);
	oled_goto(5, 0);
	oled_printf_P(PSTR("Btn R%02X L%02X N%02X"), btn.right, btn.left, btn.nav);

	draw_footer_P(PSTR("B1: back"));
	oled_flush();
}

// Joystick position is drawn separately: it comes from the filtered
// reading the main loop already takes each frame.
static void draw_live_position(int16_t x, int16_t y)
{
	oled_goto(2, 0);
	oled_printf_P(PSTR("Joy pos  X%4d Y%4d"), x, y);
	oled_flush();
}

// ---------------------------------------------------------------------
// State transitions
// ---------------------------------------------------------------------
static void enter_main_menu(void)
{
	state = STATE_MAIN_MENU;
	menu_open(&nav, &main_menu);
}

static void enter_test_menu(void)
{
	state = STATE_TEST_MENU;
	menu_open(&nav, &test_menu);
}

static void start_game(void)
{
	state = STATE_GAME;
	game_start();
	lightbar_start();
	game_draw();
}

static void pause_game(void)
{
	state = STATE_PAUSED;
	pause_holding = 0;
	lightbar_off();
	show_pause(0);
}

static void resume_game(void)
{
	state = STATE_GAME;
	pause_holding = 0;
	lightbar_start();
	game_draw();
}

static void end_game(uint8_t stopped)
{
	lightbar_off();

	uint16_t score = game_get_score();
	int8_t rank = highscore_submit(score);

	printf_P(PSTR("Game %s, score %u\r\n"), stopped ? "stopped" : "over", score);

	state = STATE_GAME_OVER;
	show_game_over(stopped, score, rank);
}

static void run_test_action(uint8_t action)
{
	static const char t_cal[]  PROGMEM = "CALIBRATION";
	static const char t_sram[] PROGMEM = "SRAM TEST";
	static const char t_hs[]   PROGMEM = "HIGHSCORES";

	switch (action)
	{
		case TEST_CALIBRATE:
		show_message(t_cal, PSTR("Release joystick..."));
		_delay_ms(800);
		joystick_calibrate();
		joystick_print_calibration();
		show_message(t_cal, PSTR("Centre calibrated."));
		state = STATE_MESSAGE;
		break;

		case TEST_LIVE:
		state = STATE_LIVE_TEST;
		live_counter = 0;
		draw_live_test();
		break;

		case TEST_SRAM:
		{
			show_message(t_sram, PSTR("Running..."));

			// The test overwrites 0x1800..0x1FFF, which includes the
			// framebuffer -- the screen is rebuilt from scratch below.
			uint16_t errors = sram_test();

			oled_clear();
			menu_draw_title(t_sram);
			oled_goto(2, 1);
			oled_printf_P(PSTR("Errors: %u"), errors);
			draw_footer_P(PSTR("B1: back"));
			oled_flush();

			state = STATE_MESSAGE;
			break;
		}

		case TEST_RESET_HS:
		highscore_reset();
		show_message(t_hs, PSTR("Highscores cleared."));
		state = STATE_MESSAGE;
		break;

		default:            // Back
		enter_main_menu();
		break;
	}
}

// ---------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------
int main(void)
{
	DDRE |= (1 << PE2);   // heartbeat LED

	uart_init();
	timer_init();
	sei();

	xmem_init();          // framebuffer lives in external SRAM
	adc_init();
	spi_init();
	oled_init();
	input_init();
	highscore_init();
	lightbar_off();       // IO board LEDs may still be on from before a reset

	joystick_calibrate();

	printf_P(PSTR("\r\nNode 1 -- Pong\r\n"));

	enter_main_menu();

	uint16_t last_frame = timer_millis();
	uint16_t last_heartbeat = last_frame;

	while (1)
	{
		uint16_t now = timer_millis();

		if ((uint16_t)(now - last_frame) < FRAME_MS)
		continue;

		// Resynchronise to the current time rather than adding FRAME_MS:
		// if a frame overruns, the loop drops it instead of trying to
		// catch up with a burst of back-to-back frames.
		last_frame = now;

		joystick_position_t pos = joystick_get_position();
		input_event_t event = input_poll(now, pos.x, pos.y);

		switch (state)
		{
			case STATE_MAIN_MENU:
			{
				int8_t choice = menu_handle(&nav, event);

				if (choice == MAIN_START)
				start_game();
				else if (choice == MAIN_HIGHSCORES)
				{
					state = STATE_HIGHSCORES;
					show_highscores();
				}
				else if (choice == MAIN_CAL_TEST)
				enter_test_menu();
				break;
			}

			case STATE_GAME:
			if (event == INPUT_SELECT)
			{
				pause_game();       // B1 pauses the game
				break;
			}

			if (game_update(pos.x) == GAME_OVER)
			{
				end_game(0);
				break;
			}

			game_draw();
			lightbar_update();
			break;

			case STATE_PAUSED:
			// A new press starts the hold timer. The press that
			// paused the game does not count: it happened before
			// this state was entered.
			if (event == INPUT_SELECT)
			{
				pause_holding = 1;
				pause_press_start = now;
				break;
			}

			if (pause_holding)
			{
				uint16_t held = now - pause_press_start;

				if (!input_select_state())
				{
					resume_game();      // released early: resume
					break;
				}

				if (held >= STOP_HOLD_MS)
				{
					end_game(1);        // held long enough: stop
					break;
				}

				show_pause((uint8_t)(held / (STOP_HOLD_MS / 100)));
			}
			break;

			case STATE_GAME_OVER:
			case STATE_HIGHSCORES:
			if (event == INPUT_SELECT || event == INPUT_LEFT)
			enter_main_menu();
			break;

			case STATE_TEST_MENU:
			{
				int8_t choice = menu_handle(&nav, event);

				if (choice == MENU_BACK)
				enter_main_menu();
				else if (choice >= 0)
				run_test_action((uint8_t)choice);
				break;
			}

			case STATE_LIVE_TEST:
			if (event == INPUT_SELECT || event == INPUT_LEFT)
			{
				enter_test_menu();
				break;
			}

			if (++live_counter >= LIVE_TEST_DIVIDER)
			{
				live_counter = 0;
				draw_live_test();
			}
			draw_live_position(pos.x, pos.y);
			break;

			case STATE_MESSAGE:
			if (event == INPUT_SELECT || event == INPUT_LEFT)
			enter_test_menu();
			break;
		}

		if ((uint16_t)(now - last_heartbeat) >= 250)
		{
			last_heartbeat = now;
			PORTE ^= (1 << PE2);
		}
	}
}
