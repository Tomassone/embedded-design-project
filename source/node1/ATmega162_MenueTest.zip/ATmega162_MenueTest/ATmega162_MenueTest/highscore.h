#ifndef HIGHSCORE_H
#define HIGHSCORE_H

#include <stdint.h>

#define HIGHSCORE_COUNT  5

// Highscores are kept in the ATmega162's internal EEPROM, so they
// survive power cycles. Loads them, or initialises the table on first
// use. Call once at startup.
void highscore_init(void);

// Score at a rank, 0 = best.
uint16_t highscore_get(uint8_t rank);

// Enters a score if it makes the table. Returns its rank (0 = best),
// or -1 if it did not qualify.
int8_t highscore_submit(uint16_t score);

void highscore_reset(void);

#endif // HIGHSCORE_H
