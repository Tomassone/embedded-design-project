#ifndef MENU_H
#define MENU_H

#include <stdint.h>
#include "input.h"

// A menu is a title plus a list of entries. All strings live in flash:
//
//   static const char item_a[] PROGMEM = "Start game";
//   static const char * const items[] PROGMEM = { item_a, ... };
//   static const menu_t my_menu = { title, items, count };
//
// Sub-menus are just further menu_t objects -- the caller decides what
// selecting an entry does, including opening another menu.
typedef struct {
    const char *title_P;
    const char * const *items_P;
    uint8_t count;
} menu_t;

// Navigation state for the menu currently on screen.
typedef struct {
    const menu_t *menu;
    uint8_t selected;
    uint8_t first_visible;      // for menus longer than the screen
} menu_nav_t;

// Returned by menu_handle() when nothing was chosen, or the user asked
// to go back (joystick left).
#define MENU_NONE   (-1)
#define MENU_BACK   (-2)

// Opens a menu with the first entry selected and draws it.
void menu_open(menu_nav_t *nav, const menu_t *menu);

// Redraws the current menu, e.g. after returning from a screen.
void menu_draw(const menu_nav_t *nav);

// Processes one input event. Up/down move the selection and redraw.
// Returns the chosen index on SELECT, MENU_BACK on LEFT, else MENU_NONE.
int8_t menu_handle(menu_nav_t *nav, input_event_t event);

// Draws a title bar across text line 0 -- shared by menus and screens,
// so everything in the UI looks alike.
void menu_draw_title(const char *title_P);

#endif // MENU_H
