#ifndef SPI_H
#define SPI_H

#include <stdint.h>

// Slave select lines. Order matters only in that each must be unique.
typedef enum {
	SPI_SLAVE_NONE,
	SPI_SLAVE_DISPLAY,
	SPI_SLAVE_IOBOARD,
	SPI_SLAVE_CAN
} spi_slave_t;

// Configures the SPI hardware as master and sets all slave select
// lines as outputs, idling high. Call once at startup.
void spi_init(void);

// Asserts one slave's select line. Deasserts all others first, so two
// slaves can never drive MISO at the same time.
void spi_select(spi_slave_t slave);

// Deasserts all slave select lines.
void spi_deselect(void);

// Exchanges one byte. SPI is full duplex: the byte sent out and the
// byte clocked in happen simultaneously, so a "write" also yields a
// read and vice versa. Pass a dummy value when only reading.
uint8_t spi_transfer(uint8_t data);

// Convenience wrappers over spi_transfer() for the common cases.
void spi_write(uint8_t data);
uint8_t spi_read(void);

// Block transfers. Slave selection is the caller's responsibility --
// these do not select or deselect, so multi-part transactions stay
// within a single assertion of the chip select.
void spi_write_bytes(const uint8_t *data, uint16_t length);
void spi_read_bytes(uint8_t *buffer, uint16_t length);

#endif // SPI_H