#ifndef OLED_TEXT_H
#define OLED_TEXT_H

#include <stdint.h>

// --- Font ------------------------------------------------------------
// Built-in 5x7 ASCII font, printable range 0x20..0x7E, stored in flash.
#define FONT_WIDTH         5
#define FONT_HEIGHT        7
#define FONT_FIRST         0x20
#define FONT_LAST          0x7E

// --- Character cell --------------------------------------------------
// 5x7 glyph plus 1 column and 1 row of spacing.
#define OLED_CHAR_WIDTH    6
#define OLED_CHAR_HEIGHT   8

// Text grid for the cursor-based functions.
#define OLED_TEXT_COLUMNS  21     // 128 / 6
#define OLED_TEXT_LINES    8      // 64 / 8, one per display page

// All functions draw into the framebuffer only.
// Call oled_flush() afterwards to show the result.

// --- Free positioning, in pixels. Text can sit anywhere on screen.
void oled_draw_char(uint8_t x, uint8_t y, char c);
void oled_draw_string(uint8_t x, uint8_t y, const char *str);
void oled_draw_string_P(uint8_t x, uint8_t y, const char *str_P);

// --- Cursor-based, in character cells. Wraps at the line end,
// --- '\n' starts a new line, wraps back to line 0 after line 7.
void oled_home(void);
void oled_goto(uint8_t line, uint8_t column);
void oled_goto_line(uint8_t line);
void oled_goto_column(uint8_t column);
void oled_clear_line(uint8_t line);

void oled_putchar(char c);
void oled_print(const char *str);
void oled_print_P(const char *str_P);

// printf onto the display at the cursor. The format string lives in
// flash: oled_printf_P(PSTR("Score: %u"), score);
void oled_printf_P(const char *fmt_P, ...);

// Inverted text: light background, dark glyphs. Useful for
// highlighting the selected entry in a menu.
void oled_set_inverted(uint8_t on);

#endif // OLED_TEXT_H