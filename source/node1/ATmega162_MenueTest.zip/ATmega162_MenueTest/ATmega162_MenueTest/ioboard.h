#ifndef IOBOARD_H
#define IOBOARD_H

#include <stdint.h>

// Command bytes, per the IO board documentation.
#define IOB_CMD_TOUCHPAD   0x01
#define IOB_CMD_SLIDER     0x02
#define IOB_CMD_JOYSTICK   0x03
#define IOB_CMD_BUTTONS    0x04
#define IOB_CMD_LED        0x05
#define IOB_CMD_LED_PWM    0x06
#define IOB_CMD_INFO       0x07

#define IOB_INFO_LENGTH    35
#define IOB_LED_COUNT      6

typedef struct {
	uint8_t x;
	uint8_t y;
	uint8_t size;   // signal strength, ~ proportion of pad touched
} ioboard_touchpad_t;

typedef struct {
	uint8_t x;
	uint8_t size;
} ioboard_slider_t;

typedef struct {
	uint8_t x;
	uint8_t y;
	uint8_t btn;
} ioboard_joystick_t;

// Bit layout from the IO board documentation. avr-gcc allocates
// bitfields LSB first, so R1/L1/NB map to bit 0 of their byte.
typedef struct __attribute__((packed)) {
	union {
		uint8_t right;
		struct {
			uint8_t R1:1;
			uint8_t R2:1;
			uint8_t R3:1;
			uint8_t R4:1;
			uint8_t R5:1;
			uint8_t R6:1;
		};
	};
	union {
		uint8_t left;
		struct {
			uint8_t L1:1;
			uint8_t L2:1;
			uint8_t L3:1;
			uint8_t L4:1;
			uint8_t L5:1;
			uint8_t L6:1;
			uint8_t L7:1;
		};
	};
	union {
		uint8_t nav;
		struct {
			uint8_t NB:1;   // nav button (press)
			uint8_t NR:1;   // right
			uint8_t ND:1;   // down
			uint8_t NL:1;   // left
			uint8_t NU:1;   // up
		};
	};
} ioboard_buttons_t;

ioboard_touchpad_t ioboard_read_touchpad(void);
ioboard_slider_t   ioboard_read_slider(void);
ioboard_joystick_t ioboard_read_joystick(void);
ioboard_buttons_t  ioboard_read_buttons(void);

// led: 0..5, on: nonzero = on
void ioboard_set_led(uint8_t led, uint8_t on);

// led: 0..5, width: PWM width, 255 = full brightness
void ioboard_set_led_pwm(uint8_t led, uint8_t width);

// Reads the 35-byte info block: 19 bytes firmware timestamp
// (YYYY-MM-DDTHH:mm:ss), then 16 bytes serial number.
// buffer must hold at least IOB_INFO_LENGTH bytes.
void ioboard_read_info(uint8_t *buffer);

#endif // IOBOARD_H