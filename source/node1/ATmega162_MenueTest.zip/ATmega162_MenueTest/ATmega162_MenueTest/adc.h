#ifndef ADC_H
#define ADC_H

#include <stdint.h>

// The ADC lives in the 0x1000-0x17FF half of the external memory map
// (A11 = 0). Any address in that range selects it -- it has no address
// lines of its own, only a chip select derived from A11.
#define ADC_BASE_ADDR   0x1000

// Channel assignment as wired on the breadboard:
//   AIN0 = joystick Y
//   AIN1 = joystick X
//   AIN2, AIN3 currently unconnected
#define ADC_CH_JOY_Y    0
#define ADC_CH_JOY_X    1

// Sets up Timer1 to generate the ADC's external clock on PD5 (OC1A).
// The MAX156 has no internal oscillator and will not convert without it.
// Call once at startup, after xmem_init().
void adc_init(void);

// Starts a conversion and returns the 8-bit result for one channel.
uint8_t adc_read_channel(uint8_t channel);

// Reads all four channels in one go, into a caller-provided array of 4.
// With MODE tied high the results come out on consecutive RD pulses,
// which is cheaper than four separate conversions.
void adc_read_all(uint8_t *results);

#endif // ADC_H