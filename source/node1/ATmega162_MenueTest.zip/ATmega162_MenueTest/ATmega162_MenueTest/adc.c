// F_CPU must be defined BEFORE <util/delay.h> is included, otherwise
// delay.h warns and falls back to its own assumed frequency.
#ifndef F_CPU
#define F_CPU 4915200UL
#endif

#include "adc.h"
#include <avr/io.h>
#include <util/delay.h>

// Memory-mapped handle to the ADC. volatile is essential: without it the
// compiler may optimise away a read that follows a write to the same
// location, since it has no way to know the value changes on its own.
static volatile uint8_t *adc = (uint8_t *)ADC_BASE_ADDR;

// ---------------------------------------------------------------------
// adc_init()
// Timer1 in CTC mode, toggling OC1A (PD5) on each compare match.
// Output frequency = F_CPU / (2 * (1 + OCR1A))
//   OCR1A = 1 -> 4.9152 MHz / 4 = 1.2288 MHz
//
// VERIFY against the MAX156 datasheet: check its permitted clock range
// and adjust OCR1A if 1.2288 MHz falls outside it.
// ---------------------------------------------------------------------
void adc_init(void)
{
	DDRD |= (1 << PD5);   // OC1A as output

	OCR1A = 1;

	// COM1A0 = toggle OC1A on compare match
	// WGM12  = CTC mode, TOP = OCR1A
	// CS10   = no prescaler
	TCCR1A = (1 << COM1A0);
	TCCR1B = (1 << WGM12) | (1 << CS10);
}

// ---------------------------------------------------------------------
// adc_read_channel()
// Writing to the ADC's address range issues a WR pulse and starts a
// conversion; the written byte selects the channel. The following read
// issues an RD pulse and returns the result.
//
// VERIFY against the datasheet (Table 1 and Table 4): with MODE tied to
// a fixed level the config register is largely bypassed -- confirm the
// channel really is selected by the written byte, and in which bits.
// ---------------------------------------------------------------------
uint8_t adc_read_channel(uint8_t channel)
{
	*adc = channel;    // WR pulse: start conversion on this channel

	// BUSY is left unconnected on this board, so completion can't be
	// polled and we wait blind instead. 10 us is a generous margin at
	// a 1.2288 MHz ADC clock. If you later wire BUSY to a spare pin,
	// replace this with a proper poll.
	_delay_us(10);

	return *adc;       // RD pulse: fetch the result
}

// ---------------------------------------------------------------------
// adc_read_all()
// One conversion start, then four consecutive reads -- results come out
// in channel order AIN0, AIN1, AIN2, AIN3.
// ---------------------------------------------------------------------
void adc_read_all(uint8_t *results)
{
	*adc = 0x00;       // start conversion sequence from channel 0

	_delay_us(20);     // longer margin: four conversions, not one

	for (uint8_t i = 0; i < 4; i++)
	{
		results[i] = *adc;
	}
}