#include "uart.h"
#include <avr/io.h>
#include <avr/interrupt.h>

// ---------------------------------------------------------------------
// Clock / baud rate configuration
// F_CPU and BAUD are normally defined in main.c before uart.h is
// included there. The #ifndef guards below only provide a fallback
// in case uart.c is compiled without them (e.g. as part of a
// separate library build), so this file still compiles standalone.
// ---------------------------------------------------------------------

#ifndef F_CPU
#define F_CPU 4915200UL
#endif

#ifndef BAUD
#define BAUD 9600UL
#endif

// UBRR (USART Baud Rate Register) value for the chosen F_CPU/BAUD pair.
// Formula from the ATmega162 datasheet for asynchronous normal mode.
#define UBRR_VALUE ((F_CPU / (16UL * BAUD)) - 1)

// ---------------------------------------------------------------------
// Ring buffers
//
// Both RX and TX use a classic circular buffer with two indices:
//   head = next free slot to write into
//   tail = next slot to read from
// Buffer is empty when head == tail, and "full" is detected by
// checking whether advancing head would collide with tail (see
// the ISR / putchar code below). This avoids needing a separate
// "count" variable that both ISR and main code would have to
// keep in sync.
//
// Sizes are chosen generously for headroom; they don't need to be
// a power of two here since we use % for wraparound instead of a
// bitmask, but power-of-two sizes make that modulo operation cheap
// for the compiler.
// ---------------------------------------------------------------------

#define RX_BUF_SIZE 16
#define TX_BUF_SIZE 32

// All buffer state is 'volatile' because it's written from an ISR
// and read from main code (or vice versa) -- without 'volatile' the
// compiler could cache values in registers and miss updates made
// by the interrupt.
static volatile uint8_t rx_buf[RX_BUF_SIZE];
static volatile uint8_t rx_head = 0;   // written by the RX ISR
static volatile uint8_t rx_tail = 0;   // written by uart_getchar()

static volatile uint8_t tx_buf[TX_BUF_SIZE];
static volatile uint8_t tx_head = 0;   // written by uart_putchar()
static volatile uint8_t tx_tail = 0;   // written by the TX ISR

// Single stdio stream, connected to both stdin and stdout in uart_init().
// Declared 'extern' in uart.h so main.c can reference it if needed;
// this is the one place it's actually allocated.
FILE uart_stream;

// ---------------------------------------------------------------------
// uart_init()
// Configures USART0 for interrupt-driven operation and hooks it up
// to the C standard I/O functions (printf, getchar, ...).
// ---------------------------------------------------------------------

void uart_init(void)
{
	// Set baud rate. UBRR is a 12-bit value split across two registers.
	UBRR0H = (uint8_t)(UBRR_VALUE >> 8);
	UBRR0L = (uint8_t)UBRR_VALUE;

	// Frame format: 8 data bits, no parity, 1 stop bit (8N1).
	// URSEL0 must be set when writing UCSR0C on the ATmega162, because
	// UCSR0C and UBRR0H share the same I/O address; URSEL0 tells the
	// hardware which register this write is meant for.
	UCSR0C = (1 << URSEL0) | (1 << UCSZ01) | (1 << UCSZ00);

	// Enable receiver, transmitter, and the "RX complete" interrupt.
	// The "data register empty" interrupt (UDRIE0) is intentionally
	// NOT enabled here -- it gets turned on only while there's data
	// queued to send (see uart_putchar), and turned back off by the
	// TX ISR once the buffer runs dry. Leaving it always-on would
	// cause a continuous stream of interrupts whenever there's
	// nothing to transmit.
	UCSR0B = (1 << RXEN0) | (1 << TXEN0) | (1 << RXCIE0);

	// Connect uart_putchar/uart_getchar as the low-level read/write
	// functions for this stream, then route stdout/stdin through it.
	// After this call, printf()/getchar()/scanf() etc. all go over UART0.
	fdev_setup_stream(&uart_stream, uart_putchar, uart_getchar, _FDEV_SETUP_RW);
	stdout = &uart_stream;
	stdin  = &uart_stream;
}

// ---------------------------------------------------------------------
// RX interrupt: fires automatically whenever a complete byte has been
// received by the hardware. Keep ISRs short -- this one just stores
// the byte and returns; nothing here blocks or waits.
// ---------------------------------------------------------------------

ISR(USART0_RXC_vect)
{
	// Reading UDR0 both retrieves the received byte and clears the
	// interrupt flag that triggered this ISR -- this read is mandatory,
	// even if the byte ends up being dropped below.
	uint8_t data = UDR0;

	uint8_t next_head = (rx_head + 1) % RX_BUF_SIZE;

	// If next_head would equal rx_tail, the buffer is full: the byte
	// is silently dropped rather than overwriting unread data. Main
	// code should call uart_getchar() often enough that this doesn't
	// happen in practice; add an overflow counter here later if you
	// need to detect/debug it.
	if (next_head != rx_tail)
	{
		rx_buf[rx_head] = data;
		rx_head = next_head;
	}
}

// ---------------------------------------------------------------------
// TX interrupt: fires whenever the hardware transmit register (UDR0)
// is free to accept a new byte. This interrupt is only enabled while
// there's data waiting in tx_buf (see uart_putchar / the 'else' branch
// below).
// ---------------------------------------------------------------------

ISR(USART0_UDRE_vect)
{
	if (tx_tail != tx_head)
	{
		// Still bytes queued -- send the next one and advance tail.
		UDR0 = tx_buf[tx_tail];
		tx_tail = (tx_tail + 1) % TX_BUF_SIZE;
	}
	else
	{
		// Buffer empty: nothing left to send, so disable this
		// interrupt. Otherwise it would keep firing continuously
		// since UDRE0 stays set whenever UDR0 is free.
		UCSR0B &= ~(1 << UDRIE0);
	}
}

// ---------------------------------------------------------------------
// uart_putchar()
// The "put" function used by the stdio stream (called internally by
// printf, puts, etc.). Queues one character for transmission and
// returns immediately -- actual sending happens in the background
// via the TX ISR above.
// ---------------------------------------------------------------------

int uart_putchar(char c, FILE *stream)
{
	// Translate '\n' to CR+LF, since most terminal programs expect
	// a carriage return before the line feed.
	if (c == '\n')
	uart_putchar('\r', stream);

	uint8_t next_head = (tx_head + 1) % TX_BUF_SIZE;

	// If the buffer is full, wait here until the ISR has freed up
	// space by sending more bytes. This is the only blocking point
	// left in the UART code, and only triggers if you're sending
	// faster than the baud rate allows the buffer to drain.
	while (next_head == tx_tail)
	;

	tx_buf[tx_head] = c;
	tx_head = next_head;

	// Make sure the "data register empty" interrupt is enabled so
	// the byte we just queued actually gets sent. Safe to set this
	// every call: if it's already enabled, this is a no-op.
	UCSR0B |= (1 << UDRIE0);

	return 0;
}

// ---------------------------------------------------------------------
// uart_getchar()
// The "get" function used by the stdio stream (called internally by
// getchar, scanf, etc.). Blocks until a byte is available in the RX
// buffer -- use uart_available() beforehand if you need a non-blocking
// check first.
// ---------------------------------------------------------------------

int uart_getchar(FILE *stream)
{
	while (rx_tail == rx_head)
	;  // buffer empty -> wait for the RX ISR to deliver a byte

	uint8_t data = rx_buf[rx_tail];
	rx_tail = (rx_tail + 1) % RX_BUF_SIZE;
	return data;
}

// ---------------------------------------------------------------------
// uart_available()
// Returns non-zero if at least one received byte is waiting to be
// read. Use this to poll the UART without blocking, e.g. in a main
// loop that also needs to do other work.
// ---------------------------------------------------------------------

uint8_t uart_available(void)
{
	return (rx_head != rx_tail);
}