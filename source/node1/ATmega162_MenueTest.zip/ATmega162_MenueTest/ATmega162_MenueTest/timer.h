#ifndef TIMER_H
#define TIMER_H

#include <stdint.h>

// 1 ms system tick on Timer3. Timer1 is taken by the ADC clock, and
// Timer0/Timer2 have their compare outputs on display control pins.
void timer_init(void);

// Milliseconds since timer_init(). Wraps after ~65 s -- always compare
// with a subtraction, e.g. (uint16_t)(now - start) >= 500.
uint16_t timer_millis(void);

#endif // TIMER_H
