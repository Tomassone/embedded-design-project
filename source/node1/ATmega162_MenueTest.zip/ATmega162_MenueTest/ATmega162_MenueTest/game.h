#ifndef GAME_H
#define GAME_H

#include <stdint.h>

typedef enum {
    GAME_RUNNING,
    GAME_OVER
} game_status_t;

// Single-player Pong: keep the ball in play with the paddle. Each
// return scores a point and speeds the ball up. Three lives.
void game_start(void);

// Advances the game by one frame. joy_x is the joystick X position
// (-90..+90), which sets the paddle position.
game_status_t game_update(int16_t joy_x);

// Renders the current state and sends it to the display.
void game_draw(void);

uint16_t game_get_score(void);

#endif // GAME_H
