#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <stdint.h>

// ---------------------------------------------------------------------
// Application protocol for the CAN bus between node 1 and node 2.
//
// CAN has no addressing: every node receives every frame and decides
// by the identifier whether it is interested. The ID therefore names
// the MESSAGE TYPE, not a recipient.
//
// The ID also sets the priority: on simultaneous transmission the
// LOWER ID wins arbitration. Hence the ordering below -- control
// messages that steer the motor outrank status reports.
//
// Node 2 must use the same table. It is the only place where the two
// nodes need to agree, apart from the bit timing.
// ---------------------------------------------------------------------

// --- Node 1 -> Node 2 ---
#define CAN_ID_JOYSTICK     0x100   // 3 bytes: x, y, buttons
#define CAN_ID_GAME_CMD     0x101   // 1 byte: game_cmd_t

// --- Node 2 -> Node 1 ---
#define CAN_ID_GOAL         0x200   // 1 byte: new score
#define CAN_ID_NODE2_STATUS 0x201   // 1 byte: node2_status_t

// Commands to node 2. Deliberately explicit rather than a bare flag,
// so a lost frame cannot leave the two nodes in opposite states.
typedef enum {
	GAME_CMD_STOP  = 0,
	GAME_CMD_START = 1,
	GAME_CMD_PAUSE = 2
} game_cmd_t;

typedef enum {
	NODE2_IDLE    = 0,
	NODE2_RUNNING = 1,
	NODE2_ERROR   = 2
} node2_status_t;

// What node 1 last heard from node 2.
typedef struct {
	uint8_t score;          // goals counted by node 2
	uint8_t status;         // node2_status_t
	uint8_t seen;           // 1 once any frame from node 2 has arrived
} node2_state_t;

// Sends the joystick position. x and y are -90..+90, buttons is a bit
// field. Returns 0 on success, nonzero if the transmit buffer is busy.
uint8_t protocol_send_joystick(int8_t x, int8_t y, uint8_t buttons);

// Sends a game command to node 2.
uint8_t protocol_send_command(game_cmd_t cmd);

// Fetches and dispatches one pending CAN message. Call once per frame.
// Returns 1 if a message was processed.
uint8_t protocol_poll(void);

// Everything node 1 knows about node 2.
const node2_state_t *protocol_node2(void);

void protocol_reset_state(void);

#endif // PROTOCOL_H