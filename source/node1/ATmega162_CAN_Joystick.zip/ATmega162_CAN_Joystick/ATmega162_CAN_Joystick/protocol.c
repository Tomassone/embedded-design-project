#include "protocol.h"
#include "can.h"

static node2_state_t node2;

uint8_t protocol_send_joystick(int8_t x, int8_t y, uint8_t buttons)
{
	can_message_t msg;

	msg.id = CAN_ID_JOYSTICK;
	msg.length = 3;
	msg.data[0] = (uint8_t)x;       // two's complement survives the cast
	msg.data[1] = (uint8_t)y;
	msg.data[2] = buttons;

	return can_send(&msg);
}

uint8_t protocol_send_command(game_cmd_t cmd)
{
	can_message_t msg;

	msg.id = CAN_ID_GAME_CMD;
	msg.length = 1;
	msg.data[0] = (uint8_t)cmd;

	return can_send(&msg);
}

uint8_t protocol_poll(void)
{
	can_message_t msg;

	if (!can_receive(&msg))
	return 0;

	switch (msg.id)
	{
		case CAN_ID_GOAL:
		if (msg.length >= 1)
		node2.score = msg.data[0];
		node2.seen = 1;
		break;

		case CAN_ID_NODE2_STATUS:
		if (msg.length >= 1)
		node2.status = msg.data[0];
		node2.seen = 1;
		break;

		default:
		// Unknown ID. In normal mode node 1 also receives its own
		// bus traffic only if another node transmits it, so this
		// is simply a message type we do not handle yet.
		break;
	}

	return 1;
}

const node2_state_t *protocol_node2(void)
{
	return &node2;
}

void protocol_reset_state(void)
{
	node2.score = 0;
	node2.status = NODE2_IDLE;
	node2.seen = 0;
}