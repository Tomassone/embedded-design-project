#ifndef CAN_H
#define CAN_H

#include <stdint.h>

// ---------------------------------------------------------------------
// High-level CAN messaging. The interface uses no MCP2515 types or
// registers, so node 2 can offer the same functions on top of its own
// controller and the application code stays the same on both nodes.
// ---------------------------------------------------------------------

#define CAN_MAX_DATA  8

typedef struct {
	uint16_t id;                    // 11-bit standard identifier
	uint8_t length;                 // number of data bytes, 0..8
	uint8_t data[CAN_MAX_DATA];
} can_message_t;

typedef enum {
	CAN_MODE_NORMAL,
	CAN_MODE_LOOPBACK               // messages are received by the sender
} can_mode_t;

// Error state of the controller. In normal mode a node alone on the
// bus gets no acknowledge, so tx_errors climbs with every attempt --
// this is the first thing to look at when nothing gets through.
typedef struct {
	uint8_t tx_errors;              // transmit error counter (TEC)
	uint8_t rx_errors;              // receive error counter (REC)
	uint8_t bus_off;                // TEC passed 255, node has left the bus
	uint8_t error_passive;          // a counter passed 127
	uint8_t rx_overflow;            // a receive buffer was overwritten
} can_error_t;

// Initialises the controller: bit timing, receive all messages,
// receive interrupt on INT0, then switches to the given mode.
// Returns 0 on success, nonzero if the controller did not respond.
uint8_t can_init(can_mode_t mode);

// Switches between normal and loopback at runtime, without losing the
// bit timing or filter configuration.
uint8_t can_set_mode(can_mode_t mode);

// Queues a message for sending. Returns 0 on success, 1 if the
// transmit buffer is still busy with the previous message.
uint8_t can_send(const can_message_t *msg);

// Fetches a received message if one is waiting.
// Returns 1 and fills msg if there was one, else returns 0.
uint8_t can_receive(can_message_t *msg);

// Nonzero if the controller has signalled a received message via its
// interrupt line since the last can_receive(). Cheap to call: no SPI.
uint8_t can_rx_pending(void);

// Reads the error counters and flags.
void can_get_errors(can_error_t *err);

// Cancels a transmission still waiting for the bus. Without this a
// message that never gets acknowledged blocks the buffer forever,
// because the controller keeps retrying.
void can_abort_tx(void);

// Clears a bus-off condition by cycling through configuration mode.
// The controller then restarts with zeroed error counters.
uint8_t can_recover(void);

#endif // CAN_H