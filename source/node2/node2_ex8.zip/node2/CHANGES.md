# Changes since node2_can.zip (exercise 6)

## main.c

- `BAUDRATE` 9600 → 115200. At 9600 the link carries about 23 telemetry
  lines per second, too few for the live plot. Set 115200 in the
  config tool as well.
- `_Static_assert(LOOP_MS == CTRL_PERIOD_MS)`: the PID runs once per
  loop pass, and its sample time must match the loop period.
- `motor_init()` after `servo_init()`. Both use the PWM controller:
  servo on channel 1, motor on channel 0.
- `motor_home()` at start-up, then `tuning_init()`: the motor stays off
  until START.
- Joystick x now sets the **cart position** through the PID.
  Joystick y now drives the **servo** (was x).
- Joystick button fires the **solenoid**, only while the game runs.
- START switches the PID on. It first sets the setpoint to the current
  position, so the cart never jumps towards position 0.
- PAUSE holds the cart in place. STOP switches the motor off.
- `game_owns_motor()`: START/STOP from node 1 do not take over while
  the config tool tests the motor.
- `handle_uart()` passes `$` lines to `tuning_feed()` first. The test
  keys g, e, r, s still work. `s` now also prints motor mode and position.
- `tuning_tick()` once per loop: PID, safety stops, telemetry.

## New files

- **board.h** — every exercise 8 pin in one place, with a build warning
  until `BOARD_PINS_VERIFIED` is 1.
- **motor.c/h** — PWM at 20 kHz on the driver's enable pin, direction
  GPIO, encoder on TC2 in quadrature decoder mode (counts both edges of
  both phases, with the input filter), homing against the left end stop,
  joystick-to-position mapping with a margin before each end stop.
  Also implements `motor_hal.h` for `tuning.c`. Time comes from the
  existing `time_now()`, so no second timer is used.
- **solenoid.c/h** — edge-triggered shot, 80 ms pulse, 400 ms cooldown.
  Holding the button cannot keep the coil energised.
- **pid.c/h** — parallel PID. D on the measurement (no kick on setpoint
  steps), low-pass filtered D, anti-windup by conditional integration.
- **tuning.c/h** — config tool protocol. Safety: PC-driven modes stop
  after 1.5 s without the PC, and open loop / relay stop at the soft
  limits.
- **motor_hal.h** — the four functions `tuning.c` needs from the
  hardware.

## Unchanged

`can.c/h`, `protocol.c/h`, and your `uart.*`, `time.*`, `sam/`.
Node 1 needs no changes.

## Verification

- All files compile for Cortex-M3 with `-Wall -Wextra` against the SAM3X
  CMSIS headers. The only warning is the intended `board.h` reminder.
- The only external symbols are `SystemInit`, `time_now`, `uart_init`,
  `uart_rx` (your starter files) and the C library.
- Joystick mapping: x = −90 → 200, 0 → 2800, +90 → 5400 counts.
  Every int8 input stays inside the margins and the mapping is monotonic.
- `pid.c` and `tuning.c` ran against a motor-and-cart simulation with
  the config tool: autotune, step test, link timeout and soft limits.
