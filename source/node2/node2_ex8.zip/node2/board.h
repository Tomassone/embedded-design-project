#pragma once
// ---------------------------------------------------------------------
// board.h -- every exercise 8 pin and constant in one place
//
// !!! CHECK EVERY PIN BELOW AGAINST THE NODE 2 SHIELD SCHEMATIC IN THE
// !!! LAB MANUAL BEFORE THE FIRST POWER-UP WITH THE MOTOR CONNECTED.
//
// The defaults are a common Arduino Due choice (hardware quadrature
// decoder on TC2), not values taken from your manual. When all pins are
// confirmed, set BOARD_PINS_VERIFIED to 1 to silence the build warning.
// ---------------------------------------------------------------------

#define BOARD_PINS_VERIFIED   0

#if !BOARD_PINS_VERIFIED
#warning "board.h: exercise 8 pins not verified against the shield schematic"
#endif

// ---- Motor driver: direction pin + PWM on the enable pin ------------
//
// Default: PWM channel 0 on PB12 = PWMH0 (peripheral B, Arduino D20).
//          Direction on PC23 (Arduino D7).
// The servo uses PWM channel 1 (PB13), so channel 0 is free.
#define MOTOR_PWM_PIO         PIOB
#define MOTOR_PWM_PIN         PIO_PB12B_PWMH0
#define MOTOR_PWM_PERIPH_B    1           // 1 = peripheral B, 0 = A
#define MOTOR_PWM_CHANNEL     0
#define MOTOR_PWM_FREQ_HZ     20000u      // above hearing, typical for H-bridges

#define MOTOR_DIR_PIO         PIOC
#define MOTOR_DIR_PIO_ID      ID_PIOC
#define MOTOR_DIR_PIN         PIO_PC23

// 1 if the DIR pin high must mean "towards larger encoder counts" is
// wrong on your board. Check with the config tool: Manual tab, open loop,
// +u must increase the position.
#define MOTOR_DIR_INVERT      0

// ---- Encoder: TC2 channel 0 in quadrature decoder mode ---------------
//
// Default: PC25 = TIOA6 (Arduino D5), PC26 = TIOB6 (Arduino D4).
#define ENCODER_PIO           PIOC
#define ENCODER_PIO_ID        ID_PIOC
#define ENCODER_PIN_A         PIO_PC25B_TIOA6
#define ENCODER_PIN_B         PIO_PC26B_TIOB6
#define ENCODER_INVERT        0           // 1 flips the count direction

// ---- Solenoid relay ---------------------------------------------------
//
// Default: PC22 (Arduino D8). Set the active level of your relay circuit.
#define SOLENOID_PIO          PIOC
#define SOLENOID_PIO_ID       ID_PIOC
#define SOLENOID_PIN          PIO_PC22
#define SOLENOID_ACTIVE_HIGH  1
#define SOLENOID_PULSE_MS     80          // how long the plunger is driven
#define SOLENOID_COOLDOWN_MS  400         // minimum time between shots

// ---- Cart travel and homing -------------------------------------------
//
// Encoder counts from the left end stop to the right end stop.
// Measure it once: home, then drive to the right end in open loop and
// read the position in the config tool.
#define MOTOR_TRAVEL_COUNTS   5600
#define MOTOR_MARGIN_COUNTS   200         // keep the setpoint off the end stops

// At start-up the cart is driven slowly to the left end stop and the
// encoder is zeroed there. 0 disables homing.
#define MOTOR_HOMING          1
#define MOTOR_HOMING_U        -350        // permille, negative = left
#define MOTOR_HOMING_MS       1500
