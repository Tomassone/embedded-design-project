// tuning.h -- PID tuning link between node 2 and the Ubuntu config tool
//
// All PC <-> node 2 traffic for the tuner is ASCII lines that start
// with '$'. Any other byte is left alone, so the existing test keys
// (g, e, r, s) in handle_uart() keep working.
//
// Integration (see INTEGRATION.md for the full snippet):
//   1. tuning_init() once after uart_init().
//   2. In handle_uart(): if (tuning_feed(c)) continue;
//   3. tuning_tick() once per control period (CTRL_PERIOD_MS).
//   4. tuning_set_game_setpoint() with the joystick target.

#ifndef TUNING_H
#define TUNING_H

#include <stdbool.h>
#include <stdint.h>

// Control period. Must match how often tuning_tick() is called.
#ifndef CTRL_PERIOD_MS
#define CTRL_PERIOD_MS  10
#endif

typedef enum
{
    TUNE_MODE_OFF   = 0,    // motor off
    TUNE_MODE_GAME  = 1,    // PID, setpoint from joystick (normal play)
    TUNE_MODE_PC    = 2,    // PID, setpoint from config tool
    TUNE_MODE_OPEN  = 3,    // open loop, motor command from config tool
    TUNE_MODE_RELAY = 4,    // relay feedback test for autotuning
} tune_mode_t;

void        tuning_init(void);
bool        tuning_feed(uint8_t c);
void        tuning_tick(void);

void        tuning_set_game_setpoint(int32_t counts);
void        tuning_set_mode(tune_mode_t m);
tune_mode_t tuning_mode(void);

#endif
