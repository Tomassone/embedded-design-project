#pragma once
#include <stdint.h>

// ---------------------------------------------------------------------
// solenoid.h -- exercise 8 shooter
//
// One short pulse per button press, with a cooldown so holding or
// bouncing the button cannot overheat the coil.
// ---------------------------------------------------------------------

void solenoid_init(void);

// Call once per loop pass with the current button state (1 = pressed)
// and whether shooting is allowed (game running). Fires on the press
// edge and ends the pulse by itself.
void solenoid_update(uint8_t pressed, uint8_t enabled);

// Releases the plunger immediately (STOP, fault).
void solenoid_off(void);
