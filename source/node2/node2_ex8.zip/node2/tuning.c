// tuning.c -- see tuning.h and PROTOCOL.md
//
// Numbers on the wire are integers only. printf("%f") is not linked
// by default with newlib-nano, and integers parse safely.
//   Gains     micro-units (1.0 = 1000000)
//   tf        microseconds
//   u         permille, -1000 .. +1000
//   position  encoder counts

#include "tuning.h"
#include "pid.h"
#include "motor_hal.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Optional: gains exported by the config tool ("Export header").
#if defined(__has_include)
#  if __has_include("pid_gains.h")
#    include "pid_gains.h"
#  endif
#endif

#ifndef PID_DEFAULT_KP
#define PID_DEFAULT_KP      0.5f    // permille / count
#endif
#ifndef PID_DEFAULT_KI
#define PID_DEFAULT_KI      0.0f    // permille / (count*s)
#endif
#ifndef PID_DEFAULT_KD
#define PID_DEFAULT_KD      0.0f    // permille*s / count
#endif
#ifndef PID_DEFAULT_TF
#define PID_DEFAULT_TF      0.02f   // s
#endif
#ifndef PID_DEFAULT_UMAX
#define PID_DEFAULT_UMAX    600     // permille
#endif

#define PROTO_VERSION       1
#define LINE_LEN            64
#define MAX_ARGS            5
#define LINK_TIMEOUT_MS     1500u   // PC-driven modes stop without $PING
#define UMAX_LIMIT          1000

static pid_ctrl_t  pid;
static tune_mode_t mode = TUNE_MODE_OFF;

static int32_t  game_sp;
static int32_t  pc_sp;
static int16_t  open_u;
static int16_t  u_max = PID_DEFAULT_UMAX;

static int16_t  relay_d;
static int32_t  relay_hyst;
static int32_t  relay_center;
static int8_t   relay_dir;

static bool     soft_on;
static int32_t  soft_lo;
static int32_t  soft_hi;

static uint8_t  stream_div;
static uint8_t  stream_cnt;
static uint32_t last_rx_ms;

static char     line[LINE_LEN];
static uint8_t  line_len;
static bool     in_line;
static bool     line_overflow;


// ---------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------

static int32_t to_micro(float x)
{
    return (int32_t)(x * 1e6f + (x >= 0.0f ? 0.5f : -0.5f));
}


static int32_t round_i(float x)
{
    return (int32_t)(x + (x >= 0.0f ? 0.5f : -0.5f));
}


static int32_t clamp_i(int32_t x, int32_t lo, int32_t hi)
{
    if (x < lo) return lo;
    if (x > hi) return hi;
    return x;
}


static bool needs_link(tune_mode_t m)
{
    return m == TUNE_MODE_PC || m == TUNE_MODE_OPEN || m == TUNE_MODE_RELAY;
}


static void print_gains(void)
{
    printf("$GAINS,%ld,%ld,%ld,%ld,%d\r\n",
           (long)to_micro(pid.kp), (long)to_micro(pid.ki),
           (long)to_micro(pid.kd), (long)to_micro(pid.tf), (int)u_max);
}


static void print_status(void)
{
    printf("$STATE,%d,%ld,%d,%ld,%ld,%d\r\n",
           (int)mode, (long)motor_hal_position(), (int)stream_div,
           (long)(soft_on ? soft_lo : 0), (long)(soft_on ? soft_hi : 0),
           CTRL_PERIOD_MS);
}


// ---------------------------------------------------------------------
// Mode handling
// ---------------------------------------------------------------------

void tuning_set_mode(tune_mode_t m)
{
    if (m > TUNE_MODE_RELAY)
        m = TUNE_MODE_OFF;

    motor_hal_set(0);
    pid_reset(&pid);

    int32_t pos = motor_hal_position();

    // Start PC setpoint at the current position: no jump on entry.
    if (m == TUNE_MODE_PC && mode != TUNE_MODE_PC)
        pc_sp = pos;

    if (m == TUNE_MODE_OPEN)
        open_u = 0;

    if (m == TUNE_MODE_RELAY)
        relay_dir = (relay_center - pos >= 0) ? 1 : -1;

    mode       = m;
    last_rx_ms = motor_hal_millis();
}


tune_mode_t tuning_mode(void)
{
    return mode;
}


void tuning_set_game_setpoint(int32_t counts)
{
    game_sp = counts;
}


// ---------------------------------------------------------------------
// Command parser
// ---------------------------------------------------------------------

static void handle_line(char *s)
{
    // Split "CMD,a,b,c" or "CMD a b c" into a keyword and integers.
    char   *tok  = strtok(s, ", \t");
    long    a[MAX_ARGS];
    uint8_t n    = 0;

    if (tok == NULL)
        return;

    char *cmd = tok;
    for (char *p = cmd; *p; p++)
        if (*p >= 'a' && *p <= 'z')
            *p = (char)(*p - 'a' + 'A');

    while ((tok = strtok(NULL, ", \t")) != NULL && n < MAX_ARGS)
    {
        char *end;
        a[n] = strtol(tok, &end, 10);
        if (*end != '\0')
        {
            printf("$ERR,%s,bad number\r\n", cmd);
            return;
        }
        n++;
    }

    last_rx_ms = motor_hal_millis();

    if (strcmp(cmd, "PING") == 0)
    {
        return;                         // keep-alive only, no reply
    }
    else if (strcmp(cmd, "HELLO") == 0)
    {
        printf("$HELLO,PIDTUNE,%d,%d\r\n", PROTO_VERSION, CTRL_PERIOD_MS);
        print_gains();
        print_status();
    }
    else if (strcmp(cmd, "GET") == 0)
    {
        print_gains();
        print_status();
    }
    else if (strcmp(cmd, "SET") == 0 && n == 4)
    {
        if (a[0] < 0 || a[1] < 0 || a[2] < 0 || a[3] < 0)
        {
            printf("$ERR,SET,negative gain\r\n");
            return;
        }
        pid_set_gains(&pid, (float)a[0] * 1e-6f, (float)a[1] * 1e-6f,
                      (float)a[2] * 1e-6f, (float)a[3] * 1e-6f);
        printf("$OK,SET\r\n");
        print_gains();
    }
    else if (strcmp(cmd, "LIM") == 0 && n == 1)
    {
        u_max     = (int16_t)clamp_i(a[0], 0, UMAX_LIMIT);
        pid.u_max = (float)u_max;
        printf("$OK,LIM\r\n");
        print_gains();
    }
    else if (strcmp(cmd, "MODE") == 0 && n == 1)
    {
        tuning_set_mode((tune_mode_t)clamp_i(a[0], 0, TUNE_MODE_RELAY));
        printf("$OK,MODE,%d\r\n", (int)mode);
    }
    else if (strcmp(cmd, "SP") == 0 && n == 1)
    {
        pc_sp = a[0];
        if (soft_on)
            pc_sp = clamp_i(pc_sp, soft_lo, soft_hi);
    }
    else if (strcmp(cmd, "U") == 0 && n == 1)
    {
        open_u = (int16_t)clamp_i(a[0], -u_max, u_max);
    }
    else if (strcmp(cmd, "RELAY") == 0 && n == 3)
    {
        relay_d      = (int16_t)clamp_i(a[0], 0, u_max);
        relay_hyst   = (a[1] < 0) ? 0 : a[1];
        relay_center = a[2];
        printf("$OK,RELAY\r\n");
    }
    else if (strcmp(cmd, "STREAM") == 0 && n == 1)
    {
        stream_div = (uint8_t)clamp_i(a[0], 0, 100);
        stream_cnt = 0;
        printf("$OK,STREAM,%d\r\n", (int)stream_div);
    }
    else if (strcmp(cmd, "SOFT") == 0 && n == 2)
    {
        soft_on = (a[0] < a[1]);
        soft_lo = a[0];
        soft_hi = a[1];
        printf("$OK,SOFT,%d\r\n", soft_on ? 1 : 0);
    }
    else if (strcmp(cmd, "ZERO") == 0)
    {
        tuning_set_mode(TUNE_MODE_OFF);
        motor_hal_zero();
        printf("$OK,ZERO\r\n");
        print_status();
    }
    else
    {
        printf("$ERR,%s,unknown or wrong argument count\r\n", cmd);
    }
}


bool tuning_feed(uint8_t c)
{
    if (!in_line)
    {
        if (c != '$')
            return false;               // not ours: legacy test key

        in_line       = true;
        line_len      = 0;
        line_overflow = false;
        return true;
    }

    if (c == '\r')
        return true;

    if (c == '\n')
    {
        in_line = false;
        if (line_overflow)
        {
            printf("$ERR,line too long\r\n");
            return true;
        }
        line[line_len] = '\0';
        handle_line(line);
        return true;
    }

    if (line_len < LINE_LEN - 1)
        line[line_len++] = (char)c;
    else
        line_overflow = true;

    return true;
}


// ---------------------------------------------------------------------
// Control loop
// ---------------------------------------------------------------------

void tuning_init(void)
{
    pid_init(&pid, CTRL_PERIOD_MS * 1e-3f, (float)u_max);
    pid_set_gains(&pid, PID_DEFAULT_KP, PID_DEFAULT_KI,
                  PID_DEFAULT_KD, PID_DEFAULT_TF);
    mode       = TUNE_MODE_OFF;
    last_rx_ms = motor_hal_millis();
}


void tuning_tick(void)
{
    uint32_t now = motor_hal_millis();
    int32_t  pos = motor_hal_position();

    // Safety 1: PC-driven modes need a live PC link.
    if (needs_link(mode) && (uint32_t)(now - last_rx_ms) > LINK_TIMEOUT_MS)
    {
        tuning_set_mode(TUNE_MODE_OFF);
        printf("$ERR,link timeout\r\n");
        print_status();
    }

    // Safety 2: open loop and relay stop outside the soft limits.
    if (soft_on && (mode == TUNE_MODE_OPEN || mode == TUNE_MODE_RELAY)
        && (pos < soft_lo || pos > soft_hi))
    {
        tuning_set_mode(TUNE_MODE_OFF);
        printf("$ERR,soft limit\r\n");
        print_status();
    }

    int32_t sp = pos;
    int16_t u  = 0;
    bool    pid_active = false;

    switch (mode)
    {
        case TUNE_MODE_GAME:
            sp = soft_on ? clamp_i(game_sp, soft_lo, soft_hi) : game_sp;
            u  = (int16_t)round_i(pid_update(&pid, (float)sp, (float)pos));
            pid_active = true;
            break;

        case TUNE_MODE_PC:
            sp = pc_sp;
            u  = (int16_t)round_i(pid_update(&pid, (float)sp, (float)pos));
            pid_active = true;
            break;

        case TUNE_MODE_OPEN:
            u = open_u;
            break;

        case TUNE_MODE_RELAY:
        {
            // Relay with hysteresis around relay_center (Astrom-Hagglund).
            // Positive u must increase the encoder count.
            int32_t e = relay_center - pos;
            if (relay_dir > 0 && e < -relay_hyst)
            {
                relay_dir = -1;
                printf("$R,%lu,-1,%ld\r\n", (unsigned long)now, (long)pos);
            }
            else if (relay_dir < 0 && e > relay_hyst)
            {
                relay_dir = 1;
                printf("$R,%lu,1,%ld\r\n", (unsigned long)now, (long)pos);
            }
            sp = relay_center;
            u  = (int16_t)(relay_dir * relay_d);
            break;
        }

        case TUNE_MODE_OFF:
        default:
            break;
    }

    motor_hal_set(u);

    if (stream_div && ++stream_cnt >= stream_div)
    {
        stream_cnt = 0;
        printf("$T,%lu,%ld,%ld,%d,%ld,%ld,%ld\r\n",
               (unsigned long)now, (long)sp, (long)pos, (int)u,
               (long)(pid_active ? round_i(pid.p_term) : 0),
               (long)(pid_active ? round_i(pid.i_term) : 0),
               (long)(pid_active ? round_i(pid.d_term) : 0));
    }
}
