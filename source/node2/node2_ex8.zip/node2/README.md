# Node 2 – exercise 8 (motor, PID, solenoid) + config tool link

Arduino Due / SAM3X8E. Builds on `node2_can.zip` (exercise 6) and adds the
position controller, the motor and encoder driver, the solenoid and the
link to the Byggern Config Tool.

## Files

| File | Status | Job |
|---|---|---|
| `main.c` | **changed** | game loop: joystick → cart (PID) and servo, button → solenoid |
| `board.h` | **new** | all exercise 8 pins and constants — **verify first** |
| `motor.c/h` | **new** | motor PWM + direction, encoder (TC2 quadrature decoder), homing |
| `solenoid.c/h` | **new** | one shot per button press, pulse length and cooldown |
| `pid.c/h` | **new** | discrete PID, anti-windup, filtered D |
| `tuning.c/h` | **new** | `$` serial protocol for the config tool, safety stops |
| `motor_hal.h` | **new** | interface between `tuning.c` and `motor.c` |
| `can.c/h` | unchanged | CAN driver (from `node2_can.zip`) |
| `protocol.c/h` | unchanged | CAN protocol with node 1 (from `node2_can.zip`) |

**Keep from your own repository, unchanged:** `uart.c/h`, `time.c/h`,
the `sam/` tree (startup, linker script, CMSIS headers) and the rest
of the `Makefile`.

## Install into your repository

1. Copy all files from this folder into your node 2 project folder.
2. In the `Makefile`, replace `SOURCE_FILES` with the list in
   `Makefile.sources`.
3. If your exercise 7 IR goal detection lives in `main.c`, move it into
   the new `main.c`: call `report_goal()` from it (see the comment there).
4. Check every pin in `board.h` against the shield schematic in the lab
   manual. Then set `BOARD_PINS_VERIFIED` to 1.
5. `make`, then flash as before.

## Behaviour

| Event | Action |
|---|---|
| Power-up | motor homes to the left end stop (1.5 s), encoder = 0, motor off |
| START from node 1 | PID on, cart holds position until the first joystick frame |
| Joystick x | cart position setpoint (left margin … right margin) |
| Joystick y | servo angle |
| Joystick button | one solenoid shot, at most every 400 ms |
| PAUSE | PID holds the cart where it is, solenoid off |
| STOP | motor off, servo centred, score reset |
| Joystick timeout (200 ms) | servo centres, cart holds its last setpoint |
| `$` lines from the config tool | gains, modes, telemetry (see PROTOCOL.md) |

While the config tool drives the motor (PC setpoint, open loop, relay
test), START and STOP from node 1 do not take it over. Switch the tool
back to *Off* or *Game* to hand control back.

## First run

1. Remove the belt or keep a hand near the power switch the first time.
2. Connect the config tool to the Due's programming port at **115200 baud**.
   The baud rate changed from 9600 because of the live plot.
3. Terminal tab: the banner shows `--- Node 2 ---` and `homing motor...`.
   The cart should drive **left**. If it drives right, set
   `MOTOR_DIR_INVERT` to 1 in `board.h`.
4. PID Tuner, Manual tab, open loop: +u must **increase** the position.
   If the cart moves right but the count falls, set `ENCODER_INVERT` to 1.
5. Drive to the right end stop and read the position. Put that value in
   `MOTOR_TRAVEL_COUNTS`.
6. Tune: autotune, then step test (see the tool's README).
   *Export pid_gains.h* into this folder. It becomes the boot default.
