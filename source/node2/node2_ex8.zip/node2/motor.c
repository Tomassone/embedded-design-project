#include "sam.h"
#include "time.h"
#include "board.h"
#include "motor.h"

// MCK / PWM frequency = period in clock ticks (clock A = MCK).
#define MCK_HZ            84000000u
#define MOTOR_PWM_PERIOD  (MCK_HZ / MOTOR_PWM_FREQ_HZ)     // 4200 at 20 kHz

_Static_assert(MOTOR_PWM_PERIOD >= 1000, "PWM period too short for permille resolution");


void motor_init(void)
{
    // ---- Clocks -------------------------------------------------------
    PMC->PMC_PCER0 = (1u << ID_PIOB) | (1u << ID_PIOC);
    PMC->PMC_PCER1 = (1u << (ID_PWM - 32)) | (1u << (ID_TC6 - 32));

    // ---- Direction pin: plain GPIO output ----------------------------
    MOTOR_DIR_PIO->PIO_PER  = MOTOR_DIR_PIN;
    MOTOR_DIR_PIO->PIO_OER  = MOTOR_DIR_PIN;
    MOTOR_DIR_PIO->PIO_CODR = MOTOR_DIR_PIN;

    // ---- PWM on the enable pin ----------------------------------------
    MOTOR_PWM_PIO->PIO_PDR = MOTOR_PWM_PIN;
#if MOTOR_PWM_PERIPH_B
    MOTOR_PWM_PIO->PIO_ABSR |= MOTOR_PWM_PIN;
#else
    MOTOR_PWM_PIO->PIO_ABSR &= ~MOTOR_PWM_PIN;
#endif

    PWM->PWM_DIS = (1u << MOTOR_PWM_CHANNEL);
    PWM->PWM_CH_NUM[MOTOR_PWM_CHANNEL].PWM_CMR  = 0;              // clock = MCK
    PWM->PWM_CH_NUM[MOTOR_PWM_CHANNEL].PWM_CPRD = MOTOR_PWM_PERIOD;
    PWM->PWM_CH_NUM[MOTOR_PWM_CHANNEL].PWM_CDTY = 0;              // motor off
    PWM->PWM_ENA = (1u << MOTOR_PWM_CHANNEL);

    // ---- Encoder: TC2 channel 0 as quadrature decoder ----------------
    // SAM3X datasheet, section "Quadrature Decoder": XC0 clocked by the
    // decoder, position mode, edges on both phases, input filter.
    ENCODER_PIO->PIO_PDR   = ENCODER_PIN_A | ENCODER_PIN_B;
    ENCODER_PIO->PIO_ABSR |= ENCODER_PIN_A | ENCODER_PIN_B;      // peripheral B

    TC2->TC_CHANNEL[0].TC_CMR = TC_CMR_TCCLKS_XC0
                              | TC_CMR_ETRGEDG_RISING
                              | TC_CMR_ABETRG;
    TC2->TC_BMR = TC_BMR_QDEN | TC_BMR_POSEN | TC_BMR_EDGPHA
                | TC_BMR_MAXFILT(1);
    TC2->TC_CHANNEL[0].TC_CCR = TC_CCR_CLKEN | TC_CCR_SWTRG;    // start at 0
}


// ---------------------------------------------------------------------
// motor_hal.h -- used by tuning.c
// ---------------------------------------------------------------------

void motor_hal_set(int16_t u)
{
    if (u >  1000) u =  1000;
    if (u < -1000) u = -1000;

    uint8_t forward = (u >= 0);
#if MOTOR_DIR_INVERT
    forward = !forward;
#endif
    if (forward)
        MOTOR_DIR_PIO->PIO_SODR = MOTOR_DIR_PIN;
    else
        MOTOR_DIR_PIO->PIO_CODR = MOTOR_DIR_PIN;

    uint32_t mag  = (uint32_t)(u >= 0 ? u : -u);
    uint32_t duty = mag * MOTOR_PWM_PERIOD / 1000u;

    // CDTYUPD: takes effect at the next period, no glitched pulse.
    PWM->PWM_CH_NUM[MOTOR_PWM_CHANNEL].PWM_CDTYUPD = duty;
}


int32_t motor_hal_position(void)
{
    // TC_CV counts up and down in QDEC position mode. Read as signed so
    // a position left of the zero point is negative, not 4 billion.
    int32_t p = (int32_t)TC2->TC_CHANNEL[0].TC_CV;
#if ENCODER_INVERT
    p = -p;
#endif
    return p;
}


void motor_hal_zero(void)
{
    TC2->TC_CHANNEL[0].TC_CCR = TC_CCR_CLKEN | TC_CCR_SWTRG;
}


uint32_t motor_hal_millis(void)
{
    // Same clock as time_doPeriodic(), so no second timer is needed.
    return (uint32_t)(time_now() / msecs(1));
}


// ---------------------------------------------------------------------

void motor_home(void)
{
#if MOTOR_HOMING
    uint64_t end = time_now() + msecs(MOTOR_HOMING_MS);

    motor_hal_set(MOTOR_HOMING_U);
    while (time_now() < end)
        ;
    motor_hal_set(0);

    // Let the cart come to rest against the end stop before zeroing.
    end = time_now() + msecs(200);
    while (time_now() < end)
        ;
    motor_hal_zero();
#endif
}


int32_t motor_joystick_to_counts(int8_t x, int8_t range)
{
    int32_t r = range;
    int32_t v = x;

    if (v >  r) v =  r;
    if (v < -r) v = -r;

    int32_t lo   = MOTOR_MARGIN_COUNTS;
    int32_t hi   = MOTOR_TRAVEL_COUNTS - MOTOR_MARGIN_COUNTS;
    int32_t span = hi - lo;

    return lo + (v + r) * span / (2 * r);
}
