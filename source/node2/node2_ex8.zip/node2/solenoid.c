#include "sam.h"
#include "time.h"
#include "board.h"
#include "solenoid.h"

static uint8_t  was_pressed;
static uint8_t  active;
static uint64_t pulse_end;
static uint64_t ready_at;


static void drive(uint8_t on)
{
#if SOLENOID_ACTIVE_HIGH
    if (on) SOLENOID_PIO->PIO_SODR = SOLENOID_PIN;
    else    SOLENOID_PIO->PIO_CODR = SOLENOID_PIN;
#else
    if (on) SOLENOID_PIO->PIO_CODR = SOLENOID_PIN;
    else    SOLENOID_PIO->PIO_SODR = SOLENOID_PIN;
#endif
}


void solenoid_init(void)
{
    PMC->PMC_PCER0 = (1u << SOLENOID_PIO_ID);
    drive(0);                                   // set level before enabling
    SOLENOID_PIO->PIO_PER = SOLENOID_PIN;
    SOLENOID_PIO->PIO_OER = SOLENOID_PIN;
    active = 0;
    was_pressed = 0;
    ready_at = 0;
}


void solenoid_off(void)
{
    drive(0);
    active = 0;
}


void solenoid_update(uint8_t pressed, uint8_t enabled)
{
    uint64_t now = time_now();

    if (active && now >= pulse_end)
    {
        drive(0);
        active = 0;
    }

    uint8_t edge = pressed && !was_pressed;
    was_pressed  = pressed;

    if (edge && enabled && !active && now >= ready_at)
    {
        drive(1);
        active    = 1;
        pulse_end = now + msecs(SOLENOID_PULSE_MS);
        ready_at  = now + msecs(SOLENOID_COOLDOWN_MS);
    }
}
