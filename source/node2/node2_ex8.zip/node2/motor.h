#pragma once
#include <stdint.h>
#include "motor_hal.h"

// ---------------------------------------------------------------------
// motor.h -- exercise 8 motor driver and encoder
//
// The motor_hal_* functions declared in motor_hal.h are implemented in
// motor.c on top of this driver. tuning.c only uses that interface.
// ---------------------------------------------------------------------

// PWM, direction pin and quadrature decoder. Call once at start-up,
// after servo_init() (both use the PWM controller).
void motor_init(void);

// Drives to the left end stop and zeroes the encoder there.
// Blocking for MOTOR_HOMING_MS. Does nothing if MOTOR_HOMING is 0.
void motor_home(void);

// Joystick x (-range..+range) to a position setpoint in encoder counts,
// inside the travel minus the margins.
int32_t motor_joystick_to_counts(int8_t x, int8_t range);
