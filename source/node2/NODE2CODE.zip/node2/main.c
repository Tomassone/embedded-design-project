#include <stdio.h>
#include <stdarg.h>
#include "sam.h"

#define F_CPU 84000000
#define BAUDRATE 9600  // <--- Set your baudrate here

// UART library functions (declared here, defined in uart.c)
void uart_init(uint32_t cpufreq, uint32_t baudrate);
void uart_tx(uint8_t val);
uint8_t uart_rx(uint8_t* val);
int uart_flush(char* buf, int len);

// Crude ms delay for the servo sweep
static void delay_ms(volatile uint32_t ms)
{
    while (ms--)
    {
        volatile uint32_t i = 4000;
        while (i--) __asm__ volatile ("nop");
    }
}

int main(void)
{
    SystemInit();
    WDT->WDT_MR = WDT_MR_WDDIS;                 // Disable watchdog (lab tip 3.6.6)

    /* =========================================================
     * FEATURE 1: Servo PWM on PB13 (Arduino D21)
     * ========================================================= */
    PMC->PMC_PCER0 = (1u << ID_PIOB);           // Enable PIOB clock
    PMC->PMC_PCER1 = (1u << (ID_PWM - 32));     // Enable PWM clock

    PIOB->PIO_PDR   = PIO_PB13;                 // Release GPIO control
    PIOB->PIO_ABSR |= PIO_PB13;                 // Select peripheral B (PWMH1)

    PWM->PWM_CH_NUM[1].PWM_CMR  = 0;            // Clock A = MCK
    PWM->PWM_CH_NUM[1].PWM_CPRD = 1680000u - 1; // 20 ms period (50 Hz)
    PWM->PWM_CH_NUM[1].PWM_CDTY = 126000u;      // 1.5 ms center position

    PWM->PWM_ENA = (1u << 1);                   // Enable PWM channel 1

    /* =========================================================
     * FEATURE 2: UART Serial Communication on PA8/PA9
     * ========================================================= */
    uart_init(F_CPU, BAUDRATE);                 // <--- Initializes UART with 9600 baud

    // printf() will now automatically use _write() from your uart.c
    printf("\n\r--- Node 2 Initialized ---\n\r");
    printf("Servo PWM sweep starting...\n\r");
    printf("UART Baudrate set to %d\n\r", BAUDRATE);

    /* =========================================================
     * MAIN LOOP: Servo Sweep + UART Status
     * ========================================================= */
    const uint32_t min_duty =  75600u;          // 0.9 ms
    const uint32_t max_duty = 176400u;          // 2.1 ms
    const uint32_t step     =   2000u;          // ~24 us per step

    while (1)
    {
        // Sweep toward max (0.9ms -> 2.1ms)
        for (uint32_t d = min_duty; d <= max_duty; d += step)
        {
            PWM->PWM_CH_NUM[1].PWM_CDTYUPD = d;
            delay_ms(20);
        }
        
        // Send status over UART
        printf("Servo at MAX (2.1 ms)\n\r");

        // Sweep toward min (2.1ms -> 0.9ms)
        for (uint32_t d = max_duty; d > min_duty; d -= step)
        {
            PWM->PWM_CH_NUM[1].PWM_CDTYUPD = d;
            delay_ms(20);
        }

        // Send status over UART
        printf("Servo at MIN (0.9 ms)\n\r");
    }
}