// tuning.c -- see tuning.h and PROTOCOL.md
//
// Numbers on the wire are integers only. printf("%f") is not linked
// by default with newlib-nano, and integers parse safely.
//   Gains     micro-units (1.0 = 1000000)
//   tf        microseconds
//   u         permille, -1000 .. +1000
//   position  encoder counts

#include "tuning.h"
#include "pid.h"
#include "motor_hal.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Optional project files: board constants and exported gains.
#if defined(__has_include)
#  if __has_include("board.h")
#    include "board.h"
#  endif
#  if __has_include("pid_gains.h")
#    include "pid_gains.h"
#  endif
#endif

#ifndef PID_DEFAULT_KP
#define PID_DEFAULT_KP      0.5f    // permille / count
#endif
#ifndef PID_DEFAULT_KI
#define PID_DEFAULT_KI      0.0f    // permille / (count*s)
#endif
#ifndef PID_DEFAULT_KD
#define PID_DEFAULT_KD      0.0f    // permille*s / count
#endif
#ifndef PID_DEFAULT_TF
#define PID_DEFAULT_TF      0.02f   // s
#endif
#ifndef PID_DEFAULT_UMAX
#define PID_DEFAULT_UMAX    600     // permille
#endif

// ---- Reference drive (overridable in board.h) ------------------------
#ifndef CAL_U
#define CAL_U               300     // permille, slow and gentle on the end stops
#endif
#ifndef CAL_STALL_WINDOW_MS
#define CAL_STALL_WINDOW_MS 150     // stall = moved less than ...
#endif
#ifndef CAL_STALL_COUNTS
#define CAL_STALL_COUNTS    4       // ... this many counts in one window
#endif
#ifndef CAL_MIN_RUN_MS
#define CAL_MIN_RUN_MS      300     // ignore the start-up before checking for a stall
#endif
#ifndef CAL_TIMEOUT_MS
#define CAL_TIMEOUT_MS      8000    // per direction
#endif
#ifndef CAL_SETTLE_MS
#define CAL_SETTLE_MS       250     // rest against the end stop before zeroing
#endif
#ifndef CAL_WRONG_DIR_COUNTS
#define CAL_WRONG_DIR_COUNTS 300    // moving this far the wrong way = sign error
#endif
#ifndef CAL_MIN_TRAVEL
#define CAL_MIN_TRAVEL      500     // shorter = encoder not counting
#endif
#ifndef CAL_SOFT_MARGIN
#define CAL_SOFT_MARGIN     100     // soft limits this far inside the end stops
#endif
#ifndef CAL_DEFAULT_TRAVEL
#  ifdef MOTOR_TRAVEL_COUNTS
#    define CAL_DEFAULT_TRAVEL MOTOR_TRAVEL_COUNTS
#  else
#    define CAL_DEFAULT_TRAVEL 5600
#  endif
#endif

#define PROTO_VERSION       3
#define LINE_LEN            64
#define MAX_ARGS            5
#define LINK_TIMEOUT_MS     1500u   // PC-driven modes stop without $PING
#define UMAX_LIMIT          1000

static pid_ctrl_t  pid;
static tune_mode_t mode = TUNE_MODE_OFF;

static int32_t  game_sp;
static int32_t  pc_sp;
static int16_t  open_u;
static int16_t  u_max = PID_DEFAULT_UMAX;

// Gains exactly as set over the link or loaded from flash. The floats in
// pid.c are derived from these, so save / load / report never drift.
static int32_t  kp_u, ki_u, kd_u, tf_us;

static int16_t  relay_d;
static int32_t  relay_hyst;
static int32_t  relay_center;
static int8_t   relay_dir;

static bool     soft_on;
static int32_t  soft_lo;
static int32_t  soft_hi;

static uint8_t  stream_div;
static uint8_t  stream_cnt;
static uint32_t last_rx_ms;
static uint32_t last_line_ms;           // only received lines, for tuning_link_active()
static bool     any_line;

static char     line[LINE_LEN];
static uint8_t  line_len;
static bool     in_line;
static bool     line_overflow;

// Calibration state
typedef enum
{
    CAL_LEFT,           // driving to the left end stop
    CAL_LEFT_SETTLE,    // resting there, then zero
    CAL_RIGHT,          // driving to the right end stop
    CAL_CENTER,         // driving back to the middle
} cal_phase_t;

static cal_phase_t cal_phase;
static bool        cal_measure;
static uint32_t    cal_t0;          // start of the current phase
static int32_t     cal_start_pos;   // position at the start of the phase
static int32_t     cal_ref_pos;     // stall window reference
static uint32_t    cal_ref_t;
static tune_mode_t cal_next_mode;   // mode after the calibration
static int32_t     travel = CAL_DEFAULT_TRAVEL;
static bool        homed;

// Where the travel value comes from. Reported in $TRAVEL.
typedef enum { TRAVEL_DEFAULT = 0, TRAVEL_MEASURED = 1, TRAVEL_STORED = 2 } travel_src_t;
static travel_src_t travel_src = TRAVEL_DEFAULT;

#ifndef MOTOR_HOMING
#define MOTOR_HOMING        1
#endif
static uint8_t     boot_cal = MOTOR_HOMING;


// ---------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------

static int32_t to_micro(float x)
{
    return (int32_t)(x * 1e6f + (x >= 0.0f ? 0.5f : -0.5f));
}


static int32_t round_i(float x)
{
    return (int32_t)(x + (x >= 0.0f ? 0.5f : -0.5f));
}


static int32_t clamp_i(int32_t x, int32_t lo, int32_t hi)
{
    if (x < lo) return lo;
    if (x > hi) return hi;
    return x;
}


static bool needs_link(tune_mode_t m)
{
    return m == TUNE_MODE_PC || m == TUNE_MODE_OPEN || m == TUNE_MODE_RELAY;
}


static void print_gains(void)
{
    printf("$GAINS,%ld,%ld,%ld,%ld,%d\r\n",
           (long)kp_u, (long)ki_u, (long)kd_u, (long)tf_us, (int)u_max);
}


static void set_gains_u(int32_t kp, int32_t ki, int32_t kd, int32_t tf)
{
    kp_u  = kp;
    ki_u  = ki;
    kd_u  = kd;
    tf_us = tf;
    pid_set_gains(&pid, (float)kp * 1e-6f, (float)ki * 1e-6f,
                  (float)kd * 1e-6f, (float)tf * 1e-6f);
}


static void set_umax(int32_t v)
{
    u_max     = (int16_t)clamp_i(v, 0, UMAX_LIMIT);
    pid.u_max = (float)u_max;
}


static void print_status(void)
{
    printf("$STATE,%d,%ld,%d,%ld,%ld,%d\r\n",
           (int)mode, (long)motor_hal_position(), (int)stream_div,
           (long)(soft_on ? soft_lo : 0), (long)(soft_on ? soft_hi : 0),
           CTRL_PERIOD_MS);
}


static void print_travel(void)
{
    printf("$TRAVEL,%ld,%d,%d\r\n",
           (long)travel, (int)travel_src, homed ? 1 : 0);
}


// ---------------------------------------------------------------------
// Mode handling
// ---------------------------------------------------------------------

static void enter_mode(tune_mode_t m)
{
    motor_hal_set(0);
    pid_reset(&pid);

    int32_t pos = motor_hal_position();

    // Start PC setpoint at the current position: no jump on entry.
    if (m == TUNE_MODE_PC && mode != TUNE_MODE_PC)
        pc_sp = pos;

    if (m == TUNE_MODE_OPEN)
        open_u = 0;

    if (m == TUNE_MODE_RELAY)
        relay_dir = (relay_center - pos >= 0) ? 1 : -1;

    mode       = m;
    last_rx_ms = motor_hal_millis();
}


void tuning_set_mode(tune_mode_t m)
{
    if (m > TUNE_MODE_CAL)
        m = TUNE_MODE_OFF;

    if (mode == TUNE_MODE_CAL && m != TUNE_MODE_CAL)
    {
        if (m == TUNE_MODE_GAME)
        {
            cal_next_mode = TUNE_MODE_GAME;     // after the calibration
            return;
        }
        printf("$ERR,cal,aborted\r\n");
    }

    if (m == TUNE_MODE_CAL)                     // only via tuning_start_cal()
        m = TUNE_MODE_OFF;

    enter_mode(m);
}


tune_mode_t tuning_mode(void)
{
    return mode;
}


void tuning_set_game_setpoint(int32_t counts)
{
    game_sp = counts;
}


int32_t tuning_travel(void)
{
    return travel;
}


bool tuning_homed(void)
{
    return homed;
}


bool tuning_link_active(void)
{
    return any_line && (uint32_t)(motor_hal_millis() - last_line_ms) < 2000u;
}


// Weak defaults: replaced by io_link.c when it is part of the build.
__attribute__((weak)) bool tuning_ext_command(const char *cmd, const long *a, uint8_t n)
{
    (void)cmd; (void)a; (void)n;
    return false;
}

__attribute__((weak)) void tuning_ext_report(void)
{
}


// ---------------------------------------------------------------------
// Reference drive
// ---------------------------------------------------------------------

static void cal_phase_begin(cal_phase_t p, uint32_t now, int32_t pos)
{
    cal_phase     = p;
    cal_t0        = now;
    cal_start_pos = pos;
    cal_ref_pos   = pos;
    cal_ref_t     = now;

    static const char *const names[] = { "LEFT", "SETTLE", "RIGHT", "CENTER" };
    printf("$CAL,%s,%ld\r\n", names[p], (long)pos);
}


void tuning_start_cal(bool measure_travel)
{
    enter_mode(TUNE_MODE_CAL);
    cal_measure   = measure_travel;
    cal_next_mode = TUNE_MODE_OFF;
    cal_phase_begin(CAL_LEFT, motor_hal_millis(), motor_hal_position());
}


static void cal_fail(const char *why)
{
    motor_hal_set(0);
    printf("$ERR,cal,%s\r\n", why);
    enter_mode(TUNE_MODE_OFF);
}


static void cal_finish(void)
{
    motor_hal_set(0);

    // Soft limits need a real travel: measured now, or stored and the
    // encoder just zeroed at the same end stop.
    if (cal_measure || travel_src == TRAVEL_STORED)
    {
        soft_on = true;
        soft_lo = CAL_SOFT_MARGIN;
        soft_hi = travel - CAL_SOFT_MARGIN;
    }

    printf("$CALDONE,%ld,%d\r\n", (long)travel, cal_measure ? 1 : 0);
    print_travel();

    tune_mode_t next = cal_next_mode;
    enter_mode(TUNE_MODE_OFF);

    if (next == TUNE_MODE_GAME)
    {
        game_sp = motor_hal_position();         // hold, until the joystick moves
        enter_mode(TUNE_MODE_GAME);
    }
    print_status();
}


// Drives towards an end stop. Returns 1 when the stop is reached.
static int cal_drive(int8_t dir, uint32_t now, int32_t pos, int16_t *u)
{
    *u = (int16_t)(dir * CAL_U);

    // Moving away from the end stop: motor or encoder sign is wrong.
    if ((pos - cal_start_pos) * dir < -CAL_WRONG_DIR_COUNTS)
    {
        cal_fail("count rises while driving left: run the open-loop test (README)");
        *u = 0;
        return 0;
    }

    if ((uint32_t)(now - cal_t0) > CAL_TIMEOUT_MS)
    {
        cal_fail("no end stop found: motor not driving or encoder not counting");
        *u = 0;
        return 0;
    }

    // Stall check once per window, after the start-up time.
    if ((uint32_t)(now - cal_ref_t) >= CAL_STALL_WINDOW_MS)
    {
        int32_t moved = abs(pos - cal_ref_pos);
        cal_ref_pos = pos;
        cal_ref_t   = now;

        if ((uint32_t)(now - cal_t0) >= CAL_MIN_RUN_MS && moved < CAL_STALL_COUNTS)
        {
            *u = 0;
            return 1;
        }
    }
    return 0;
}


static int16_t cal_step(uint32_t now, int32_t pos)
{
    int16_t u = 0;

    switch (cal_phase)
    {
        case CAL_LEFT:
            if (cal_drive(-1, now, pos, &u))
                cal_phase_begin(CAL_LEFT_SETTLE, now, pos);
            break;

        case CAL_LEFT_SETTLE:
            if ((uint32_t)(now - cal_t0) >= CAL_SETTLE_MS)
            {
                motor_hal_zero();
                homed = true;
                if (cal_measure)
                    cal_phase_begin(CAL_RIGHT, now, 0);
                else
                    cal_finish();
            }
            break;

        case CAL_RIGHT:
            if (cal_drive(+1, now, pos, &u))
            {
                if (pos < CAL_MIN_TRAVEL)
                {
                    cal_fail("travel too short: encoder not counting?");
                    return 0;
                }
                travel     = pos;
                travel_src = TRAVEL_MEASURED;
                cal_phase_begin(CAL_CENTER, now, pos);
            }
            break;

        case CAL_CENTER:
            if (pos <= travel / 2)
            {
                cal_finish();
                return 0;
            }
            if ((uint32_t)(now - cal_t0) > CAL_TIMEOUT_MS)
            {
                cal_fail("could not return to the middle");
                return 0;
            }
            u = -CAL_U;
            break;
    }

    // cal_fail()/cal_finish() may have left calibration mode already.
    return (mode == TUNE_MODE_CAL) ? u : 0;
}


// ---------------------------------------------------------------------
// Command parser
// ---------------------------------------------------------------------

static void handle_line(char *s)
{
    // Split "CMD,a,b,c" or "CMD a b c" into a keyword and integers.
    char   *tok  = strtok(s, ", \t");
    long    a[MAX_ARGS];
    uint8_t n    = 0;

    if (tok == NULL)
        return;

    char *cmd = tok;
    for (char *p = cmd; *p; p++)
        if (*p >= 'a' && *p <= 'z')
            *p = (char)(*p - 'a' + 'A');

    while ((tok = strtok(NULL, ", \t")) != NULL && n < MAX_ARGS)
    {
        char *end;
        a[n] = strtol(tok, &end, 10);
        if (*end != '\0')
        {
            printf("$ERR,%s,bad number\r\n", cmd);
            return;
        }
        n++;
    }

    last_rx_ms   = motor_hal_millis();
    last_line_ms = last_rx_ms;
    any_line     = true;

    if (strcmp(cmd, "PING") == 0)
    {
        return;                         // keep-alive only, no reply
    }
    else if (strcmp(cmd, "HELLO") == 0)
    {
        printf("$HELLO,PIDTUNE,%d,%d\r\n", PROTO_VERSION, CTRL_PERIOD_MS);
        print_gains();
        print_status();
        print_travel();
        tuning_ext_report();
    }
    else if (strcmp(cmd, "GET") == 0)
    {
        tuning_report();
    }
    else if (strcmp(cmd, "SET") == 0 && n == 4)
    {
        if (a[0] < 0 || a[1] < 0 || a[2] < 0 || a[3] < 0)
        {
            printf("$ERR,SET,negative gain\r\n");
            return;
        }
        set_gains_u(a[0], a[1], a[2], a[3]);
        printf("$OK,SET\r\n");
        print_gains();
    }
    else if (strcmp(cmd, "LIM") == 0 && n == 1)
    {
        set_umax(a[0]);
        printf("$OK,LIM\r\n");
        print_gains();
    }
    else if (strcmp(cmd, "MODE") == 0 && n == 1)
    {
        tuning_set_mode((tune_mode_t)clamp_i(a[0], 0, TUNE_MODE_RELAY));
        printf("$OK,MODE,%d\r\n", (int)mode);
    }
    else if (strcmp(cmd, "BOOT") == 0 && n == 1)
    {
        boot_cal = (uint8_t)clamp_i(a[0], 0, 2);
        printf("$OK,BOOT,%d\r\n", (int)boot_cal);
    }
    else if (strcmp(cmd, "CAL") == 0 && n == 1)
    {
        tuning_start_cal(a[0] != 0);
        printf("$OK,MODE,%d\r\n", (int)mode);
    }
    else if (strcmp(cmd, "SP") == 0 && n == 1)
    {
        pc_sp = a[0];
        if (soft_on)
            pc_sp = clamp_i(pc_sp, soft_lo, soft_hi);
    }
    else if (strcmp(cmd, "U") == 0 && n == 1)
    {
        open_u = (int16_t)clamp_i(a[0], -u_max, u_max);
    }
    else if (strcmp(cmd, "RELAY") == 0 && n == 3)
    {
        relay_d      = (int16_t)clamp_i(a[0], 0, u_max);
        relay_hyst   = (a[1] < 0) ? 0 : a[1];
        relay_center = a[2];
        printf("$OK,RELAY\r\n");
    }
    else if (strcmp(cmd, "STREAM") == 0 && n == 1)
    {
        stream_div = (uint8_t)clamp_i(a[0], 0, 100);
        stream_cnt = 0;
        printf("$OK,STREAM,%d\r\n", (int)stream_div);
    }
    else if (strcmp(cmd, "SOFT") == 0 && n == 2)
    {
        soft_on = (a[0] < a[1]);
        soft_lo = a[0];
        soft_hi = a[1];
        printf("$OK,SOFT,%d\r\n", soft_on ? 1 : 0);
    }
    else if (strcmp(cmd, "ZERO") == 0)
    {
        tuning_set_mode(TUNE_MODE_OFF);
        motor_hal_zero();
        printf("$OK,ZERO\r\n");
        print_status();
    }
    else if (!tuning_ext_command(cmd, a, n))
    {
        printf("$ERR,%s,unknown or wrong argument count\r\n", cmd);
    }
}


bool tuning_feed(uint8_t c)
{
    if (!in_line)
    {
        if (c != '$')
            return false;               // not ours: legacy test key

        in_line       = true;
        line_len      = 0;
        line_overflow = false;
        return true;
    }

    if (c == '\r')
        return true;

    if (c == '\n')
    {
        in_line = false;
        if (line_overflow)
        {
            printf("$ERR,line too long\r\n");
            return true;
        }
        line[line_len] = '\0';
        handle_line(line);
        return true;
    }

    if (line_len < LINE_LEN - 1)
        line[line_len++] = (char)c;
    else
        line_overflow = true;

    return true;
}


// ---------------------------------------------------------------------
// Control loop
// ---------------------------------------------------------------------

void tuning_init(void)
{
    pid_init(&pid, CTRL_PERIOD_MS * 1e-3f, (float)u_max);
    set_gains_u(to_micro(PID_DEFAULT_KP), to_micro(PID_DEFAULT_KI),
                to_micro(PID_DEFAULT_KD), to_micro(PID_DEFAULT_TF));
    mode       = TUNE_MODE_OFF;
    last_rx_ms = motor_hal_millis();
}


void tuning_get_params(tuning_params_t *p)
{
    p->kp_u     = kp_u;
    p->ki_u     = ki_u;
    p->kd_u     = kd_u;
    p->tf_us    = tf_us;
    p->u_max    = u_max;
    p->travel   = (travel_src == TRAVEL_DEFAULT) ? 0 : travel;
    p->boot_cal = boot_cal;
}


void tuning_apply_params(const tuning_params_t *p)
{
    // Same checks as the link commands: negative gains are refused.
    if (p->kp_u >= 0 && p->ki_u >= 0 && p->kd_u >= 0 && p->tf_us >= 0)
        set_gains_u(p->kp_u, p->ki_u, p->kd_u, p->tf_us);
    set_umax(p->u_max);
    boot_cal = (p->boot_cal <= 2) ? p->boot_cal : MOTOR_HOMING;

    if (p->travel >= CAL_MIN_TRAVEL)
    {
        travel     = p->travel;
        travel_src = TRAVEL_STORED;
    }
}


void tuning_report(void)
{
    print_gains();
    print_status();
    print_travel();
    tuning_ext_report();
}


uint8_t tuning_boot_cal(void)
{
    if (boot_cal == 1)
        tuning_start_cal(false);
    else if (boot_cal == 2)
        tuning_start_cal(true);
    return boot_cal;
}


void tuning_tick(void)
{
    uint32_t now = motor_hal_millis();
    int32_t  pos = motor_hal_position();

    // Safety 1: PC-driven modes need a live PC link.
    if (needs_link(mode) && (uint32_t)(now - last_rx_ms) > LINK_TIMEOUT_MS)
    {
        tuning_set_mode(TUNE_MODE_OFF);
        printf("$ERR,link timeout\r\n");
        print_status();
    }

    // Safety 2: open loop and relay stop outside the soft limits.
    if (soft_on && (mode == TUNE_MODE_OPEN || mode == TUNE_MODE_RELAY)
        && (pos < soft_lo || pos > soft_hi))
    {
        tuning_set_mode(TUNE_MODE_OFF);
        printf("$ERR,soft limit\r\n");
        print_status();
    }

    int32_t sp = pos;
    int16_t u  = 0;
    bool    pid_active = false;

    switch (mode)
    {
        case TUNE_MODE_GAME:
            sp = soft_on ? clamp_i(game_sp, soft_lo, soft_hi) : game_sp;
            u  = (int16_t)round_i(pid_update(&pid, (float)sp, (float)pos));
            pid_active = true;
            break;

        case TUNE_MODE_PC:
            sp = pc_sp;
            u  = (int16_t)round_i(pid_update(&pid, (float)sp, (float)pos));
            pid_active = true;
            break;

        case TUNE_MODE_OPEN:
            u = open_u;
            break;

        case TUNE_MODE_RELAY:
        {
            // Relay with hysteresis around relay_center (Astrom-Hagglund).
            // Positive u must increase the encoder count.
            int32_t e = relay_center - pos;
            if (relay_dir > 0 && e < -relay_hyst)
            {
                relay_dir = -1;
                printf("$R,%lu,-1,%ld\r\n", (unsigned long)now, (long)pos);
            }
            else if (relay_dir < 0 && e > relay_hyst)
            {
                relay_dir = 1;
                printf("$R,%lu,1,%ld\r\n", (unsigned long)now, (long)pos);
            }
            sp = relay_center;
            u  = (int16_t)(relay_dir * relay_d);
            break;
        }

        case TUNE_MODE_CAL:
            u = cal_step(now, pos);
            break;

        case TUNE_MODE_OFF:
        default:
            break;
    }

    motor_hal_set(u);

    if (stream_div && ++stream_cnt >= stream_div)
    {
        stream_cnt = 0;
        printf("$T,%lu,%ld,%ld,%d,%ld,%ld,%ld\r\n",
               (unsigned long)now, (long)sp, (long)pos, (int)u,
               (long)(pid_active ? round_i(pid.p_term) : 0),
               (long)(pid_active ? round_i(pid.i_term) : 0),
               (long)(pid_active ? round_i(pid.d_term) : 0));
    }
}
