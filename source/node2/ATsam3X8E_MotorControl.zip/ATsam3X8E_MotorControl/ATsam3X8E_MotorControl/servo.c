#include "servo.h"

#ifndef HOST_TEST
#include "sam.h"
#endif

// PWM clock = MCK = 84 MHz -> 84 counts per microsecond.
#define COUNTS_PER_US   84u
#define SERVO_PERIOD    1680000u            // 20 ms

static uint16_t servo_us = SERVO_US_CENTRE;


void servo_init(void)
{
#ifndef HOST_TEST
    PMC->PMC_PCER0 = (1u << ID_PIOB);           // PIOB clock
    PMC->PMC_PCER1 = (1u << (ID_PWM - 32));     // PWM clock

    PIOB->PIO_PDR   = PIO_PB13;                 // release GPIO control
    PIOB->PIO_ABSR |= PIO_PB13;                 // peripheral B (PWMH1)

    // CPOL = 1: the pulse is HIGH for CDTY. With CPOL = 0 a PWMH output is
    // low during CDTY, which inverts the servo pulse.
    PWM->PWM_CH_NUM[1].PWM_CMR  = PWM_CMR_CPOL; // clock = MCK, high = duty
    PWM->PWM_CH_NUM[1].PWM_CPRD = SERVO_PERIOD - 1;
    PWM->PWM_CH_NUM[1].PWM_CDTY = (uint32_t)SERVO_US_CENTRE * COUNTS_PER_US;

    PWM->PWM_ENA = (1u << 1);                   // enable channel 1
#endif
    servo_us = SERVO_US_CENTRE;
}


void servo_set_us(uint16_t us)
{
    if (us < SERVO_US_MIN) us = SERVO_US_MIN;
    if (us > SERVO_US_MAX) us = SERVO_US_MAX;
    servo_us = us;

#ifndef HOST_TEST
    // CDTYUPD: takes effect at the next period, no glitched pulse.
    PWM->PWM_CH_NUM[1].PWM_CDTYUPD = (uint32_t)us * COUNTS_PER_US;
#endif
}


uint16_t servo_get_us(void)
{
    return servo_us;
}
