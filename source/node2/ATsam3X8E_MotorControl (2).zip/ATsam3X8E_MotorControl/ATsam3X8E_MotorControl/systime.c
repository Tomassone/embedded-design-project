#include "sam.h"
#include "systime.h"

static volatile uint64_t ms_ticks;


void systime_init(uint32_t cpufreq)
{
	ms_ticks = 0;
	SysTick_Config(cpufreq / 1000u);            // 1 ms interrupt, CMSIS helper
	NVIC_SetPriority(SysTick_IRQn, 1);
}


// Work that must happen every millisecond, even when the main loop is
// busy (solenoid.c ends its pulse here). Weak: empty if nobody needs it.
__attribute__((weak)) void systime_1ms_hook(void)
{
}


void SysTick_Handler(void)
{
	ms_ticks++;
	systime_1ms_hook();
}


systime_t time_now(void)
{
	// A 64-bit read is two 32-bit loads on the Cortex-M3. Read until two
	// consecutive values agree, so a tick between the halves cannot
	// produce a torn value.
	uint64_t a, b;
	do
	{
		a = ms_ticks;
		b = ms_ticks;
	} while (a != b);
	return a;
}


void time_spinUntil(systime_t t)
{
	while (time_now() < t)
	;
}
