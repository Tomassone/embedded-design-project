// tuning.h -- PID tuning link between node 2 and the config tool
//
// All PC <-> node 2 traffic for the tuner is ASCII lines that start
// with '$'. Any other byte is left alone, so the existing test keys
// (g, e, r, s) in handle_uart() keep working.
//
// This module owns the motor: every tuning_tick() writes exactly one
// motor command, whichever mode is active.
//
// Integration:
//   1. tuning_init() once after uart_init().
//   2. In handle_uart(): if (tuning_feed(c)) continue;
//   3. tuning_tick() once per control period (CTRL_PERIOD_MS).
//   4. tuning_set_game_setpoint() with the joystick target.

#ifndef TUNING_H
#define TUNING_H

#include <stdbool.h>
#include <stdint.h>

// Control period. Must match how often tuning_tick() is called.
#ifndef CTRL_PERIOD_MS
#define CTRL_PERIOD_MS  10
#endif

typedef enum
{
    TUNE_MODE_OFF   = 0,    // motor off
    TUNE_MODE_GAME  = 1,    // PID, setpoint from joystick (normal play)
    TUNE_MODE_PC    = 2,    // PID, setpoint from config tool
    TUNE_MODE_OPEN  = 3,    // open loop, motor command from config tool
    TUNE_MODE_RELAY = 4,    // relay feedback test for autotuning
    TUNE_MODE_CAL   = 5,    // reference drive / travel calibration
} tune_mode_t;

void        tuning_init(void);
bool        tuning_feed(uint8_t c);
void        tuning_tick(void);

void        tuning_set_game_setpoint(int32_t counts);

// Switching to OFF, PC, OPEN or RELAY aborts a running calibration.
// Switching to GAME during a calibration is remembered instead, and
// takes effect when the calibration has finished.
void        tuning_set_mode(tune_mode_t m);
tune_mode_t tuning_mode(void);

// Reference drive. Non-blocking: it runs inside tuning_tick().
//   measure_travel = 0: drive to the left end stop, zero the encoder.
//   measure_travel = 1: then also drive to the right end stop, store the
//                       travel, set the soft limits, and return to the
//                       middle.
void        tuning_start_cal(bool measure_travel);

// Travel in counts: the measured value after a full calibration,
// otherwise the default (CAL_DEFAULT_TRAVEL).
int32_t     tuning_travel(void);

// true after the encoder has been zeroed at the left end stop.
bool        tuning_homed(void);

// ---- Settings that survive a reset (see settings.c / nvcfg.c) -----------
// Gains in the wire units: micro-units, tf in microseconds.
typedef struct
{
    int32_t kp_u, ki_u, kd_u, tf_us;
    int16_t u_max;              // permille
    int32_t travel;             // counts; 0 = not known (use the default)
    uint8_t boot_cal;           // reference drive at power-up: 0 none, 1 home,
                                // 2 home + measure travel
} tuning_params_t;

void        tuning_get_params(tuning_params_t *p);

// Applies gains and output limit at once. A travel > 0 is marked as
// "stored": a later homing (boot_cal 1) then also sets the soft limits.
void        tuning_apply_params(const tuning_params_t *p);

// Prints $GAINS, $STATE, $TRAVEL and the extension report, as on $GET.
void        tuning_report(void);

// Starts the reference drive selected by boot_cal. Returns the mode used.
uint8_t     tuning_boot_cal(void);

// true while the config tool is connected: a '$' line arrived within
// the last 2 s (the tool sends $PING every 0.5 s).
bool        tuning_link_active(void);

// ---- Extension hooks ----------------------------------------------------
// Other modules can add '$' commands without touching this file: define
// these two functions (io_link.c does). The defaults here are weak.
//
// Called for every command tuning.c does not know. cmd is upper case,
// a[0..n-1] the integer arguments. Return true if handled.
bool        tuning_ext_command(const char *cmd, const long *a, uint8_t n);

// Called on $HELLO and $GET, after the tuner's own report.
void        tuning_ext_report(void);

#endif
