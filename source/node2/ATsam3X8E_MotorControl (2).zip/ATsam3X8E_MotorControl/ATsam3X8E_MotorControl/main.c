#include <stdio.h>
#include "sam.h"
#include "uart.h"
#include "systime.h"
#include "can.h"
#include "protocol.h"
#include "board.h"
#include "motor.h"
#include "servo.h"
#include "solenoid.h"
#include "ir.h"
#include "io_link.h"
#include "settings.h"
#include "nvcfg.h"
#include "tuning.h"

#define F_CPU     84000000

// 115200 instead of 9600: the config tool's live plot streams telemetry.
// Set the same rate in the config tool (Port tab).
#define BAUDRATE  115200

// ---------------------------------------------------------------------
// Loop period. Node 1 sends the joystick every 50 ms, and each receive
// mailbox holds one message, so polling has to be clearly faster than
// that. 10 ms is also the PID sample time (CTRL_PERIOD_MS in tuning.h).
// ---------------------------------------------------------------------
#define LOOP_MS           10

_Static_assert(LOOP_MS == CTRL_PERIOD_MS,
"the PID runs once per loop: LOOP_MS must equal CTRL_PERIOD_MS");

// Node 1 stops sending joystick frames as soon as it leaves the game,
// so this must not be mistaken for a fault. The cart holds its setpoint.
#define JOYSTICK_TIMEOUT_MS   200

// Status heartbeat to node 1.
#define STATUS_PERIOD_MS  500

#define JOYSTICK_RANGE    90

static node2_status_t status = NODE2_IDLE;
static uint8_t         score;


// ---------------------------------------------------------------------
// Stack check. At start-up the unused part of the stack is filled with
// a pattern. stack_used() finds the deepest point that was overwritten
// since then. The 's' key prints it: if it gets close to the total, the
// stack is too small (see README, "Stack size").
//
// _sstack / _estack come from Atmel's linker script.
// ---------------------------------------------------------------------
#define STACK_FILL  0xA5A5A5A5u

extern uint32_t _sstack;
extern uint32_t _estack;

static void stack_paint(void)
{
	uint32_t  marker;                           // lives in the current frame
	uint32_t *p   = &_sstack;
	uint32_t *top = (uint32_t *)((uintptr_t)&marker - 64u);

	while (p < top)
	*p++ = STACK_FILL;
}

static uint32_t stack_total(void)
{
	return (uint32_t)((uintptr_t)&_estack - (uintptr_t)&_sstack);
}

static uint32_t stack_used(void)
{
	const uint32_t *p = &_sstack;

	while (p < &_estack && *p == STACK_FILL)
	p++;
	return (uint32_t)((uintptr_t)&_estack - (uintptr_t)p);
}


// ---------------------------------------------------------------------
// The ball got past the paddle: called by the IR beam (ir.c) while the
// game runs. The 'g' key stays as a test trigger.
// ---------------------------------------------------------------------
static void report_goal(void)
{
	score++;
	protocol_send_goal(score);
	io_link_goal(score);
	printf("GOAL -- score now %u\n\r", score);
}


static void print_io_status(void)
{
	uint16_t deb, hold, pulse, cool;
	uint8_t  lvl;

	ir_get_config(&deb, &hold, &lvl);
	solenoid_get_timing(&pulse, &cool);

	printf("IR  pin %u  beam %s%s  breaks %lu  glitches %lu  holdoff-ignored %lu\n\r",
	(unsigned)ir_raw(), ir_blocked() ? "BLOCKED" : "clear",
	ir_stuck() ? " (stuck)" : "",
	(unsigned long)ir_breaks(), (unsigned long)ir_glitches(),
	(unsigned long)ir_suppressed());
	printf("    blocked level %u  debounce %u ms  holdoff %u ms\n\r",
	(unsigned)lvl, (unsigned)deb, (unsigned)hold);
	printf("SOL pin %s  shots %lu  pulse %u ms  cooldown %u ms  forced-off %lu\n\r",
	solenoid_active() ? "ON" : "off", (unsigned long)solenoid_shots(),
	(unsigned)pulse, (unsigned)cool, (unsigned long)solenoid_forced_off());
	printf("SERVO locked at %u us\n\r", (unsigned)servo_get_us());
}


static void set_status(node2_status_t s)
{
	status = s;
	protocol_send_status(status);
}


// Node 1 may switch the motor between OFF and GAME. It must not take
// over while the config tool drives it (PC setpoint, open loop, relay),
// and a STOP must not abort a running reference drive.
static uint8_t game_owns_motor(void)
{
	tune_mode_t m = tuning_mode();
	return m == TUNE_MODE_OFF || m == TUNE_MODE_GAME;
}


static void print_can_errors(void)
{
	CanErrors e;
	can_get_errors(&e);

	printf("CAN  TEC %u  REC %u  %s%s\n\r",
	e.tx_errors, e.rx_errors,
	e.error_passive ? "ERROR-PASSIVE " : "",
	e.bus_off ? "BUS-OFF" : (e.tx_errors || e.rx_errors ? "" : "OK"));
}


static void start_reference_drive(void)
{
	#if !BOARD_PINS_VERIFIED
	// No automatic drive until board.h is confirmed: with a wrong pin or
	// polarity the motor could push into an end stop at full power.
	printf("reference drive skipped: set BOARD_PINS_VERIFIED in board.h\n\r");
	#else
	static const char *const what[] = {
		"none (encoder zero = power-up position)",
		"homing to the left end stop",
		"homing and measuring the travel",
	};
	uint8_t m = tuning_boot_cal();
	printf("reference drive: %s\n\r", what[m <= 2 ? m : 0]);
	#endif
}


// Test keys over the serial terminal. Lines starting with '$' belong to
// the config tool and are taken by tuning_feed() first.
static void handle_uart(void)
{
	uint8_t c;

	while (uart_rx(&c))
	{
		if (tuning_feed(c))
		continue;

		switch (c)
		{
			case 'g':
			report_goal();
			break;

			case 'e':
			print_can_errors();
			break;

			case 'r':
			score = 0;
			printf("Score reset\n\r");
			break;

			case 'f':
			printf(solenoid_fire() ? "solenoid: shot\n\r"
			: "solenoid: busy or cooling down\n\r");
			break;

			case 'i':
			print_io_status();
			break;

			case 'h':
			printf("reference drive: homing\n\r");
			tuning_start_cal(false);
			break;

			case 'c':
			printf("reference drive: homing and measuring the travel\n\r");
			tuning_start_cal(true);
			break;

			case 's':
			{
				const joystick_rx_t *j = protocol_joystick();
				printf("state %u  joy %s x %d y %d btn %02X  score %u\n\r",
				status, j->valid ? "ok" : "stale",
				j->x, j->y, j->buttons, score);
				printf("motor mode %u  pos %ld  travel %ld  %s\n\r",
				(unsigned)tuning_mode(), (long)motor_hal_position(),
				(long)tuning_travel(),
				tuning_homed() ? "homed" : "NOT homed");
				printf("settings in flash: %s\n\r",
				nvcfg_seq() ? "yes" : "none (defaults)");
				printf("stack used %lu of %lu bytes\n\r",
				(unsigned long)stack_used(), (unsigned long)stack_total());
				break;
			}

			default:
			break;
		}
	}
}


int main(void)
{
	SystemInit();
	stack_paint();                              // before anything else uses the stack
	motor_init();                               // first: A3959 ENABLE low = motor off
	solenoid_init();                            // second: solenoid driver off
	WDT->WDT_MR = WDT_MR_WDDIS;                 // Disable watchdog (lab tip 3.6.6)
	systime_init(F_CPU);                        // 1 ms SysTick for time_now()

	servo_init();                               // forward (1500 us) until settings load
	ir_init();                                  // after systime: edges get time stamps
	uart_init(F_CPU, BAUDRATE);

	// Polling, not interrupt driven: main() is the only thing that
	// touches the game state, so nothing has to be volatile.
	can_init_default(0);

	printf("\n\r--- Node 2 ---\n\r");
	printf("CAN %lu bit/s, %u TQ/bit, BRP %u, clk %lu Hz\n\r",
	(unsigned long)CAN_BITRATE, CAN_TQ_PER_BIT,
	(unsigned)CAN_BRP, (unsigned long)CAN_CLK_HZ);

	// Built-in defaults first, then whatever was saved from the config
	// tool: gains, travel, boot mode, IR, solenoid, servo position.
	tuning_init();
	settings_boot();
	printf("servo locked at %u us\n\r", (unsigned)servo_get_us());

	// Motor init: reference drive as stored (non-blocking, runs inside
	// tuning_tick). The motor stays off afterwards until START.
	start_reference_drive();

	printf("keys: g=goal  e=can errors  r=reset score  s=state\n\r");
	printf("      h=home (left end stop)  c=calibrate travel\n\r");
	printf("      f=fire solenoid  i=IR, solenoid and servo status\n\r");
	printf("IR beam is %s\n\r", ir_blocked() ? "BLOCKED (check alignment or IR_BLOCKED_LEVEL)"
	: "clear");
	printf("config tool: connect at %u baud\n\r", (unsigned)BAUDRATE);
	printf("stack %lu bytes, used so far %lu\n\r",
	(unsigned long)stack_total(), (unsigned long)stack_used());
	if (stack_total() < 4096u)
	printf("WARNING: stack below 4 KB -- see README, 'Stack size'\n\r");

	set_status(NODE2_IDLE);

	uint32_t since_status = 0;

	time_doPeriodic(msecs(LOOP_MS))
	{
		handle_uart();

		// Drain every pending frame. More than one can be waiting:
		// there are two receive mailboxes.
		protocol_poll();

		if (protocol_cmd_changed())
		{
			switch (protocol_game_cmd())
			{
				case GAME_CMD_START:
				// Also sent on resume from pause, so do not reset
				// the score here.
				set_status(NODE2_RUNNING);
				if (tuning_mode() == TUNE_MODE_OFF)
				{
					// Hold the current position until the first
					// joystick frame; never jump to setpoint 0.
					tuning_set_game_setpoint(motor_hal_position());
					tuning_set_mode(TUNE_MODE_GAME);
				}
				else if (tuning_mode() == TUNE_MODE_CAL)
				{
					// Queued: game mode starts when the reference
					// drive has finished.
					tuning_set_mode(TUNE_MODE_GAME);
				}
				printf("START\n\r");
				break;

				case GAME_CMD_PAUSE:
				// Hold position: the PID keeps the last setpoint.
				set_status(NODE2_IDLE);
				solenoid_off();
				printf("PAUSE\n\r");
				break;

				case GAME_CMD_STOP:
				set_status(NODE2_IDLE);
				score = 0;
				solenoid_off();
				if (game_owns_motor())
				tuning_set_mode(TUNE_MODE_OFF);
				printf("STOP\n\r");
				break;
			}
		}

		// Node 1 stops sending joystick frames when it leaves the game.
		// The cart holds its last setpoint.
		if (protocol_check_timeout(JOYSTICK_TIMEOUT_MS))
		printf("joystick timeout -- cart holds position\n\r");

		const joystick_rx_t *joy = protocol_joystick();
		uint8_t running = (status == NODE2_RUNNING) && joy->valid;

		// Joystick x -> cart position (PID). The servo stays locked forward.
		if (running)
		tuning_set_game_setpoint(motor_joystick_to_counts(joy->x, JOYSTICK_RANGE,
		tuning_travel()));

		// Button -> one solenoid shot per press, only while playing.
		solenoid_update((joy->buttons & JOY_BTN_B1) != 0, running);

		// IR beam -> goal. Breaks outside the game are only reported.
		if (ir_update() && status == NODE2_RUNNING)
		report_goal();

		io_link_set_game(score, status == NODE2_RUNNING);
		io_link_tick();
		settings_tick();

		// PID, safety checks and telemetry to the config tool.
		tuning_tick();

		since_status += LOOP_MS;
		if (since_status >= STATUS_PERIOD_MS)
		{
			since_status = 0;
			protocol_send_status(status);
		}
	}
}
