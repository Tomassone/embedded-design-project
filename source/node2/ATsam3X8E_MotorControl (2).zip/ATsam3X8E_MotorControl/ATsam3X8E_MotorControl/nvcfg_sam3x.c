// nvcfg_sam3x.c -- flash access for nvcfg.c on the SAM3X8E
//
// Writes go through the flash programming routine in the chip's ROM
// (IAP), the same method as Atmel's own EFC driver for the SAM3X: the
// ROM routine issues the command and waits until the flash controller
// is ready again.
//
// Pages used: the last two pages of bank 1, controlled by EFC1. The
// program runs from bank 0, so interrupts keep working while bank 1 is
// being written (about 5 ms per page).
//
// All addresses and bit positions are written out as numbers from the
// SAM3X datasheet (chapters "Memories" and "EEFC"). The device headers
// differ between toolchains: Atmel Studio's SAM3X pack, for example, has
// no EEFC_FCR_FKEY() / EEFC_FCR_FCMD() macros. Plain numbers build the
// same everywhere.

#include <stdint.h>
#include "sam.h"            // only for __DSB()
#include "nvcfg.h"

// ---- Memory map (SAM3X8E datasheet, "Product Mapping") ---------------
#define FLASH1_ADDR       0x000C0000u      // bank 1 start (bank 0: 0x00080000)
#define FLASH1_PAGES      1024u            // 256 KB / 256 B
#define FLASH_PAGE_SIZE   256u
#define IAP_ENTRY_PTR     0x00100008u      // ROM: address of the IAP function

// ---- EFC1 registers (base 0x400E0C00) --------------------------------
#define EFC1_FSR          (*(volatile uint32_t *)0x400E0C08u)   // status

#define FSR_FRDY          (1u << 0)        // ready
#define FSR_FCMDE         (1u << 1)        // command error
#define FSR_FLOCKE        (1u << 2)        // lock error

// FCR command word: key in bits 31..24, argument (page) in 23..8,
// command in 7..0.
#define FCR_KEY           (0x5Au << 24)
#define FCR_ARG(page)     (((uint32_t)(page) & 0xFFFFu) << 8)
#define FCMD_EWP          0x03u            // erase page and write page

#define NV_FIRST_PAGE     (FLASH1_PAGES - 2u)     // pages 1022 and 1023 of bank 1
#define NV_BANK           1u                      // EFC1

_Static_assert(FLASH_PAGE_SIZE == NVCFG_PAGE_SIZE, "page size mismatch");


static volatile uint32_t *page_addr(uint8_t idx)
{
	return (volatile uint32_t *)(FLASH1_ADDR + (NV_FIRST_PAGE + idx) * FLASH_PAGE_SIZE);
}


const uint8_t *nvcfg_hal_page(uint8_t idx)
{
	return (const uint8_t *)page_addr(idx);
}


uint32_t nvcfg_hal_write(uint8_t idx, const uint32_t data[NVCFG_PAGE_SIZE / 4])
{
	typedef uint32_t (*iap_fn)(uint32_t efc_index, uint32_t fcr);
	iap_fn iap = (iap_fn)*(const volatile uint32_t *)IAP_ENTRY_PTR;

	// Wait until no other flash command is running.
	while (!(EFC1_FSR & FSR_FRDY))
	;

	// Fill the page latch buffer: 32-bit writes to the page's own
	// addresses. Nothing is programmed until the command below.
	volatile uint32_t *dst = page_addr(idx);
	for (uint32_t i = 0; i < NVCFG_PAGE_SIZE / 4; i++)
	dst[i] = data[i];
	__DSB();

	iap(NV_BANK, FCR_KEY | FCR_ARG(NV_FIRST_PAGE + idx) | FCMD_EWP);

	return EFC1_FSR & (FSR_FCMDE | FSR_FLOCKE);
}