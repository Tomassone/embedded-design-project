// pid.c -- see pid.h

#include "pid.h"

static float clampf(float x, float lo, float hi)
{
    if (x < lo) return lo;
    if (x > hi) return hi;
    return x;
}


void pid_init(pid_ctrl_t *c, float dt, float u_max)
{
    c->kp    = 0.0f;
    c->ki    = 0.0f;
    c->kd    = 0.0f;
    c->tf    = 0.0f;
    c->dt    = dt;
    c->u_max = u_max;
    pid_reset(c);
}


void pid_set_gains(pid_ctrl_t *c, float kp, float ki, float kd, float tf)
{
    c->kp = kp;
    c->ki = ki;
    c->kd = kd;
    c->tf = (tf < 0.0f) ? 0.0f : tf;

    // Ki set to zero: drop the stored integral, otherwise it stays
    // frozen in the output forever.
    if (ki == 0.0f)
        c->integ = 0.0f;
}


void pid_reset(pid_ctrl_t *c)
{
    c->integ  = 0.0f;
    c->deriv  = 0.0f;
    c->prev_y = 0.0f;
    c->first  = true;
    c->p_term = 0.0f;
    c->i_term = 0.0f;
    c->d_term = 0.0f;
    c->u      = 0.0f;
}


float pid_update(pid_ctrl_t *c, float setpoint, float y)
{
    float e = setpoint - y;

    // Proportional
    float p = c->kp * e;

    // Derivative on measurement, first-order filtered:
    //   D(s) = -Kd*s / (tf*s + 1), discretised with backward Euler
    if (c->first)
    {
        c->prev_y = y;
        c->deriv  = 0.0f;
        c->first  = false;
    }
    float d_raw = -c->kd * (y - c->prev_y) / c->dt;
    float alpha = c->dt / (c->tf + c->dt);
    c->deriv   += alpha * (d_raw - c->deriv);
    c->prev_y   = y;

    // Integral with conditional integration (anti-windup).
    // Integrate tentatively. Keep the new value only if the output is
    // not saturated, or if the error pulls the output back inside.
    float i_new = c->integ + c->ki * e * c->dt;
    i_new       = clampf(i_new, -c->u_max, c->u_max);

    float u_unsat = p + i_new + c->deriv;
    bool  sat_hi  = (u_unsat >  c->u_max) && (e > 0.0f);
    bool  sat_lo  = (u_unsat < -c->u_max) && (e < 0.0f);

    if (!sat_hi && !sat_lo)
        c->integ = i_new;

    float u = clampf(p + c->integ + c->deriv, -c->u_max, c->u_max);

    c->p_term = p;
    c->i_term = c->integ;
    c->d_term = c->deriv;
    c->u      = u;
    return u;
}
