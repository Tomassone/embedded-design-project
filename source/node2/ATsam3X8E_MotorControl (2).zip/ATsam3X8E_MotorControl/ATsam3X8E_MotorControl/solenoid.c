#include "board.h"
#include "solenoid.h"

#ifndef SOLENOID_MAX_ON_MS
#define SOLENOID_MAX_ON_MS  500         // hard limit on the pin, above any pulse
#endif

#ifdef HOST_TEST
// PC build: the test or simulator supplies output, read-back and clock.
void     solenoid_hal_drive(uint8_t on);
uint8_t  solenoid_hal_is_on(void);
uint32_t solenoid_hal_millis(void);
#define IRQ_OFF()
#define IRQ_ON()
#else
#include "sam.h"
#include "systime.h"

static void solenoid_hal_drive(uint8_t on)
{
	#if SOLENOID_ACTIVE_HIGH
	if (on) SOLENOID_PIO->PIO_SODR = SOLENOID_PIN;
	else    SOLENOID_PIO->PIO_CODR = SOLENOID_PIN;
	#else
	if (on) SOLENOID_PIO->PIO_CODR = SOLENOID_PIN;
	else    SOLENOID_PIO->PIO_SODR = SOLENOID_PIN;
	#endif
}

// Reads back what the pin is driven to (output data status register),
// independent of the software flags.
static uint8_t solenoid_hal_is_on(void)
{
	uint8_t high = (SOLENOID_PIO->PIO_ODSR & SOLENOID_PIN) ? 1u : 0u;
	#if SOLENOID_ACTIVE_HIGH
	return high;
	#else
	return (uint8_t)!high;
	#endif
}

static uint32_t solenoid_hal_millis(void) { return (uint32_t)time_now(); }

#define IRQ_OFF()  __disable_irq()
#define IRQ_ON()   __enable_irq()
#endif

// Safe limits for the runtime settings.
#define PULSE_MIN_MS      10
#define PULSE_MAX_MS      300
#define COOLDOWN_MIN_MS   100

_Static_assert(SOLENOID_MAX_ON_MS > PULSE_MAX_MS, "hard limit must be above the longest pulse");

// ---- Shared with the 1 ms interrupt -------------------------------------
static volatile uint8_t  active;        // a pulse is running
static volatile uint16_t pulse_ms = SOLENOID_PULSE_MS;
static volatile uint16_t on_ms;         // length of the running pulse so far
static volatile uint16_t pin_on_ms;     // how long the PIN has been on
static volatile uint8_t  done;          // a pulse has ended, length in done_ms
static volatile uint16_t done_ms;
static volatile uint32_t forced;

// ---- Main loop only -----------------------------------------------------
static uint16_t cooldown_ms = SOLENOID_COOLDOWN_MS;
static uint8_t  was_pressed;
static uint32_t last_shot;
static uint8_t  have_shot;
static uint32_t shots;


void solenoid_tick_1ms(void)
{
	if (active)
	{
		// The pulse starts somewhere between two ticks. Ending it on the
		// tick AFTER pulse_ms full ticks guarantees at least pulse_ms on
		// time (pulse_ms .. pulse_ms + 1): never too short to set the
		// mechanism.
		if (++on_ms > pulse_ms)
		{
			solenoid_hal_drive(0);
			active  = 0;
			done_ms = pulse_ms;
			done    = 1;
		}
	}

	// Independent of the flags above: watch the pin itself.
	if (solenoid_hal_is_on())
	{
		if (++pin_on_ms > SOLENOID_MAX_ON_MS)
		{
			solenoid_hal_drive(0);
			active = 0;
			forced++;
		}
	}
	else
	pin_on_ms = 0;
}


void solenoid_init(void)
{
	#ifndef HOST_TEST
	PMC->PMC_PCER0 = (1u << SOLENOID_PIO_ID);
	SOLENOID_PIO->PIO_PUDR = SOLENOID_PIN;      // no pull-up into the driver
	solenoid_hal_drive(0);                      // level before output enable
	SOLENOID_PIO->PIO_OER  = SOLENOID_PIN;
	SOLENOID_PIO->PIO_PER  = SOLENOID_PIN;
	#else
	solenoid_hal_drive(0);
	#endif
	active      = 0;
	on_ms       = 0;
	pin_on_ms   = 0;
	done        = 0;
	forced      = 0;
	was_pressed = 1;        // a button already held at start-up is no edge
	have_shot   = 0;
	shots       = 0;
}


void solenoid_off(void)
{
	IRQ_OFF();
	solenoid_hal_drive(0);
	if (active)
	{
		done_ms = on_ms;
		done    = 1;
	}
	active = 0;
	IRQ_ON();
}


uint8_t solenoid_fire(void)
{
	uint32_t now = solenoid_hal_millis();
	uint8_t  fired = 0;

	IRQ_OFF();
	if (!active && !(have_shot && (uint32_t)(now - last_shot) < cooldown_ms))
	{
		on_ms  = 0;
		active = 1;
		solenoid_hal_drive(1);
		fired  = 1;
	}
	IRQ_ON();

	if (fired)
	{
		last_shot = now;
		have_shot = 1;
		shots++;
	}
	return fired;
}


void solenoid_update(uint8_t pressed, uint8_t enabled)
{
	// Rising edge only. was_pressed is tracked even when shooting is not
	// allowed: a button held while the game starts is not a shot.
	uint8_t rising = pressed && !was_pressed;
	was_pressed    = pressed ? 1u : 0u;

	if (rising && enabled)
	(void)solenoid_fire();
}


#ifndef HOST_TEST
// Called by SysTick_Handler (systime.c) every millisecond.
void systime_1ms_hook(void)
{
	solenoid_tick_1ms();
}
#endif


uint8_t  solenoid_active(void)     { return solenoid_hal_is_on(); }
uint32_t solenoid_shots(void)      { return shots; }
uint32_t solenoid_forced_off(void) { return forced; }


uint8_t solenoid_take_pulse(uint16_t *ms)
{
	uint8_t got = 0;

	IRQ_OFF();
	if (done)
	{
		*ms  = done_ms;
		done = 0;
		got  = 1;
	}
	IRQ_ON();
	return got;
}


void solenoid_set_timing(uint16_t pulse, uint16_t cooldown)
{
	if (pulse < PULSE_MIN_MS) pulse = PULSE_MIN_MS;
	if (pulse > PULSE_MAX_MS) pulse = PULSE_MAX_MS;

	// The coil must rest at least as long as it was on.
	uint16_t min_cool = (uint16_t)(2u * pulse);
	if (min_cool < COOLDOWN_MIN_MS) min_cool = COOLDOWN_MIN_MS;
	if (cooldown < min_cool)        cooldown = min_cool;
	if (cooldown > 10000)           cooldown = 10000;

	pulse_ms    = pulse;
	cooldown_ms = cooldown;
}


void solenoid_get_timing(uint16_t *pulse, uint16_t *cooldown)
{
	*pulse    = pulse_ms;
	*cooldown = cooldown_ms;
}
