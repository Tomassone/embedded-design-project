#pragma once
#include <stdbool.h>
#include <stdint.h>

// ---------------------------------------------------------------------
// settings.h -- everything the config tool can change, stored in flash
//
// Stored: PID gains and output limit, measured travel, reference drive
// at power-up, IR beam settings, solenoid timing, servo forward position.
//
// Power-up:  settings_boot() loads the record and applies it, or keeps
//            the built-in defaults (board.h, pid_gains.h) if none is
//            stored. main() then starts the reference drive.
// Changing:  the config tool changes the values in RAM, as before.
// Saving:    "$SAVE" from the config tool writes the current values.
// ---------------------------------------------------------------------

// Loads and applies the stored settings. Prints one status line.
// Returns true if a stored record was used.
bool settings_boot(void);

// Call once per loop pass: reports $NV to the config tool when the
// "unsaved changes" state changes.
void settings_tick(void);

// '$' commands SAVE, LOAD, NVERASE, NV, SERVO. Returns true if handled.
bool settings_command(const char *cmd, const long *a, uint8_t n);

// Prints $NV (and $SERVO).
void settings_report(void);
