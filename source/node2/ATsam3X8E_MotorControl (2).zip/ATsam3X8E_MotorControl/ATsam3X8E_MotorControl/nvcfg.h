#pragma once
#include <stdint.h>

// ---------------------------------------------------------------------
// nvcfg.h -- non-volatile settings record in the SAM3X internal flash
//
// The SAM3X8E has no EEPROM. The record lives in the last two 256-byte
// pages of flash bank 1 (0x000FFE00 and 0x000FFF00). The program runs
// from bank 0, so bank 1 can be written while the program keeps running.
//
// Power-fail safe: each save goes to the page that does NOT hold the
// newest record, with a sequence number and a CRC-32. At start-up the
// valid record with the highest sequence number wins. A save that is
// interrupted leaves the previous record intact.
//
// Flash endurance is about 10 000 erase cycles per page: saving on
// request from the config tool is fine, saving in a loop is not.
// ---------------------------------------------------------------------

#define NVCFG_PAYLOAD_MAX   200         // bytes of user data per record

typedef enum
{
    NVCFG_OK          = 0,
    NVCFG_EMPTY       = 1,              // nothing stored (or wrong version)
    NVCFG_ERR_SIZE    = 2,              // payload too large
    NVCFG_ERR_FLASH   = 3,              // flash controller reported an error
    NVCFG_ERR_VERIFY  = 4,              // read-back did not match
} nvcfg_result_t;

// Loads the newest valid record. version must match the stored one.
// On NVCFG_OK the payload is copied to data (len bytes).
nvcfg_result_t nvcfg_load(uint16_t version, void *data, uint16_t len);

// Saves a new record, alternating between the two pages.
nvcfg_result_t nvcfg_save(uint16_t version, const void *data, uint16_t len);

// Invalidates both pages: the next start uses the built-in defaults.
nvcfg_result_t nvcfg_erase(void);

// Sequence number of the newest valid record, 0 if none.
uint32_t       nvcfg_seq(void);

const char    *nvcfg_result_text(nvcfg_result_t r);

// ---- Hardware layer (nvcfg_sam3x.c, or a fake for PC tests) -----------
#define NVCFG_PAGE_SIZE     256u

// Pointer to the current content of page 0 or 1 (memory-mapped flash).
const uint8_t *nvcfg_hal_page(uint8_t idx);

// Erases and writes one full page. 0 = OK, otherwise the error flags.
uint32_t       nvcfg_hal_write(uint8_t idx, const uint32_t data[NVCFG_PAGE_SIZE / 4]);
