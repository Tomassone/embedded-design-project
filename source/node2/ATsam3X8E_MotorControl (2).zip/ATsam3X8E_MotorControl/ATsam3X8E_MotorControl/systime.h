#pragma once
#include <stdint.h>

// ---------------------------------------------------------------------
// systime.h -- system time from SysTick
//
// Replaces the course starter's time.h (renamed: "time.h" can clash
// with the C library's <time.h> in Atmel Studio).
//
// One tick = 1 ms. time_now() and msecs() use the same unit, so code
// written as "time_now() - t > msecs(200)" works unchanged.
// ---------------------------------------------------------------------

typedef uint64_t systime_t;

// Starts SysTick. Call once after SystemInit().
// cpufreq: MCK in Hz (84 MHz after SystemInit).
void systime_init(uint32_t cpufreq);

// Milliseconds since systime_init(). 64 bit: never wraps in practice.
systime_t time_now(void);

#define msecs(ms)   ((systime_t)(ms))
#define secs(s)     ((systime_t)(s) * 1000u)

// Busy-waits until time_now() reaches t.
void time_spinUntil(systime_t t);

// Fixed-rate loop. The body runs, then the loop waits for the next
// period boundary, so the period stays exact even if the body's run
// time varies:
//
//     time_doPeriodic(msecs(10)) { ... }
//
// If the body takes longer than one period, the next pass starts at
// once and the loop catches up. It never skips a pass.
#define time_doPeriodic(period)                                          \
    for (systime_t _tp_next = time_now() + (period); ;                   \
         time_spinUntil(_tp_next), _tp_next += (period))
