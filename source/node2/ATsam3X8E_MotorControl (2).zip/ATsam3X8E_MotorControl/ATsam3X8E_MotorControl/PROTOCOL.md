# Serial protocol (node 2 ↔ Byggern Config Tool)

ASCII lines. Every tuner line starts with `$` and ends with `\n`.
Fields are separated by commas or spaces. Only integers are used.
Other bytes are not touched, so the old test keys (`g e r s`) still work.

Units: gains in micro-units (1.0 = 1000000), `tf` in µs,
`u` in permille (−1000…1000), positions in encoder counts.

## PC → node 2

| Command | Meaning |
|---|---|
| `$HELLO` | Handshake. Replies `$HELLO`, `$GAINS`, `$STATE` |
| `$GET` | Replies `$GAINS` and `$STATE` |
| `$SET,kp,ki,kd,tf` | Set gains (µ-units, tf in µs) |
| `$LIM,umax` | Output limit in permille |
| `$MODE,n` | 0 off, 1 game, 2 PC setpoint, 3 open loop, 4 relay |
| `$CAL,m` | Reference drive (mode 5). 0 = home only, 1 = home + measure travel. Any `$MODE` aborts it |
| `$SP,counts` | Setpoint for mode 2 |
| `$U,permille` | Motor command for mode 3 |
| `$RELAY,d,hyst,centre` | Relay amplitude, hysteresis, centre for mode 4 |
| `$STREAM,div` | Telemetry every `div` control ticks, 0 = off |
| `$SOFT,lo,hi` | Soft limits, `lo ≥ hi` disables |
| `$ZERO` | Motor off, encoder = 0 |
| `$PING` | Keep-alive, no reply. Sent every 0.5 s by the tool |
| `$SOL` or `$SOL,1` | Fire one solenoid shot (pulse + cooldown enforced by the node) |
| `$SOL,0` | Release the solenoid now |
| `$SOLCFG,pulse_ms,cooldown_ms` | Shot timing. Clamped: pulse 10–300 ms, cooldown ≥ 2 × pulse and ≥ 100 ms |
| `$IRCFG,debounce_ms,holdoff_ms,level` | IR beam: minimum block for a break, ignore time after a goal, pin level that means "blocked" |
| `$IO` | Report `$IO`, `$IRCFG`, `$SOLCFG` now |
| `$IOCLR` | Clear the IR counters |
| `$SERVO,us` | Servo forward position, 900–2100 µs (1500 = middle). Applies at once |
| `$BOOT,m` | Motor init at power-up: 0 none, 1 home (use saved travel), 2 home + measure travel |
| `$SAVE` | Store all settings in flash. Refused while a reference drive runs |
| `$LOAD` | Re-apply the stored settings (undo unsaved changes) |
| `$NVERASE` | Erase the stored settings: next power-up uses the built-in defaults |
| `$NV` | Report `$NV` and `$SERVO` |

## Node 2 → PC

| Line | Meaning |
|---|---|
| `$HELLO,PIDTUNE,ver,dt_ms` | Protocol version (3) and control period |
| `$IO,raw,blocked,stuck,sol,shots,breaks,glitches,ignored,score,running` | I/O state. Sent on every change (at most every 20 ms) and every 500 ms while the tool is connected |
| `$IREV,dur_ms,kind` | A beam break has ended: its length; kind 1 = counted, 2 = ignored (holdoff) |
| `$GOAL,score` | Goal counted (beam break while the game runs) |
| `$IRCFG,debounce_ms,holdoff_ms,level` | Current IR settings |
| `$SOLCFG,pulse_ms,cooldown_ms` | Current solenoid timing |
| `$NV,stored,seq,dirty,boot` | Flash state: settings stored 0/1, save counter, running values differ from stored 0/1, boot mode. Sent on $HELLO/$GET and whenever *dirty* changes |
| `$SERVO,us` | Current servo position |
| `$TRAVEL,counts,source,homed` | *source*: 0 default, 1 measured now, 2 from saved settings |

| `$CAL,phase,pos` | Reference drive progress: LEFT, SETTLE, RIGHT, CENTER |
| `$CALDONE,travel,measured` | Reference drive finished. After a measurement the soft limits are set to 100 … travel−100 |
| `$GAINS,kp,ki,kd,tf,umax` | Current gains |
| `$STATE,mode,pos,div,lo,hi,dt_ms` | Current state |
| `$T,t_ms,sp,pos,u,p,i,d` | Telemetry. p/i/d are the PID terms in permille |
| `$R,t_ms,dir,pos` | Relay switched direction (exact timing for autotune) |
| `$OK,cmd[,…]` | Command accepted |
| `$ERR,text` | Error, also `link timeout` and `soft limit` safety stops |
| `$ERR,cal,reason` | Reference drive failed: wrong direction, no end stop, travel too short, aborted |
