#include "board.h"
#include "ir.h"

#ifdef HOST_TEST
// PC build: the test or simulator supplies the pin and the clock.
uint8_t  ir_hal_read(void);
uint32_t ir_hal_millis(void);
#define IRQ_OFF()
#define IRQ_ON()
#else
#include "sam.h"
#include "systime.h"
static uint8_t  ir_hal_read(void)   { return (IR_PIO->PIO_PDSR & IR_PIN) ? 1u : 0u; }
static uint32_t ir_hal_millis(void) { return (uint32_t)time_now(); }
#define IRQ_OFF()  __disable_irq()
#define IRQ_ON()   __enable_irq()
#endif

#ifndef IR_REARM_MS
#define IR_REARM_MS     500     // beam must be clear this long before the next goal
#endif

// ---- Settings -----------------------------------------------------------
static uint16_t debounce_ms   = IR_DEBOUNCE_MS;
static uint16_t holdoff_ms    = IR_HOLDOFF_MS;
static uint8_t  blocked_level = IR_BLOCKED_LEVEL;

// ---- State shared with the ISR (written in ir_edge) ---------------------
static volatile uint8_t  raw;            // last pin level
static volatile uint8_t  blocked;        // current beam state
static volatile uint32_t blocked_since;  // ms, start of the current block
static volatile uint8_t  decided;        // current block already judged
static volatile uint8_t  cur_kind;       // 1 counted, 2 holdoff, 0 none
static volatile uint8_t  pending;        // a counted break waits for ir_poll
static volatile uint8_t  fin_ready;      // a judged block has ended
static volatile uint32_t fin_dur;
static volatile uint8_t  fin_kind;
static volatile uint32_t glitches;
static volatile uint8_t  armed;          // a break may count as a goal
static volatile uint32_t clear_since;    // ms, start of the current clear phase

// ---- State owned by the main loop ---------------------------------------
static uint32_t last_counted;            // ms of the last counted break
static uint8_t  have_counted;
static uint32_t breaks;
static uint32_t suppressed;


// Judges the current block once it has lasted debounce_ms.
// Called from ir_edge (block ended) and ir_poll (block still going).
//
// Only an ARMED detector counts. A counted break disarms it, and it is
// re-armed in ir_poll() only after the beam has been clear without a
// break for IR_REARM_MS. A ball resting in the beam, even with the
// signal flickering at the beam edge, therefore counts exactly once.
static void judge(uint32_t now)
{
	if (!armed)
	{
		cur_kind = 2;
		suppressed++;
	}
	else
	{
		cur_kind     = 1;
		pending      = 1;
		armed        = 0;
		last_counted = now;
		have_counted = 1;
		breaks++;
	}
	decided = 1;
}


void ir_edge(uint8_t level, uint32_t now)
{
	raw = level;
	uint8_t b = (level == blocked_level);

	if (b == blocked)
	return;                             // no state change

	if (b)
	{
		// Any block, even a short glitch, restarts the clear time that
		// re-arming needs.
		blocked       = 1;
		blocked_since = now;
		decided       = 0;
		cur_kind      = 0;
		return;
	}

	// Beam clear again: judge a block that was long enough but ended
	// between two loop passes.
	blocked     = 0;
	clear_since = now;
	uint32_t dur = now - blocked_since;

	if (!decided)
	{
		if (dur >= debounce_ms)
		judge(now);
		else
		{
			glitches++;
			return;
		}
	}

	fin_dur   = dur;
	fin_kind  = cur_kind;
	fin_ready = 1;
}


uint8_t ir_poll(uint32_t now)
{
	IRQ_OFF();
	if (blocked && !decided && (uint32_t)(now - blocked_since) >= debounce_ms)
	judge(now);

	// Re-arm: beam clear without interruption for IR_REARM_MS, and at
	// least holdoff_ms since the last goal.
	if (!armed && !blocked
	&& (uint32_t)(now - clear_since) >= IR_REARM_MS
	&& (!have_counted || (uint32_t)(now - last_counted) >= holdoff_ms))
	armed = 1;

	uint8_t event = pending;
	pending = 0;
	IRQ_ON();

	return event;
}


void ir_reset_logic(uint8_t level, uint32_t now)
{
	IRQ_OFF();
	raw           = level;
	blocked       = (level == blocked_level);
	blocked_since = now;
	decided       = 1;                      // a block present at start is not a goal
	cur_kind      = 0;
	armed         = !blocked;               // clear beam: ready; blocked: wait for clear
	clear_since   = now;
	pending       = 0;
	fin_ready     = 0;
	have_counted  = 0;
	IRQ_ON();
}


// ---------------------------------------------------------------------
// Hardware
// ---------------------------------------------------------------------

#ifndef HOST_TEST
void IR_IRQ_HANDLER(void)
{
	uint32_t isr = IR_PIO->PIO_ISR;         // reading clears the flags
	if (isr & IR_PIN)
	ir_edge(ir_hal_read(), ir_hal_millis());
}
#endif


void ir_init(void)
{
	#ifndef HOST_TEST
	PMC->PMC_PCER0 = (1u << IR_PIO_ID);     // clock needed to read inputs

	IR_PIO->PIO_PER = IR_PIN;               // GPIO
	IR_PIO->PIO_ODR = IR_PIN;               // input
	#if IR_PULLUP
	IR_PIO->PIO_PUER = IR_PIN;
	#else
	IR_PIO->PIO_PUDR = IR_PIN;
	#endif

	// Hardware debounce filter: pulses shorter than about 1 ms never reach
	// the interrupt. Slow clock 32 768 Hz, period = 2 * (DIV + 1) / 32768.
	IR_PIO->PIO_SCDR  = 15;                 // about 1 ms
	IR_PIO->PIO_DIFSR = IR_PIN;             // debounce, not glitch filter
	IR_PIO->PIO_IFER  = IR_PIN;

	(void)IR_PIO->PIO_ISR;                  // drop stale flags
	IR_PIO->PIO_AIMDR = IR_PIN;             // interrupt on both edges
	IR_PIO->PIO_IER   = IR_PIN;

	NVIC_ClearPendingIRQ(IR_IRQn);
	NVIC_SetPriority(IR_IRQn, 3);
	NVIC_EnableIRQ(IR_IRQn);
	#endif

	breaks = suppressed = glitches = 0;
	ir_reset_logic(ir_hal_read(), ir_hal_millis());
}


uint8_t ir_update(void)
{
	uint32_t now = ir_hal_millis();

	#ifndef HOST_TEST
	// Safety net: if an edge was missed, resynchronise from the pin.
	uint8_t level = ir_hal_read();
	if (level != raw)
	{
		IRQ_OFF();
		ir_edge(level, now);
		IRQ_ON();
	}
	#endif
	return ir_poll(now);
}


uint8_t ir_raw(void)      { return raw; }
uint8_t ir_blocked(void)  { return blocked; }

uint8_t ir_stuck(void)
{
	return blocked && (uint32_t)(ir_hal_millis() - blocked_since) >= IR_STUCK_MS;
}

uint32_t ir_breaks(void)     { return breaks; }
uint32_t ir_glitches(void)   { return glitches; }
uint32_t ir_suppressed(void) { return suppressed; }

void ir_clear(void)
{
	IRQ_OFF();
	breaks = suppressed = glitches = 0;
	IRQ_ON();
}


uint8_t ir_take_finished(uint32_t *dur_ms, uint8_t *kind)
{
	uint8_t got = 0;

	IRQ_OFF();
	if (fin_ready)
	{
		*dur_ms   = fin_dur;
		*kind     = fin_kind;
		fin_ready = 0;
		got       = 1;
	}
	IRQ_ON();
	return got;
}


void ir_set_config(uint16_t debounce, uint16_t holdoff, uint8_t level)
{
	if (debounce < 1)     debounce = 1;
	if (debounce > 1000)  debounce = 1000;
	if (holdoff > 10000)  holdoff  = 10000;

	debounce_ms   = debounce;
	holdoff_ms    = holdoff;

	if ((level ? 1u : 0u) != blocked_level)
	{
		blocked_level = level ? 1u : 0u;
		ir_reset_logic(ir_hal_read(), ir_hal_millis());   // re-read with new polarity
	}
}


void ir_get_config(uint16_t *debounce, uint16_t *holdoff, uint8_t *level)
{
	*debounce = debounce_ms;
	*holdoff  = holdoff_ms;
	*level    = blocked_level;
}