#pragma once
#include <stdbool.h>
#include <stdint.h>

// ---------------------------------------------------------------------
// io_link.h -- solenoid and IR beam over the config tool link
//
// Adds these '$' commands to the tuner protocol (see PROTOCOL.md):
//   $SOL[,1]  fire one shot        $SOL,0  release now
//   $SOLCFG,pulse_ms,cooldown_ms
//   $IRCFG,debounce_ms,holdoff_ms,blocked_level
//   $IO       report now           $IOCLR  clear the counters
//
// and reports $IO, $IREV, $GOAL, $IRCFG, $SOLCFG. Hooked into tuning.c
// through tuning_ext_command() / tuning_ext_report().
// ---------------------------------------------------------------------

// Call once per loop pass, after ir_update(). Sends $IO when something
// changed (at most every 20 ms) and every 500 ms while the config tool
// is connected, and $IREV for every finished beam break.
void io_link_tick(void);

// Game state shown in $IO.
void io_link_set_game(uint8_t score, bool running);

// Announces a goal to the config tool.
void io_link_goal(uint8_t score);

// Prints $IO, $IRCFG and $SOLCFG.
void io_link_report(void);
