#include <stdio.h>
#include <string.h>

#include "io_link.h"
#include "ir.h"
#include "solenoid.h"
#include "tuning.h"
#include "motor_hal.h"
#include "settings.h"

#define IO_MIN_GAP_MS     20      // fastest $IO rate on changes
#define IO_HEARTBEAT_MS   500     // $IO rate when nothing changes

static uint8_t  game_score;
static bool     game_running;

static uint32_t last_sent_ms;
static uint8_t  last_sig_valid;
static uint32_t last_sig;


static void print_io(void)
{
	printf("$IO,%u,%u,%u,%u,%lu,%lu,%lu,%lu,%u,%u,%lu\r\n",
	(unsigned)ir_raw(), (unsigned)ir_blocked(), (unsigned)ir_stuck(),
	(unsigned)solenoid_active(), (unsigned long)solenoid_shots(),
	(unsigned long)ir_breaks(), (unsigned long)ir_glitches(),
	(unsigned long)ir_suppressed(),
	(unsigned)game_score, game_running ? 1u : 0u,
	(unsigned long)solenoid_forced_off());
}


static void print_cfg(void)
{
	uint16_t deb, hold, pulse, cool;
	uint8_t  lvl;

	ir_get_config(&deb, &hold, &lvl);
	solenoid_get_timing(&pulse, &cool);
	printf("$IRCFG,%u,%u,%u\r\n", (unsigned)deb, (unsigned)hold, (unsigned)lvl);
	printf("$SOLCFG,%u,%u\r\n", (unsigned)pulse, (unsigned)cool);
}


void io_link_report(void)
{
	print_io();
	print_cfg();
}


// Everything shown in $IO except the slow counters, packed for a cheap
// "did anything change" test.
static uint32_t signature(void)
{
	return  (uint32_t)ir_raw()
	| ((uint32_t)ir_blocked()      << 1)
	| ((uint32_t)ir_stuck()        << 2)
	| ((uint32_t)solenoid_active() << 3)
	| ((uint32_t)(game_running ? 1u : 0u) << 4)
	| ((uint32_t)game_score        << 8)
	| ((uint32_t)(solenoid_shots() & 0xFFu) << 16)
	| ((uint32_t)(ir_breaks()      & 0xFFu) << 24);
}


void io_link_tick(void)
{
	// Finished beam breaks: one line each, also without the tool, so a
	// plain terminal shows them too.
	uint32_t dur;
	uint8_t  kind;
	while (ir_take_finished(&dur, &kind))
	printf("$IREV,%lu,%u\r\n", (unsigned long)dur, (unsigned)kind);

	// Finished solenoid pulses with their measured length.
	uint16_t pulse;
	while (solenoid_take_pulse(&pulse))
	printf("$SOLEV,%u,%lu\r\n", (unsigned)pulse,
	(unsigned long)solenoid_forced_off());

	if (!tuning_link_active())
	{
		last_sig_valid = 0;
		return;
	}

	uint32_t now = motor_hal_millis();
	uint32_t sig = signature();
	uint32_t gap = now - last_sent_ms;

	bool changed = !last_sig_valid || sig != last_sig;

	if ((changed && gap >= IO_MIN_GAP_MS) || gap >= IO_HEARTBEAT_MS)
	{
		print_io();
		last_sent_ms   = now;
		last_sig       = sig;
		last_sig_valid = 1;
	}
}


void io_link_set_game(uint8_t score, bool running)
{
	game_score   = score;
	game_running = running;
}


void io_link_goal(uint8_t score)
{
	printf("$GOAL,%u\r\n", (unsigned)score);
}


// ---------------------------------------------------------------------
// Hooks called by tuning.c
// ---------------------------------------------------------------------

bool tuning_ext_command(const char *cmd, const long *a, uint8_t n)
{
	if (settings_command(cmd, a, n))
	return true;

	if (strcmp(cmd, "SOL") == 0 && n <= 1)
	{
		if (n == 1 && a[0] == 0)
		{
			solenoid_off();
			printf("$OK,SOL,0\r\n");
		}
		else if (solenoid_fire())
		printf("$OK,SOL,1\r\n");
		else
		printf("$ERR,SOL,busy or cooling down\r\n");
		print_io();
		return true;
	}

	if (strcmp(cmd, "SOLCFG") == 0 && n == 2)
	{
		solenoid_set_timing((uint16_t)(a[0] < 0 ? 0 : a[0] > 65535 ? 65535 : a[0]),
		(uint16_t)(a[1] < 0 ? 0 : a[1] > 65535 ? 65535 : a[1]));
		print_cfg();
		return true;
	}

	if (strcmp(cmd, "IRCFG") == 0 && n == 3)
	{
		ir_set_config((uint16_t)(a[0] < 0 ? 0 : a[0] > 65535 ? 65535 : a[0]),
		(uint16_t)(a[1] < 0 ? 0 : a[1] > 65535 ? 65535 : a[1]),
		(uint8_t)(a[2] != 0));
		print_cfg();
		print_io();
		return true;
	}

	if (strcmp(cmd, "IO") == 0 && n == 0)
	{
		io_link_report();
		return true;
	}

	if (strcmp(cmd, "IOCLR") == 0 && n == 0)
	{
		ir_clear();
		printf("$OK,IOCLR\r\n");
		print_io();
		return true;
	}

	return false;
}


void tuning_ext_report(void)
{
	io_link_report();
	settings_report();
}