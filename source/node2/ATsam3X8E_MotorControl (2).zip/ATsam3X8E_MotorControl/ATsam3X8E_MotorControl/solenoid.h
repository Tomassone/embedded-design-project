#pragma once
#include <stdint.h>

// ---------------------------------------------------------------------
// solenoid.h -- shooter: one fixed pulse per rising edge
//
//   button  ____/?????????????????\_____/?????
//   output  ____/????\______________________/????\___
//               |<-->|  pulse_ms            ^ next rising edge,
//               |<--------->| cooldown_ms     after the cooldown
//
// - A shot needs a RISING edge of the button. Holding it does nothing
//   more; it must be released and pressed again.
// - The pulse is ended by the 1 ms SysTick interrupt, not by the main
//   loop, so a busy or stalled main loop cannot stretch it.
// - Hard limit on the pin itself: if the output is on for more than
//   SOLENOID_MAX_ON_MS for any reason, it is forced off and counted.
// ---------------------------------------------------------------------

// Call early in main(): output inactive, reset pull-up removed.
void     solenoid_init(void);

// Call once per loop pass with the joystick button (1 = pressed) and
// whether shooting is allowed (game running). Fires on the rising edge.
void     solenoid_update(uint8_t pressed, uint8_t enabled);

// One shot now (config tool, 'f' key). Returns 1 if fired, 0 if a pulse
// or the cooldown is still running.
uint8_t  solenoid_fire(void);

// Releases the plunger immediately (STOP, PAUSE, fault).
void     solenoid_off(void);

// Called every 1 ms from the SysTick interrupt (systime.c). Ends the
// pulse and enforces the hard limit.
void     solenoid_tick_1ms(void);

uint8_t  solenoid_active(void);     // 1 while the OUTPUT PIN is on (read back)
uint32_t solenoid_shots(void);      // shots since start
uint32_t solenoid_forced_off(void); // times the hard limit had to act

// A pulse has ended: its measured length in ms, once. 0 = none new.
uint8_t  solenoid_take_pulse(uint16_t *ms);

// Runtime timing (defaults from board.h), clamped to safe limits.
void     solenoid_set_timing(uint16_t pulse_ms, uint16_t cooldown_ms);
void     solenoid_get_timing(uint16_t *pulse_ms, uint16_t *cooldown_ms);