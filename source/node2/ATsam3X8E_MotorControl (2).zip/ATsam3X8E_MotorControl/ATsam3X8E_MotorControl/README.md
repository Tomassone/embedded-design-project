# Node 2 – exercises 7 and 8 (IR goal, motor, PID, solenoid) + config tool link

Arduino Due / SAM3X8E. Builds on `node2_can.zip` (exercise 6) and adds the
position controller, the motor and encoder driver, the solenoid and the
link to the Byggern Config Tool.

## Files

| File | Status | Job |
|---|---|---|
| `main.c` | **changed** | game loop: joystick → cart (PID) and servo, button → solenoid |
| `board.h` | **new** | all exercise 8 pins and constants, checked against the shield schematic |
| `motor.c/h` | **new** | motor PWM + direction, encoder (TC2 quadrature decoder), homing |
| `solenoid.c/h` | **new** | shots from button or config tool, pulse length and cooldown |
| `ir.c/h` | **new** | IR beam on a digital input: edge interrupt, debounce, holdoff, goal events |
| `io_link.c/h` | **new** | solenoid and IR commands / status for the config tool |
| `servo.c/h` | **new** | servo locked forward, position in µs (default 1500 = middle) |
| `settings.c/h` | **new** | everything the config tool sets: load at power-up, `$SAVE`/`$LOAD`/`$NVERASE` |
| `nvcfg.c/h` | **new** | power-fail-safe record in flash (two pages, sequence number, CRC) |
| `nvcfg_sam3x.c` | **new** | flash write through the SAM3X ROM routine, last 2 pages of bank 1 |
| `pid.c/h` | **new** | discrete PID, anti-windup, filtered D |
| `tuning.c/h` | **new** | `$` serial protocol for the config tool, safety stops |
| `motor_hal.h` | **new** | interface between `tuning.c` and `motor.c` |
| `uart.c/h` | **new** | SAM3X UART (PA8/PA9), interrupt-driven, `printf` support |
| `systime.c/h` | **new** | 1 ms SysTick: `time_now()`, `msecs()`, `time_doPeriodic()` |
| `can.c/h` | unchanged | CAN driver (from `node2_can.zip`) |
| `protocol.c/h` | include only | CAN protocol with node 1; now includes `systime.h` |

`uart` and `systime` replace the course starter's `uart` and `time`.
`time.h` was renamed to `systime.h` because the C library has its own
`<time.h>`. The project is complete: startup code and linker script
come from Atmel Studio itself.

## Pins for your own circuits

| Signal | Due pin | SAM3X | Direction | Notes |
|---|---|---|---|---|
| IR beam, digital | **D2** | PB25 | input | 0–3.3 V only. Comparator / op-amp output. Push-pull, or set `IR_PULLUP 1` for open collector |
| Solenoid driver | **D3** | PC28 | output | 3.3 V logic. Drives a logic-level MOSFET or transistor, never the coil. Flyback diode across the coil |

Both are on the D0–D7 header next to the shield's D4/D5/D7, and the
shield does not use them. Connect the grounds of both circuits to the
Due's GND.

A 10 kΩ pull-down from the MOSFET gate (or transistor base) to GND keeps
the solenoid off during the few milliseconds after a reset, before the
firmware drives D3 low.

## Atmel Studio 7

1. *File → New → Project → GCC C Executable Project*, device **ATSAM3X8E**
   (your `ATsam3X8E_MotorControl` project is fine).
2. Delete the generated `main.c` from the project.
3. Copy all `.c` and `.h` files from this folder into the project folder.
   Then in the Solution Explorer: right-click the project →
   *Add → Existing Item…* → select all of them. Copying alone is not
   enough: Atmel Studio only compiles files that are added to the project.
4. Leave `Device_Startup` (startup and `system_sam3xa.c`) as generated.
5. Build (F7). Expect one warning from `board.h` until the pins are
   verified.
6. Flash with the Atmel-ICE over JTAG/SWD as for node 1:
   *Tools → Device Programming*, or *Start Without Debugging*.

If `printf` causes linker errors about `_sbrk`, `_close` or similar,
make sure `uart.c` is part of the project: it provides those functions.

### Stack size (important)

Give the program an 8 KB stack. *Project → Properties → Toolchain →
ARM/GNU Linker → Miscellaneous → Linker Flags*, add:

    -Wl,--defsym=STACK_SIZE=0x2000 -Wl,--defsym=__stack_size__=0x2000

Also tick *ARM/GNU Linker → General → Use size optimized library
(--specs=nano.specs)* if it is offered. It halves the flash size and
uses less stack.

Check after flashing: the banner prints `stack 8192 bytes`, and the `s`
key prints `stack used … of 8192 bytes`. A warning appears when the
stack is below 4 KB. Symptom of a too-small stack: readable banner, then
binary garbage in the terminal, then no more replies.

## Makefile (Linux, instead of Atmel Studio)

Replace `SOURCE_FILES` with the list in `Makefile.sources`, and drop the
starter's `uart.c` and `time.c` from the folder.

## Behaviour

| Event | Action |
|---|---|
| Power-up | load saved settings → motor init (reference drive as saved) → motor off until START |
| `h` / `c` key, or tool buttons | home / home + measure travel (see "Reference drive") |
| START from node 1 | PID on, cart holds position until the first joystick frame |
| Joystick x | cart position setpoint (left margin … right margin) |
| Servo | locked forward, at the saved position (default 1500 µs) |
| Joystick button | one solenoid shot, at most every 400 ms (game running only) |
| IR beam break ≥ 5 ms | goal while the game runs: score +1, sent to node 1. Breaks outside the game are only reported |
| Further breaks within 1 s | ignored: the bouncing ball counts once |
| `f` / `i` key | fire the solenoid / print IR and solenoid status |
| Config tool, Game I/O tab | fire, timing, IR polarity / debounce / holdoff, live status |
| PAUSE | PID holds the cart where it is, solenoid off |
| STOP | motor off, score reset |
| Joystick timeout (200 ms) | cart holds its last setpoint |
| `$` lines from the config tool | gains, modes, telemetry, reference drive (see PROTOCOL.md) |

While the config tool drives the motor (PC setpoint, open loop, relay
test), START and STOP from node 1 do not take it over. Switch the tool
back to *Off* or *Game* to hand control back.

## Saved settings and power-up

At every power-up node 2:

1. starts with the built-in defaults (`board.h`, `pid_gains.h`),
2. loads the settings saved from the config tool, if any:
   PID gains and output limit, travel, motor init mode, IR beam
   settings, solenoid timing, servo forward position,
3. runs the motor init (reference drive) as saved:

| Motor init | What happens | Time |
|---|---|---|
| 2 – home + measure travel | default when nothing is saved | ≈ 6 s |
| 1 – home only | uses the saved travel for joystick range and soft limits | ≈ 2 s |
| 0 – none | encoder zero = wherever the cart stands | 0 |

4. switches the motor off until START from node 1.

Change values in the config tool as before, then **Save to node**
(top bar, Ctrl+S). The top bar shows *unsaved changes* until you do.
Saving is refused while a reference drive is running, because the travel
is not known yet then.

**Storage.** The SAM3X has no EEPROM, so the settings go into the last
two 256-byte pages of the internal flash (bank 1, `0x000FFE00`). The
program runs from bank 0 and keeps running during a save (about 5 ms).
Each save writes the page that does not hold the newest record, with a
sequence number and CRC: a power cut during a save keeps the previous
settings. A flash page survives about 10 000 saves.

**Re-flashing the firmware** with a chip erase also erases the saved
settings: the node then starts with the defaults and does a full
reference drive. The config tool notices this ("no saved settings") and
offers to restore the settings last saved from this PC. If your Atmel
Studio offers *Erase only program area* (project properties → Tool →
Programming settings), the saved settings survive a re-flash.

If you change the layout of `settings_t` in `settings.c`, increase
`SETTINGS_VERSION`: an old record is then ignored instead of misread.

## Reference drive (encoder calibration)

The quadrature encoder only counts relative movement, so after power-up
the position is unknown. The reference drive gives it a fixed zero:

1. **Home:** the cart drives left at `CAL_U` (30 %). The end stop is
   detected by **stall**: the encoder moves less than `CAL_STALL_COUNTS`
   within `CAL_STALL_WINDOW_MS`. After a short rest the encoder is set
   to 0 there.
2. **Measure travel** (full calibration only): the cart drives right
   to the other end stop. That position is the travel. Joystick mapping
   and soft limits (100 … travel − 100) use it from then on. Then the
   cart returns to the middle.

Start it:

| How | Home only | Home + travel |
|---|---|---|
| Power-up | config tool Start-up tab, then save (default without saved settings: 2) | |
| Terminal key | `h` | `c` |
| Config tool, PID Tuner → Setup | *Home* | *Calibrate travel* |

It runs inside the 10 ms loop, so CAN and the UART keep working.
A START from node 1 during the drive is queued: the game starts when it
has finished. STOP in the config tool (Esc) aborts it.

Self-checks, reported as `$ERR,cal,…`:

| Message | Meaning |
|---|---|
| `count rises while driving left` | motor direction, encoder direction or PWM polarity is wrong: run the open-loop test above |
| `no end stop found` | 8 s without a stall: motor not driving, or the stall threshold is too strict |
| `travel too short` | under 500 counts between the end stops: encoder not counting |

To skip the right-hand drive at power-up: calibrate once, choose *Home
only* in the config tool's Start-up tab, and save. The measured travel is
saved with the other settings.

## Motor direction and polarity test

Do this once before the first reference drive, and whenever the
reference drive reports `count rises while driving left`. Keep a hand
on the motor power switch: never let it push into an end stop for long.

Config tool → PID Tuner → Manual tab → *Open loop motor command*. Start
with the cart near the middle (push it there by hand with the motor off).

| Step | Slider | Watch |
|---|---|---|
| A | u = 0 | motor must be **idle** |
| B | u = +200, briefly | direction, and whether *pos* in the top right rises or falls |
| C | u = +500, briefly | must be **faster** than B |

| Result | Fix in `board.h` |
|---|---|
| A: motor pushes, C slower than B | `MOTOR_PWM_INVERT 1` |
| A: motor pushes, B and C same speed | PWM pin is not the driver's speed input: check `MOTOR_PWM_PIN` against the shield schematic |
| B: cart drives **left** | `MOTOR_DIR_INVERT 1` |
| B: cart drives right, *pos* **falls** | `ENCODER_INVERT 1` |
| B: cart drives right, *pos* rises | correct |

Change one flag, rebuild, flash, repeat until the last row applies.
The pins themselves are already confirmed against the shield schematic
(see the table at the top of `board.h`).

## Before the first run

- Pins are confirmed against the shield schematic.
- Wire the IR output to D2 and the solenoid driver to D3 (see "Pins for
  your own circuits").
- IR polarity: open the config tool's Game I/O tab with a clear beam. It
  must show BEAM CLEAR. If not, select the other "Blocked when pin is"
  level, then put that value into `IR_BLOCKED_LEVEL` in `board.h`
  (*Copy as board.h defines* helps).

## First run

1. Remove the belt or keep a hand near the power switch the first time.
2. Connect the config tool to the Due's programming port at **115200 baud**.
   The baud rate changed from 9600 because of the live plot.
3. Terminal tab: the banner shows `--- Node 2 ---` and
   `reference drive: homing to the left end stop`. The cart should drive
   **left** and stop at the end stop. If it reports `wrong direction`,
   see the table in "Reference drive".
4. PID Tuner, Manual tab, open loop: +u must **increase** the position.
   If the cart moves right but the count falls, set `ENCODER_INVERT` to 1.
5. Press `c` (or *Calibrate travel* in the tool) to measure the travel.
6. Tune: autotune, then step test (see the tool's README).
   *Export pid_gains.h* into this folder. It becomes the boot default.
