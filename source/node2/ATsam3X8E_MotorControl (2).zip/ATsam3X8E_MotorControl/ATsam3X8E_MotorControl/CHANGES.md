# Changes since node2_can.zip (exercise 6)

## main.c

- `BAUDRATE` 9600 → 115200. At 9600 the link carries about 23 telemetry
  lines per second, too few for the live plot. Set 115200 in the
  config tool as well.
- `_Static_assert(LOOP_MS == CTRL_PERIOD_MS)`: the PID runs once per
  loop pass, and its sample time must match the loop period.
- `motor_init()` after `servo_init()`. Both use the PWM controller:
  servo on channel 1, motor on channel 0.
- Reference drive at start-up (non-blocking, see below), then the motor
  stays off until START.
- Joystick x now sets the **cart position** through the PID.
  Joystick y now drives the **servo** (was x).
- Joystick button fires the **solenoid**, only while the game runs.
- START switches the PID on. It first sets the setpoint to the current
  position, so the cart never jumps towards position 0.
- PAUSE holds the cart in place. STOP switches the motor off.
- `game_owns_motor()`: START/STOP from node 1 do not take over while
  the config tool tests the motor.
- `handle_uart()` passes `$` lines to `tuning_feed()` first. The test
  keys g, e, r, s still work. `s` now also prints motor mode and position.
- `tuning_tick()` once per loop: PID, safety stops, telemetry.

## New files

- **board.h** — every exercise 8 pin in one place, with a build warning
  until `BOARD_PINS_VERIFIED` is 1.
- **motor.c/h** — PWM at 20 kHz on the driver's enable pin, direction
  GPIO, encoder on TC2 in quadrature decoder mode (counts both edges of
  both phases, with the input filter), homing against the left end stop,
  joystick-to-position mapping with a margin before each end stop.
  Also implements `motor_hal.h` for `tuning.c`. Time comes from the
  existing `time_now()`, so no second timer is used.
- **solenoid.c/h** — edge-triggered shot, 80 ms pulse, 400 ms cooldown.
  Holding the button cannot keep the coil energised.
- **pid.c/h** — parallel PID. D on the measurement (no kick on setpoint
  steps), low-pass filtered D, anti-windup by conditional integration.
- **tuning.c/h** — config tool protocol. Safety: PC-driven modes stop
  after 1.5 s without the PC, and open loop / relay stop at the soft
  limits.
- **motor_hal.h** — the four functions `tuning.c` needs from the
  hardware.

- **uart.c/h** — replaces the starter's UART. PA8/PA9 at 115200,
  receive and transmit through interrupt ring buffers (256 / 1024 bytes),
  so no byte is lost while the loop is busy and `printf` does not stall
  the control loop. Provides `_write` and the other newlib system calls.
- **systime.c/h** — replaces the starter's `time.*`. SysTick at 1 ms,
  64-bit `time_now()`, `msecs()`, and a fixed-rate `time_doPeriodic()`.
  Renamed from `time.h` to avoid a clash with the C library's `<time.h>`.

## Fix after the first test on hardware

Symptom: readable banner, then binary garbage, then no replies.

Cause: `uart_init()` set `stdout` unbuffered. For unbuffered streams,
newlib's `printf` puts a 1024-byte buffer on the stack for every call.
With Atmel Studio's default stack this overflowed into `.bss`, where the
UART ring buffers sit directly below the stack. The UART then sent stack
contents, and a corrupted return address finally stopped the CPU.

Fixes:
- `stdout` is now line-buffered with a static 128-byte buffer.
- README: set an 8 KB stack in the Atmel Studio linker flags.
- `main.c` paints the stack at boot. The banner and the `s` key report
  stack size and the deepest use so far, with a warning below 4 KB.
- `HardFault_Handler` (in `uart.c`) switches the PWM outputs off and
  prints `!! HardFault` by polling, instead of freezing silently.

## Reference drive (encoder calibration)

- Replaces the blind 1.5 s homing. New mode `TUNE_MODE_CAL` in
  `tuning.c`: drive left until the encoder stalls, zero; optionally
  drive right until it stalls again, store that as the travel, set the
  soft limits, return to the middle. Non-blocking, inside the 10 ms loop.
- Detects a wrong motor/encoder sign, a missing end stop (timeout) and
  an encoder that does not count.
- Start: `MOTOR_HOMING` 1/2 at power-up, keys `h` / `c`, or `$CAL,0/1`
  from the config tool (new buttons in PID Tuner → Setup).
- Joystick mapping uses the measured travel (`tuning_travel()`).
- START during the drive is queued; STOP from the tool aborts it.
- Protocol version 2: `$CAL`, `$CALDONE`, `$TRAVEL`.
- Tested in the simulator: home, full calibration (travel 5600 found
  exactly), inverted motor (stopped after 0.2 s), dead encoder, abort.

## Fix: motor ran at u = 0 (second hardware test)

Symptom: reference drive failed with a direction error, and the motor
kept pushing into the left end stop even after the error.

Cause, checked against the shield schematic (toppkort-A3959-basic v8)
and the A3959 datasheet:
- The motor PWM goes to the A3959 ENABLE input, which is active high.
- On the SAM3X a PWMH output with CPOL = 0 is LOW during the duty cycle.
  Duty 0 therefore meant ENABLE permanently high = full power.
- The servo (PWMH1, same setting) had an inverted pulse as well.
- The encoder counted up while the cart drove left.

Fixes:
- Motor and servo PWM channels use `PWM_CMR_CPOL`: CDTY is the high time.
- `ENCODER_INVERT 1`.
- `motor_init()` runs first in `main()` and drives ENABLE low as a GPIO
  before handing the pin to the PWM. After reset the pin's internal
  pull-up would otherwise hold ENABLE high.
- The HardFault handler drives ENABLE low as a GPIO.
- `board.h`: all pins confirmed against the schematic,
  `BOARD_PINS_VERIFIED 1`. The solenoid relay is not on the shield.

## IR beam on a digital input, solenoid from the config tool

Pins (free on the shield): IR input **D2 = PB25**, solenoid output
**D3 = PC28**. The solenoid moved from the earlier default D8.

- **ir.c/h** (new): pin-change interrupt time-stamps every edge, so a
  ball shorter than one 10 ms loop pass is still counted. A block of at
  least `IR_DEBOUNCE_MS` (5 ms) is a break; shorter ones are glitches.
  After a counted break, breaks are ignored for `IR_HOLDOFF_MS` (1 s).
  A beam already blocked at start-up is not a goal. Hardware debounce
  filter (about 1 ms) on the pin, plus a resync in the loop in case an
  edge is missed. "Stuck" flag after 3 s blocked.
- **main.c**: a counted break while the game runs calls
  `report_goal()` (score, CAN to node 1, `$GOAL` to the tool).
  `solenoid_init()` now runs right after `motor_init()`. New keys
  `f` (fire) and `i` (I/O status).
- **solenoid.c/h**: `solenoid_fire()` for manual shots, run-time timing
  with safe clamps (pulse 10–300 ms, cooldown ≥ 2 × pulse), shot counter.
  The pin's reset pull-up is switched off before the output is enabled.
- **io_link.c/h** (new): `$SOL`, `$SOLCFG`, `$IRCFG`, `$IO`, `$IOCLR`;
  reports `$IO`, `$IREV`, `$GOAL`. Rate-limited: on change at most every
  20 ms, heartbeat every 500 ms, only while the tool is connected.
- **tuning.c/h**: weak hooks `tuning_ext_command()` /
  `tuning_ext_report()` so other modules add commands without touching
  the parser; `tuning_link_active()`. Protocol version 3.
- **uart.c**: the HardFault handler also switches the solenoid off.

Tested on the PC with the real `ir.c` and `solenoid.c`: 3 ms glitch
ignored, 7 ms ball between two loop passes counted, bounce within the
holdoff ignored, chatter at the beam edge counted once, stuck flag,
polarity flip at run time, button held for 2 s gives exactly one 80 ms
pulse, unsafe timing clamped.

## Settings in flash, motor init at power-up, servo locked forward

- **settings.c/h** (new): collects every value the config tool can
  change (PID gains and limit, travel, motor init mode, IR settings,
  solenoid timing, servo position), loads them at power-up, and handles
  `$SAVE`, `$LOAD`, `$NVERASE`, `$NV`, `$SERVO`. Reports `$NV` with an
  *unsaved changes* flag whenever it changes. `$SAVE` is refused during a
  reference drive.
- **nvcfg.c/h** (new): record with magic, version, sequence number and
  CRC-32 in two alternating flash pages; newest valid one wins at load.
- **nvcfg_sam3x.c** (new): writes through the SAM3X ROM programming
  routine (`IROM_ADDR + 8`, EFC1, "erase and write page"), the same
  method as Atmel's EFC driver. Last two pages of bank 1.
- **servo.c/h** (new, moved out of `main.c`): servo locked at a stored
  position in µs. Default 1500 µs = middle of 900–2100. Joystick y no
  longer moves it; STOP and the joystick timeout no longer move it.
- **tuning.c/h**: gains kept as exact integers (micro-units), so saving
  and reloading never drifts. `tuning_get_params()`,
  `tuning_apply_params()`, `tuning_boot_cal()`, `tuning_report()`,
  `$BOOT`. Travel source 0 default / 1 measured / 2 saved, reported in
  `$TRAVEL`. A homing with a saved travel sets the soft limits.
- **main.c**: power-up = defaults → `settings_boot()` → reference drive
  as saved. `settings_tick()` in the loop. `s` key shows the flash state.
- **board.h**: `MOTOR_HOMING` default 2 (full calibration) until a
  saved setting says otherwise.

Tested on the PC with a fake flash: save → reboot restores every value
exactly; unsaved-changes flag; power cut during a save keeps the old
record; bit flip in the newest page falls back to the older one; 1000
saves alternate correctly; erase; unsafe values clamped on load. In the
simulator with a file as flash: power cycle with "home only" uses the
saved travel; simulated re-flash → the config tool restores the settings
and saves them after the reference drive.

## Unchanged

`can.c/h`. `protocol.c` only includes `systime.h` instead of `time.h`.
Node 1 needs no changes.

## Verification

- All files compile for Cortex-M3 with `-Wall -Wextra` against the SAM3X
  CMSIS headers. The only warning is the intended `board.h` reminder.
- The complete project links with Atmel's `startup_sam3xa.c`,
  `system_sam3xa.c` and `sam3x8e_flash.ld`, with newlib-nano (18 KB
  flash) and full newlib (37 KB). No missing symbols.
- `time_doPeriodic()` keeps a fixed 10 ms grid and catches up after an
  overlong pass without skipping one (host test).
- Joystick mapping: x = −90 → 200, 0 → 2800, +90 → 5400 counts.
  Every int8 input stays inside the margins and the mapping is monotonic.
- `pid.c` and `tuning.c` ran against a motor-and-cart simulation with
  the config tool: autotune, step test, link timeout and soft limits.
