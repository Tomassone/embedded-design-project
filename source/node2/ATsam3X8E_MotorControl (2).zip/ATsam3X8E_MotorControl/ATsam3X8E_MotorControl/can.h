
#pragma once

#include <stdint.h>

// ---------------------------------------------------------------------
// Clock feeding the CAN controller.
//
// PMC_PCR.DIV selects it: 0 = MCK, 1 = MCK/2, 2 = MCK/4, 3 = MCK/8.
// MCK is 84 MHz on the Arduino Due.
//
// The two pieces of starter code disagreed about this: the comment in
// can_init() said DIV = 1 (MCK/2), while the example bit timing in this
// header used .brp = F_CPU/2000000-1, which only gives 16 TQ at
// 125 kbit/s if the clock is the full MCK. CAN_BRP in protocol.h is
// derived from CAN_CLK_HZ, so changing CAN_PERIPH_DIV alone keeps the
// bit rate correct -- verify against the SAM3X datasheet which divisor
// the CAN controller requires at 84 MHz.
// ---------------------------------------------------------------------
#define CAN_PERIPH_DIV   0u
#define CAN_CLK_HZ       (84000000u >> CAN_PERIPH_DIV)

// Struct with bit timing information
// See `can_init` for usage example
//
// WARNING: the bitfield order below does NOT match the field positions of
// the SAM3X CAN_BR register. In CAN_BR, PHASE1 sits at bit 4 and PROPAG at
// bit 8 (see sam/sam3x/include/component/component_can.h), but the struct
// allocates `propag` to bits 4..7 and `phase1` to bits 8..11. Writing
// `.phase1 = x` therefore lands in the PROPAG field and vice versa.
//
// Because the two segments are simply swapped, the TOTAL number of time
// quanta per bit is unaffected, so the bit rate still comes out right --
// only the sample point moves. That is exactly what has to match between
// the nodes, so this file builds CAN_BR through the official CAN_BR_*
// macros and passes it in `.reg` instead. Do not use the named fields.
typedef struct CanInit CanInit;
__attribute__((packed)) struct CanInit {
    union {
        struct {
            uint32_t phase2:4;  // Phase 2 segment
            uint32_t propag:4;  // Propagation time segment   (lands on PHASE1)
            uint32_t phase1:4;  // Phase 1 segment            (lands on PROPAG)
            uint32_t sjw:4;     // Synchronization jump width
            uint32_t brp:8;     // Baud rate prescaler
            uint32_t smp:8;     // Sampling mode
        };
        uint32_t reg;
    };
};


// Initialize CAN bus, with bit timings and optional interrupt
// If `rxInterrupt` is not 0, an interrupt will be triggered when a message is received.
// (See can.c for an example interrupt handler)
//
// Prefer can_init_default() in protocol.h, which fills in the bit timing
// that matches node 1.
void can_init(CanInit init, uint8_t rxInterrupt);


// Strict-aliasing-safe reinterpret-cast
#define union_cast(type, x) \
    (((union { \
        typeof(x) a; \
        type b; \
    })x).b)


// Dummy type for use with `union_cast`, see below
typedef struct Byte8 Byte8;
struct Byte8 {
    uint8_t bytes[8];
};


// CAN message data type
// Data fields have 3 access methods (via union):
//  8 bytes
//  2 double words (32-bit ints)
//  1 Byte8 dummy struct
// The dummy struct allows for convenient construction of a CAN message from another type
//
// NOTE: `id` is uint16_t, not uint8_t as in the original starter code. A
// standard CAN identifier is 11 bits wide, so IDs above 0xFF are perfectly
// legal and the protocol with node 1 uses 0x100..0x201. With a uint8_t
// field those IDs silently truncate: 0x100 becomes 0x00 and 0x101 becomes
// 0x01, which is why nothing is received at the other end.
//
// Example:
//    typedef struct {
//        uint16_t  a;
//        uint8_t   b;
//        float     c;
//    } __attribute__((packed)) YourStruct ;
//
//    CanMsg m = (CanMsg){
//        .id = 1,
//        .length = sizeof(YourStruct),
//        .byte8 = union_cast(Byte8, ((YourStruct){
//            .a = 10,
//            .b = 20,
//            .c = -30.0,
//        })),
//    };
//    can_printmsg(m);
//    // Should print: CanMsg(id:1, length:7, data:{10, 0, 20, 0, 0, 240, 193})
typedef struct CanMsg CanMsg;
struct CanMsg {
    uint16_t id;                // 11-bit standard identifier, 0x000..0x7FF
    uint8_t length;
    union {
        uint8_t     byte[8];
        uint32_t    dword[2];
        Byte8       byte8;
    };
};

// Send a CAN message on the bus.
// Blocks if the bus does not receive the message (typically because one of the
// receiving nodes has not cleared a buffer)
void can_tx(CanMsg m);

// Non-blocking send. Returns 0 if the message was handed to the mailbox,
// 1 if the mailbox is still busy with the previous one.
//
// Use this for anything sent periodically. Joystick positions and status
// are state, not a queue of events: if the previous frame has not got out
// yet, the newer one supersedes it and blocking would stall the loop.
uint8_t can_tx_try(CanMsg m);

// Receive a CAN message.
// Does not block. Returns 0 if there is no message, 1 otherwise
uint8_t can_rx(CanMsg* m);

// Error state of the controller. In normal mode a node alone on the bus
// gets no acknowledge, so tx_errors climbs with every attempt -- this is
// the first thing to look at when nothing gets through.
typedef struct CanErrors CanErrors;
struct CanErrors {
    uint8_t tx_errors;          // TEC
    uint8_t rx_errors;          // REC
    uint8_t error_passive;      // a counter passed 127
    uint8_t bus_off;            // TEC passed 255, node has left the bus
};

// Read the error counters and flags.
void can_get_errors(CanErrors* e);

// Print a CAN message (using `printf`)
void can_printmsg(CanMsg m);
