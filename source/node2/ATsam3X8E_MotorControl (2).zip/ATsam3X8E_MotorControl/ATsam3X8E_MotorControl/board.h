#pragma once
// ---------------------------------------------------------------------
// board.h -- every exercise 8 pin and constant in one place
//
// Pins checked against the shield schematic "toppkort-A3959-basic v8":
//
//   Shield signal        A3959 pin   Due pin       SAM3X
//   ENABLE/PWM           9           D20 / SDA     PB12 = PWMH0
//   PHASE/DIR            4           D7            PC23
//   QUAD_A               encoder 3   D5            PC25 = TIOA6
//   QUAD_B               encoder 1   D4            PC26 = TIOB6
//   SERVO_PWM            servo 1     D21 / SCL     PB13 = PWMH1
//
// Your own circuits, on pins the shield does not use:
//
//   IR beam (digital)    input       D2            PB25
//   Solenoid driver      output      D3            PC28
//
// Both are 3.3 V pins and NOT 5 V tolerant.
// ---------------------------------------------------------------------

#define BOARD_PINS_VERIFIED   1

#if !BOARD_PINS_VERIFIED
#warning "board.h: exercise 8 pins not verified against the shield schematic"
#endif

// ---- Motor driver A3959: PWM on ENABLE, direction on PHASE -----------
//
// ENABLE is active high (A3959 datasheet): high = motor driven,
// low = outputs chopped (off, fast decay because EXT_MODE is tied low).
// PWM channel 0 on PB12 = PWMH0. The servo uses channel 1.
#define MOTOR_PWM_PIO         PIOB
#define MOTOR_PWM_PIN         PIO_PB12B_PWMH0
#define MOTOR_PWM_PERIPH_B    1           // 1 = peripheral B, 0 = A
#define MOTOR_PWM_CHANNEL     0
#define MOTOR_PWM_FREQ_HZ     20000u      // above hearing, typical for H-bridges

#define MOTOR_DIR_PIO         PIOC
#define MOTOR_DIR_PIO_ID      ID_PIOC
#define MOTOR_DIR_PIN         PIO_PC23

// Direction: with u > 0 the cart must drive RIGHT.
// If it drives left, set 1.
#define MOTOR_DIR_INVERT      0

// PWM polarity, normally 0: motor.c already accounts for the SAM3X PWMH
// output being LOW during the duty cycle when CPOL = 0. Only set 1 if the
// motor pushes at u = 0 and gets SLOWER at a larger |u|.
#define MOTOR_PWM_INVERT      0

// ---- Encoder: TC2 channel 0 in quadrature decoder mode ---------------
//
// QUAD_A on PC25 = TIOA6 (D5), QUAD_B on PC26 = TIOB6 (D4).
#define ENCODER_PIO           PIOC
#define ENCODER_PIO_ID        ID_PIOC
#define ENCODER_PIN_A         PIO_PC25B_TIOA6
#define ENCODER_PIN_B         PIO_PC26B_TIOB6
// Count direction: driving RIGHT must INCREASE the position.
// 1 on your board: the count rose while the cart drove left.
#define ENCODER_INVERT        1

// ---- IR beam: digital input from your comparator / op-amp ------------
//
// D2 = PB25. The signal must stay between 0 and 3.3 V.
#define IR_PIO                PIOB
#define IR_PIO_ID             ID_PIOB
#define IR_PIN                PIO_PB25
#define IR_IRQn               PIOB_IRQn
#define IR_IRQ_HANDLER        PIOB_Handler      // no other PIOB interrupt in use

// Pin level that means "beam interrupted". 0: the signal drops when the
// ball blocks the light. Check in the config tool (Game I/O tab): with a
// clear beam it must show "clear". The tool can flip it at run time.
#define IR_BLOCKED_LEVEL      0
#define IR_PULLUP             0                 // 1 for an open-collector output

#define IR_DEBOUNCE_MS        5                 // shorter blocks are glitches
#define IR_HOLDOFF_MS         1000              // minimum time between two goals
#define IR_REARM_MS           500               // beam clear this long before the next goal
#define IR_STUCK_MS           3000              // blocked this long = report "stuck"

// ---- Solenoid driver --------------------------------------------------
//
// D3 = PC28. Drive a logic-level MOSFET or transistor, never the coil
// directly, and put a flyback diode across the coil.
#define SOLENOID_PIO          PIOC
#define SOLENOID_PIO_ID       ID_PIOC
#define SOLENOID_PIN          PIO_PC28
#define SOLENOID_ACTIVE_HIGH  1                 // 1: pin high = coil on
#define SOLENOID_PULSE_MS     80                // how long the plunger is driven
#define SOLENOID_COOLDOWN_MS  400               // minimum time between shots
#define SOLENOID_MAX_ON_MS    500               // hard limit: pin forced off after this

// ---- Cart travel and reference drive ---------------------------------
//
// Travel in encoder counts from the left to the right end stop. Only a
// default: a full calibration ('c' key, or "Calibrate travel" in the
// config tool) measures the real value at run time.
#define MOTOR_TRAVEL_COUNTS   5600
#define MOTOR_MARGIN_COUNTS   200         // joystick setpoints keep off the end stops

// Reference drive at power-up (default until a saved setting from the
// config tool overrides it, see settings.c):
//   0 = none (encoder starts at 0 wherever the cart is)
//   1 = home: drive to the left end stop, zero the encoder there.
//       Uses the stored travel, if one was saved.
//   2 = full calibration: home, then measure the travel to the right end
#define MOTOR_HOMING          2

// Reference drive tuning. The end stop is detected when the encoder
// moves less than CAL_STALL_COUNTS within CAL_STALL_WINDOW_MS.
#define CAL_U                 300         // permille: slow, gentle on the end stops
#define CAL_STALL_WINDOW_MS   150
#define CAL_STALL_COUNTS      4
#define CAL_TIMEOUT_MS        8000        // per direction