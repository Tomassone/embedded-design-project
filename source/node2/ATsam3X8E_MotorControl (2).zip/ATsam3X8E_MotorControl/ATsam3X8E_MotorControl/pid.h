// pid.h -- discrete PID controller for the node 2 motor (exercise 8)
//
// Parallel form:  u = Kp*e + Ki*integral(e) + Kd*d/dt(-y)
//
// - Derivative acts on the measurement, not on the error.
//   A setpoint step therefore causes no derivative kick.
// - The derivative is low-pass filtered with time constant tf.
// - Anti-windup by conditional integration (clamping).
// - The integrator stores Ki*integral(e), not integral(e).
//   Changing Ki at runtime therefore causes no output bump.
//
// Units used in this project:
//   e, y      encoder counts
//   u         permille of full motor command, -1000 .. +1000
//   Kp        permille / count
//   Ki        permille / (count * s)
//   Kd        permille * s / count

#ifndef PID_H
#define PID_H

#include <stdbool.h>

typedef struct
{
    // Parameters
    float kp;
    float ki;
    float kd;
    float tf;           // derivative filter time constant [s], 0 = no filter
    float u_max;        // output limit, symmetric: -u_max .. +u_max
    float dt;           // sample time [s]

    // State
    float integ;        // Ki * integral(e)
    float deriv;        // filtered derivative term
    float prev_y;
    bool  first;

    // Last computed terms, for telemetry only
    float p_term;
    float i_term;
    float d_term;
    float u;
} pid_ctrl_t;

void  pid_init(pid_ctrl_t *c, float dt, float u_max);
void  pid_set_gains(pid_ctrl_t *c, float kp, float ki, float kd, float tf);
void  pid_reset(pid_ctrl_t *c);
float pid_update(pid_ctrl_t *c, float setpoint, float measurement);

#endif
