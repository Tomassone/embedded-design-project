#pragma once

#include <stdint.h>
#include "can.h"

// ---------------------------------------------------------------------
// Application protocol for the CAN bus between node 1 (ATmega162 +
// MCP2515) and node 2 (SAM3X8E).
//
// CAN has no addressing: every node receives every frame and decides by
// the identifier whether it is interested. The ID therefore names the
// MESSAGE TYPE, not a recipient.
//
// The ID also sets the priority: on simultaneous transmission the LOWER
// ID wins arbitration. Hence the ordering below -- control messages that
// steer the servo outrank status reports.
//
// This table must stay identical to protocol.h on node 1. It and the bit
// timing are the only two things the two nodes have to agree on.
// ---------------------------------------------------------------------

// --- Node 1 -> Node 2 ---
#define CAN_ID_JOYSTICK     0x100   // 3 bytes: x, y, buttons
#define CAN_ID_GAME_CMD     0x101   // 1 byte: game_cmd_t

// --- Node 2 -> Node 1 ---
#define CAN_ID_GOAL         0x200   // 1 byte: new score
#define CAN_ID_NODE2_STATUS 0x201   // 1 byte: node2_status_t

// Commands from node 1. Deliberately explicit rather than a bare flag,
// so a lost frame cannot leave the two nodes in opposite states.
//
// GAME_CMD_START is also sent when node 1 resumes from pause, so it has
// to be idempotent here: it must not restart the round or reset the
// score.
typedef enum {
    GAME_CMD_STOP  = 0,
    GAME_CMD_START = 1,
    GAME_CMD_PAUSE = 2
} game_cmd_t;

typedef enum {
    NODE2_IDLE    = 0,
    NODE2_RUNNING = 1,
    NODE2_ERROR   = 2
} node2_status_t;

// Bits in the joystick payload's third byte.
#define JOY_BTN_B1  0x01

// ---------------------------------------------------------------------
// Bit timing, derived rather than written as a magic number so that
// changing one constant cannot silently break the match with node 1.
//
// One bit = 16 time quanta (TQ):
//   SyncSeg 1 + PropSeg 2 + PhaseSeg1 7 + PhaseSeg2 6
//   Sample point after 10 of 16 TQ = 62.5 %
//
//   TQ       = (BRP + 1) / CAN_CLK_HZ = 42 / 84 MHz = 0.5 us
//   Bit time = 16 * 0.5 us = 8 us  ->  125 kbit/s
//
// The register fields store (value - 1), hence PHASE1 = 6 for 7 TQ.
//
// Node 1 reaches the same numbers through the MCP2515's CNF registers
// (CNF1 = 0x03, CNF2 = 0xB1, CNF3 = 0x05 at 16 MHz). Matching the bit
// RATE is not enough -- the segment counts have to match too, or the two
// nodes sample at different points in the bit and long cables start
// producing errors.
// ---------------------------------------------------------------------
#define CAN_BITRATE      125000u
#define CAN_TQ_PER_BIT   16u
#define CAN_BRP          ((CAN_CLK_HZ / (CAN_TQ_PER_BIT * CAN_BITRATE)) - 1u)

_Static_assert(CAN_CLK_HZ % (CAN_TQ_PER_BIT * CAN_BITRATE) == 0,
               "CAN clock does not divide evenly into 16 TQ per bit");

// Initialises the CAN controller with that timing.
// rxInterrupt is passed through to can_init(); main.c polls, so 0.
void can_init_default(uint8_t rxInterrupt);

// --- Receiving ---

// Latest joystick state from node 1.
typedef struct {
    int8_t  x;              // -90..+90, 0 = centred
    int8_t  y;              // -90..+90, 0 = centred
    uint8_t buttons;        // JOY_BTN_B1
    uint8_t valid;          // 0 until the first frame, and after a timeout
} joystick_rx_t;

// Drains every pending CAN message and updates the state below.
// Returns the number of messages handled. Call once per loop pass.
uint8_t protocol_poll(void);

// Marks the joystick stale if nothing has arrived for timeout_ms.
// Returns 1 the moment it goes stale, so the caller can fail safe.
uint8_t protocol_check_timeout(uint32_t timeout_ms);

const joystick_rx_t *protocol_joystick(void);

// The command last received from node 1.
game_cmd_t protocol_game_cmd(void);

// 1 if a new command arrived since the last call, and clears the flag.
uint8_t protocol_cmd_changed(void);

// --- Sending ---

// Reports a goal. score is the new running total.
uint8_t protocol_send_goal(uint8_t score);

// Reports this node's state.
uint8_t protocol_send_status(node2_status_t status);
