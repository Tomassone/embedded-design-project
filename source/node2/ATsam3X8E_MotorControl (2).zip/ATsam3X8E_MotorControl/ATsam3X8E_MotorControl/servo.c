#include "servo.h"

#ifndef HOST_TEST
#include "sam.h"
#endif

// The SAM3X PWM channel counter is only 16 bits wide (CPRD/CDTY max
// 65535), even though the CMSIS header masks show 24 bits. At MCK
// (84 MHz) a 20 ms period would be 1 680 000 ticks: it does not fit, and
// the truncated values give duty > period, i.e. no pulses at all.
//
// So the servo channel uses MCK / 32 = 2.625 MHz:
//   20 ms period = 52 500 ticks (fits), 1 us = 2.625 ticks (0.38 us steps).
#define PWM_CLK_HZ      (84000000u / 32u)                   // 2 625 000
#define SERVO_PERIOD    (PWM_CLK_HZ / 50u)                  // 52 500 = 20 ms

_Static_assert(SERVO_PERIOD <= 0xFFFFu, "servo period must fit the 16-bit PWM counter");

#ifndef HOST_TEST
// Microseconds -> PWM ticks, rounded: us * 2.625 = us * 21 / 8.
static uint32_t us_to_ticks(uint16_t us)
{
	return ((uint32_t)us * 21u + 4u) / 8u;
}
#endif

static uint16_t servo_us = SERVO_US_CENTRE;


void servo_init(void)
{
	#ifndef HOST_TEST
	PMC->PMC_PCER0 = (1u << ID_PIOB);           // PIOB clock
	PMC->PMC_PCER1 = (1u << (ID_PWM - 32));     // PWM clock

	PIOB->PIO_PDR   = PIO_PB13;                 // release GPIO control
	PIOB->PIO_ABSR |= PIO_PB13;                 // peripheral B (PWMH1)

	PWM->PWM_DIS = (1u << 1);                   // channel 1 off while configuring

	// CPOL = 1: the pulse is HIGH for CDTY. With CPOL = 0 a PWMH output is
	// low during CDTY, which inverts the servo pulse.
	PWM->PWM_CH_NUM[1].PWM_CMR  = PWM_CMR_CPRE_MCK_DIV_32 | PWM_CMR_CPOL;
	PWM->PWM_CH_NUM[1].PWM_CPRD = SERVO_PERIOD;
	PWM->PWM_CH_NUM[1].PWM_CDTY = us_to_ticks(SERVO_US_CENTRE);

	PWM->PWM_ENA = (1u << 1);                   // enable channel 1
	#endif
	servo_us = SERVO_US_CENTRE;
}


void servo_set_us(uint16_t us)
{
	if (us < SERVO_US_MIN) us = SERVO_US_MIN;
	if (us > SERVO_US_MAX) us = SERVO_US_MAX;
	servo_us = us;

	#ifndef HOST_TEST
	// CDTYUPD: takes effect at the next period, no glitched pulse.
	PWM->PWM_CH_NUM[1].PWM_CDTYUPD = us_to_ticks(us);
	#endif
}


uint16_t servo_get_us(void)
{
	return servo_us;
}