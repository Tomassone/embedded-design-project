#pragma once
#include <stdint.h>

// ---------------------------------------------------------------------
// servo.h -- servo on PB13 (D21), PWM channel 1, 50 Hz
//
// The servo is locked in one position (forward). The pulse width is set
// in microseconds: 900 = one end, 1500 = middle of the range, 2100 =
// other end. The forward position is a stored setting (settings.c), so a
// horn that is not mounted exactly straight can be trimmed from the
// config tool.
// ---------------------------------------------------------------------

#define SERVO_US_MIN      900
#define SERVO_US_MAX      2100
#define SERVO_US_CENTRE   1500      // half of the range: (900 + 2100) / 2

void     servo_init(void);          // starts at SERVO_US_CENTRE

// Sets the pulse width, clamped to SERVO_US_MIN .. SERVO_US_MAX.
void     servo_set_us(uint16_t us);
uint16_t servo_get_us(void);
