#include <stddef.h>
#include <string.h>
#include "nvcfg.h"

#define NV_MAGIC    0x4E475942u     // "BYGN"

typedef struct
{
	uint32_t magic;
	uint16_t version;
	uint16_t len;
	uint32_t seq;
	uint8_t  data[NVCFG_PAYLOAD_MAX];
	uint32_t crc;                   // over everything above
} nv_record_t;

_Static_assert(sizeof(nv_record_t) <= NVCFG_PAGE_SIZE, "record larger than one flash page");
_Static_assert(offsetof(nv_record_t, crc) % 4 == 0, "crc must be word aligned");

static uint32_t newest_seq;         // 0 = none
static int8_t   newest_page = -1;   // -1 = none


static uint32_t crc32(const void *p, uint32_t n)
{
	const uint8_t *b = p;
	uint32_t crc = 0xFFFFFFFFu;

	while (n--)
	{
		crc ^= *b++;
		for (int k = 0; k < 8; k++)
		crc = (crc >> 1) ^ (0xEDB88320u & (uint32_t)-(int32_t)(crc & 1u));
	}
	return ~crc;
}


// Copies a page and checks it. Returns 1 if it holds a valid record.
static int read_page(uint8_t idx, nv_record_t *r)
{
	memcpy(r, nvcfg_hal_page(idx), sizeof *r);

	if (r->magic != NV_MAGIC || r->len > NVCFG_PAYLOAD_MAX || r->seq == 0)
	return 0;
	return r->crc == crc32(r, offsetof(nv_record_t, crc));
}


// Finds the newest valid page. Sequence numbers are compared with
// wrap-around, so the order survives the 32-bit overflow.
static int8_t scan(nv_record_t *best)
{
	nv_record_t r;
	int8_t      found = -1;

	for (uint8_t i = 0; i < 2; i++)
	{
		if (!read_page(i, &r))
		continue;
		if (found < 0 || (int32_t)(r.seq - best->seq) > 0)
		{
			*best = r;
			found = (int8_t)i;
		}
	}

	newest_page = found;
	newest_seq  = (found >= 0) ? best->seq : 0;
	return found;
}


nvcfg_result_t nvcfg_load(uint16_t version, void *data, uint16_t len)
{
	nv_record_t r;

	if (scan(&r) < 0)
	return NVCFG_EMPTY;
	if (r.version != version || r.len != len)
	return NVCFG_EMPTY;         // layout changed: use the defaults

	memcpy(data, r.data, len);
	return NVCFG_OK;
}


static nvcfg_result_t write_record(uint8_t idx, const nv_record_t *r)
{
	uint32_t page[NVCFG_PAGE_SIZE / 4];

	memset(page, 0xFF, sizeof page);
	memcpy(page, r, sizeof *r);

	if (nvcfg_hal_write(idx, page) != 0)
	return NVCFG_ERR_FLASH;
	if (memcmp(nvcfg_hal_page(idx), page, NVCFG_PAGE_SIZE) != 0)
	return NVCFG_ERR_VERIFY;
	return NVCFG_OK;
}


nvcfg_result_t nvcfg_save(uint16_t version, const void *data, uint16_t len)
{
	if (len > NVCFG_PAYLOAD_MAX)
	return NVCFG_ERR_SIZE;

	nv_record_t cur;
	scan(&cur);

	nv_record_t r;
	memset(&r, 0, sizeof r);
	r.magic   = NV_MAGIC;
	r.version = version;
	r.len     = len;
	r.seq     = newest_seq + 1;
	if (r.seq == 0)
	r.seq = 1;
	memcpy(r.data, data, len);
	r.crc = crc32(&r, offsetof(nv_record_t, crc));

	// Write to the page that does not hold the newest record.
	uint8_t target = (newest_page == 0) ? 1 : 0;

	nvcfg_result_t res = write_record(target, &r);
	if (res == NVCFG_OK)
	{
		newest_page = (int8_t)target;
		newest_seq  = r.seq;
	}
	return res;
}


nvcfg_result_t nvcfg_erase(void)
{
	uint32_t blank[NVCFG_PAGE_SIZE / 4];
	memset(blank, 0xFF, sizeof blank);

	for (uint8_t i = 0; i < 2; i++)
	if (nvcfg_hal_write(i, blank) != 0)
	return NVCFG_ERR_FLASH;

	newest_page = -1;
	newest_seq  = 0;
	return NVCFG_OK;
}


uint32_t nvcfg_seq(void)
{
	return newest_seq;
}


const char *nvcfg_result_text(nvcfg_result_t r)
{
	switch (r)
	{
		case NVCFG_OK:         return "ok";
		case NVCFG_EMPTY:      return "nothing stored";
		case NVCFG_ERR_SIZE:   return "record too large";
		case NVCFG_ERR_FLASH:  return "flash controller error (region locked?)";
		case NVCFG_ERR_VERIFY: return "read-back mismatch";
	}
	return "?";
}