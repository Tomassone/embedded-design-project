#pragma once
#include <stdint.h>

// ---------------------------------------------------------------------
// uart.h -- SAM3X8E UART on PA8 (URXD) / PA9 (UTXD)
//
// On the Arduino Due these two pins go to the ATmega16U2, which turns
// them into the USB "programming port" (COMx on Windows).
//
// Receive and transmit are interrupt driven through ring buffers:
//   - bytes arriving while main() is busy are not lost
//   - printf() returns immediately unless the TX buffer is full
//
// printf() is routed here through newlib's _write().
// ---------------------------------------------------------------------

// cpufreq: MCK in Hz (84 MHz after SystemInit). 8N1, no flow control.
void uart_init(uint32_t cpufreq, uint32_t baudrate);

// 1 and the byte in *c if one was waiting, 0 if the buffer is empty.
uint8_t uart_rx(uint8_t *c);

// Queues one byte. Waits only if the TX buffer is full.
void uart_tx(uint8_t c);

// Waits until everything queued has left the shift register.
void uart_flush(void);

// Sends a string by polling, without interrupts or the ring buffer.
// For fault handlers only: slow, and it bypasses printf's buffer.
void uart_puts_blocking(const char *s);
