#pragma once
#include <stdint.h>

// ---------------------------------------------------------------------
// ir.h -- IR beam (goal detection) on a digital input
//
// The comparator / op-amp output of your IR circuit goes to IR_PIN
// (board.h). A pin-change interrupt time-stamps every edge, so a ball
// that crosses the beam faster than one 10 ms loop pass is not missed.
//
// A beam BREAK counts when the beam stays blocked for at least
// debounce_ms. Shorter blocks are counted as glitches and ignored.
// After a counted break the detector is disarmed. It re-arms only when
// the beam has been clear WITHOUT interruption for IR_REARM_MS, and at
// least holdoff_ms after the goal. A ball resting or bouncing in the
// beam, even with a flickering signal, is one goal.
// ---------------------------------------------------------------------

void     ir_init(void);

// Call once per loop pass. Returns 1 once per counted beam break.
uint8_t  ir_update(void);

uint8_t  ir_raw(void);          // pin level, 0 or 1
uint8_t  ir_blocked(void);      // 1 = beam interrupted (polarity applied)
uint8_t  ir_stuck(void);        // 1 = blocked for longer than IR_STUCK_MS

uint32_t ir_breaks(void);       // counted breaks since start / ir_clear()
uint32_t ir_glitches(void);     // blocks shorter than debounce_ms
uint32_t ir_suppressed(void);   // valid breaks ignored: beam not cleared yet
void     ir_clear(void);

// A break has ended. Gives its length and kind once:
//   kind 1 = counted break, 2 = ignored (beam not re-armed).
// Returns 0 if nothing new has finished.
uint8_t  ir_take_finished(uint32_t *dur_ms, uint8_t *kind);

// Runtime settings (defaults from board.h). blocked_level: pin level
// that means "beam interrupted".
void     ir_set_config(uint16_t debounce_ms, uint16_t holdoff_ms, uint8_t blocked_level);
void     ir_get_config(uint16_t *debounce_ms, uint16_t *holdoff_ms, uint8_t *blocked_level);

// ---- Logic core, hardware-free (used by the ISR, testable on a PC) ----
void     ir_edge(uint8_t raw_level, uint32_t now_ms);   // on every pin change
uint8_t  ir_poll(uint32_t now_ms);                      // ir_update() body
void     ir_reset_logic(uint8_t raw_level, uint32_t now_ms);