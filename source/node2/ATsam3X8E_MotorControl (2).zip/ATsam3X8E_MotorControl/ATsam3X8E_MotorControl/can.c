
#include "sam.h"
#include "can.h"
#include <stdio.h>

// ---------------------------------------------------------------------
// Mailbox allocation.
//
// The SAM3X CAN controller has 8 mailboxes, each of which holds exactly
// one message. Three are used here:
//
//   0  transmit
//   1  receive, joystick only, overwrite mode
//   2  receive, everything else, discard mode
//
// The split matters because the two kinds of traffic want opposite
// behaviour when a message arrives before the previous one was read:
//
//   Joystick position is STATE. The newest value is the only one worth
//   having, so mailbox 1 overwrites.
//
//   A game command is an EVENT. Losing a STOP would leave the servo
//   running, so mailbox 2 discards the new message and keeps the one
//   already waiting, which the main loop is about to read anyway.
//
// A received message goes to the LOWEST-numbered mailbox whose
// acceptance filter matches, so joystick frames land in 1 and never
// reach 2.
// ---------------------------------------------------------------------
#define txMailbox   0
#define rxJoystick  1
#define rxOther     2

// Identifier that mailbox 1 filters on. Kept as a literal rather than
// including protocol.h, so can.c stays a pure driver.
#define RX_JOYSTICK_ID  0x100


void can_printmsg(CanMsg m){
    printf("CanMsg(id:%d, length:%d, data:{", m.id, m.length);
    if(m.length){
        printf("%d", m.byte[0]);
    }
    for(uint8_t i = 1; i < m.length; i++){
        printf(", %d", m.byte[i]);
    }
    printf("})\n");
}


void can_init(CanInit init, uint8_t rxInterrupt){
    // Disable CAN
    CAN0->CAN_MR &= ~CAN_MR_CANEN;

    // Clear status register by reading it
    __attribute__((unused)) uint32_t ul_status = CAN0->CAN_SR;

    // Disable PIO interrupts on the CAN pins.
    // (The original starter code named PA8/PA9 here, which are the UART
    //  pins, not the CAN pins.)
    PIOA->PIO_IDR = PIO_PA1A_CANRX0 | PIO_PA0A_CANTX0;

    // Select CAN0 RX and TX in PIOA: peripheral A on PA1 and PA0
    PIOA->PIO_ABSR &= ~(PIO_PA1A_CANRX0 | PIO_PA0A_CANTX0);

    // Disable the Parallel IO (PIO) of the Rx and Tx pins so that the peripheral controller can use them
    PIOA->PIO_PDR = PIO_PA1A_CANRX0 | PIO_PA0A_CANTX0;

    // Enable pull up on the CAN pins
    PIOA->PIO_PUER = (PIO_PA1A_CANRX0 | PIO_PA0A_CANTX0);

    // Enable the clock for CAN0 in the PMC.
    // DIV selects the peripheral clock: 0 = MCK, 1 = MCK/2, 2 = MCK/4,
    // 3 = MCK/8. It must agree with CAN_PERIPH_DIV in protocol.h, which
    // is where the baud rate prescaler is computed from it.
    PMC->PMC_PCR = PMC_PCR_EN
                 | (CAN_PERIPH_DIV << PMC_PCR_DIV_Pos)
                 | PMC_PCR_CMD
                 | (ID_CAN0 << PMC_PCR_PID_Pos);
    PMC->PMC_PCER1 |= 1 << (ID_CAN0 - 32);

    // Set baudrate, Phase1, phase2 and propagation delay for can bus. Must match on all nodes!
    CAN0->CAN_BR = init.reg;

    // --- Mailbox 0: transmit ---
    // MIDE stays CLEARED. MIDE = 1 selects the 29-bit extended
    // identifier of CAN 2.0B; node 1 sends and expects 11-bit standard
    // identifiers, so the two must agree here.
    CAN0->CAN_MB[txMailbox].CAN_MID = 0;
    CAN0->CAN_MB[txMailbox].CAN_MMR = CAN_MMR_MOT_MB_TX;

    // --- Mailbox 1: joystick, newest wins ---
    // A full 11-bit mask means only this one identifier is accepted.
    // MAM.MIDE set + MID.MIDE clear = standard frames only.
    CAN0->CAN_MB[rxJoystick].CAN_MAM = CAN_MAM_MIDvA_Msk | CAN_MAM_MIDE;
    CAN0->CAN_MB[rxJoystick].CAN_MID = CAN_MID_MIDvA(RX_JOYSTICK_ID);
    CAN0->CAN_MB[rxJoystick].CAN_MMR = CAN_MMR_MOT_MB_RX_OVERWRITE;
    CAN0->CAN_MB[rxJoystick].CAN_MCR = CAN_MCR_MTCR;

    // --- Mailbox 2: everything else, oldest wins ---
    // Mask 0 = every bit is "don't care", so this accepts any
    // identifier, standard or extended.
    CAN0->CAN_MB[rxOther].CAN_MAM = 0;
    CAN0->CAN_MB[rxOther].CAN_MID = 0;
    CAN0->CAN_MB[rxOther].CAN_MMR = CAN_MMR_MOT_MB_RX;
    CAN0->CAN_MB[rxOther].CAN_MCR = CAN_MCR_MTCR;

    if(rxInterrupt){
        // Enable interrupt on reception in either receive mailbox
        CAN0->CAN_IER |= (1 << rxJoystick) | (1 << rxOther);
        // Enable interrupt in NVIC
        NVIC_EnableIRQ(ID_CAN0);
    }

    // Enable CAN
    CAN0->CAN_MR |= CAN_MR_CANEN;

    // The controller needs to see 11 recessive bits before it joins the
    // bus. Bounded wait: if the bus is held dominant by a wiring fault
    // this must not hang.
    for(uint32_t i = 0; i < 100000u && !(CAN0->CAN_SR & CAN_SR_WAKEUP); i++){
        __asm__ volatile ("nop");
    }
}


// Loads a message into the transmit mailbox. The caller has already
// checked that the mailbox is free.
static void tx_load(CanMsg m){
    // Set message ID. MIDE cleared = 11-bit standard identifier.
    CAN0->CAN_MB[txMailbox].CAN_MID = CAN_MID_MIDvA(m.id & 0x7FF);

    // Coerce maximum 8 byte length
    m.length = m.length > 8 ? 8 : m.length;

    //  Put message in can data registers
    CAN0->CAN_MB[txMailbox].CAN_MDL = m.dword[0];
    CAN0->CAN_MB[txMailbox].CAN_MDH = m.dword[1];

    // Set message length and mailbox ready to send
    CAN0->CAN_MB[txMailbox].CAN_MCR = (m.length << CAN_MCR_MDLC_Pos) | CAN_MCR_MTCR;
}


void can_tx(CanMsg m){
    while(!(CAN0->CAN_MB[txMailbox].CAN_MSR & CAN_MSR_MRDY)){}
    tx_load(m);
}


uint8_t can_tx_try(CanMsg m){
    if(!(CAN0->CAN_MB[txMailbox].CAN_MSR & CAN_MSR_MRDY)){
        return 1;               // still busy with the previous message
    }
    tx_load(m);
    return 0;
}


// Reads one receive mailbox into m and re-arms it.
static void rx_read(uint8_t mb, CanMsg* m){
    // Get message ID. MIDvA is the 11-bit standard identifier field.
    m->id = (uint16_t)((CAN0->CAN_MB[mb].CAN_MID & CAN_MID_MIDvA_Msk) >> CAN_MID_MIDvA_Pos);

    // Get data length
    m->length = (uint8_t)((CAN0->CAN_MB[mb].CAN_MSR & CAN_MSR_MDLC_Msk) >> CAN_MSR_MDLC_Pos);
    if(m->length > 8){
        m->length = 8;
    }

    // Get data from CAN mailbox
    m->dword[0] = CAN0->CAN_MB[mb].CAN_MDL;
    m->dword[1] = CAN0->CAN_MB[mb].CAN_MDH;

    // Re-arm for the next message. MTCR on a reception mailbox means
    // "data read, ready for the next frame".
    CAN0->CAN_MB[mb].CAN_MCR = CAN_MCR_MTCR;
}


uint8_t can_rx(CanMsg* m){
    // Joystick mailbox first: it carries the freshest control input.
    if(CAN0->CAN_MB[rxJoystick].CAN_MSR & CAN_MSR_MRDY){
        rx_read(rxJoystick, m);
        return 1;
    }

    if(CAN0->CAN_MB[rxOther].CAN_MSR & CAN_MSR_MRDY){
        rx_read(rxOther, m);
        return 1;
    }

    return 0;
}


void can_get_errors(CanErrors* e){
    uint32_t ecr = CAN0->CAN_ECR;
    uint32_t sr  = CAN0->CAN_SR;

    e->rx_errors     = (uint8_t)((ecr & CAN_ECR_REC_Msk) >> CAN_ECR_REC_Pos);
    e->tx_errors     = (uint8_t)((ecr & CAN_ECR_TEC_Msk) >> CAN_ECR_TEC_Pos);
    e->error_passive = (sr & CAN_SR_ERRP) ? 1 : 0;
    e->bus_off       = (sr & CAN_SR_BOFF) ? 1 : 0;
}


/*
// Example CAN interrupt handler.
// Not used: main.c polls can_rx() in its 10 ms loop instead, which keeps
// all CAN handling on one thread and avoids having to make the game state
// volatile.
void CAN0_Handler(void){
    uint32_t can_sr = CAN0->CAN_SR;
    CanMsg m;

    if(can_sr & ((1 << rxJoystick) | (1 << rxOther))){
        while(can_rx(&m)){
            can_printmsg(m);
        }
    }

    NVIC_ClearPendingIRQ(ID_CAN0);
}
*/
