#include <stdio.h>
#include <string.h>

#include "settings.h"
#include "nvcfg.h"
#include "tuning.h"
#include "ir.h"
#include "solenoid.h"
#include "servo.h"

// Bump when the layout of settings_t changes: an old record is then
// ignored and the defaults are used, instead of reading garbage.
#define SETTINGS_VERSION    1

typedef struct
{
    int32_t  kp_u, ki_u, kd_u, tf_us;
    int32_t  travel;
    int16_t  u_max;
    uint8_t  boot_cal;
    uint8_t  ir_level;
    uint16_t ir_debounce_ms;
    uint16_t ir_holdoff_ms;
    uint16_t sol_pulse_ms;
    uint16_t sol_cooldown_ms;
    uint16_t servo_us;
    uint16_t reserved;
} settings_t;

static settings_t saved;            // what is in flash (valid if have_saved)
static bool       have_saved;
static int8_t     last_dirty = -1;  // for change detection in settings_tick()


static void collect(settings_t *s)
{
    tuning_params_t tp;

    memset(s, 0, sizeof *s);        // padding too, so memcmp() is exact
    tuning_get_params(&tp);
    s->kp_u     = tp.kp_u;
    s->ki_u     = tp.ki_u;
    s->kd_u     = tp.kd_u;
    s->tf_us    = tp.tf_us;
    s->u_max    = tp.u_max;
    s->travel   = tp.travel;
    s->boot_cal = tp.boot_cal;

    ir_get_config(&s->ir_debounce_ms, &s->ir_holdoff_ms, &s->ir_level);
    solenoid_get_timing(&s->sol_pulse_ms, &s->sol_cooldown_ms);
    s->servo_us = servo_get_us();
}


static void apply(const settings_t *s)
{
    tuning_params_t tp;

    tp.kp_u     = s->kp_u;
    tp.ki_u     = s->ki_u;
    tp.kd_u     = s->kd_u;
    tp.tf_us    = s->tf_us;
    tp.u_max    = s->u_max;
    tp.travel   = s->travel;
    tp.boot_cal = s->boot_cal;
    tuning_apply_params(&tp);

    ir_set_config(s->ir_debounce_ms, s->ir_holdoff_ms, s->ir_level);
    solenoid_set_timing(s->sol_pulse_ms, s->sol_cooldown_ms);
    servo_set_us(s->servo_us);
}


static bool dirty(void)
{
    if (!have_saved)
        return true;

    settings_t now;
    collect(&now);
    return memcmp(&now, &saved, sizeof now) != 0;
}


bool settings_boot(void)
{
    settings_t s;
    nvcfg_result_t r = nvcfg_load(SETTINGS_VERSION, &s, sizeof s);

    if (r != NVCFG_OK)
    {
        have_saved = false;
        printf("settings: none stored, using built-in defaults\r\n");
        return false;
    }

    apply(&s);
    collect(&saved);                // values after clamping = the reference
    have_saved = true;
    printf("settings: loaded from flash (#%lu)\r\n", (unsigned long)nvcfg_seq());
    return true;
}


void settings_report(void)
{
    tuning_params_t tp;
    tuning_get_params(&tp);

    // $NV,stored,seq,dirty,boot_cal
    printf("$NV,%d,%lu,%d,%d\r\n", have_saved ? 1 : 0,
           (unsigned long)nvcfg_seq(), dirty() ? 1 : 0, (int)tp.boot_cal);
    printf("$SERVO,%u\r\n", (unsigned)servo_get_us());
}


void settings_tick(void)
{
    int8_t d = dirty() ? 1 : 0;

    if (d != last_dirty)
    {
        last_dirty = d;
        if (tuning_link_active())
            settings_report();
    }
}


bool settings_command(const char *cmd, const long *a, uint8_t n)
{
    if (strcmp(cmd, "SAVE") == 0 && n == 0)
    {
        // During the reference drive the travel is not known yet: saving
        // now would store the wrong travel.
        if (tuning_mode() == TUNE_MODE_CAL)
        {
            printf("$ERR,SAVE,reference drive running - save when it has finished\r\n");
            return true;
        }

        settings_t s;
        collect(&s);

        nvcfg_result_t r = nvcfg_save(SETTINGS_VERSION, &s, sizeof s);
        if (r == NVCFG_OK)
        {
            saved      = s;
            have_saved = true;
            printf("$OK,SAVE,%lu\r\n", (unsigned long)nvcfg_seq());
        }
        else
            printf("$ERR,SAVE,%s\r\n", nvcfg_result_text(r));
        settings_report();
        return true;
    }

    if (strcmp(cmd, "LOAD") == 0 && n == 0)
    {
        settings_t s;
        nvcfg_result_t r = nvcfg_load(SETTINGS_VERSION, &s, sizeof s);
        if (r == NVCFG_OK)
        {
            apply(&s);
            collect(&saved);
            have_saved = true;
            printf("$OK,LOAD,%lu\r\n", (unsigned long)nvcfg_seq());
        }
        else
            printf("$ERR,LOAD,%s\r\n", nvcfg_result_text(r));
        tuning_report();            // gains, state, travel, I/O, $NV
        return true;
    }

    if (strcmp(cmd, "NVERASE") == 0 && n == 0)
    {
        nvcfg_result_t r = nvcfg_erase();
        if (r == NVCFG_OK)
        {
            have_saved = false;
            printf("$OK,NVERASE\r\n");
        }
        else
            printf("$ERR,NVERASE,%s\r\n", nvcfg_result_text(r));
        settings_report();
        return true;
    }

    if (strcmp(cmd, "NV") == 0 && n == 0)
    {
        settings_report();
        return true;
    }

    if (strcmp(cmd, "SERVO") == 0 && n == 1)
    {
        long us = a[0];
        if (us < 0)     us = 0;
        if (us > 65535) us = 65535;
        servo_set_us((uint16_t)us);
        printf("$SERVO,%u\r\n", (unsigned)servo_get_us());
        return true;
    }

    return false;
}
