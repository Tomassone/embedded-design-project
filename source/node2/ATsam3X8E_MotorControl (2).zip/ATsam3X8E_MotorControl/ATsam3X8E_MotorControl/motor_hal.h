// motor_hal.h -- what tuning.c needs from the exercise 8 hardware code
//
// Implement these four functions in your motor/encoder driver.
// tuning.c and pid.c only call this interface, so they compile and
// run unchanged on the board and in the PC simulator.

#ifndef MOTOR_HAL_H
#define MOTOR_HAL_H

#include <stdint.h>

// Motor command in permille of full scale: -1000 .. +1000.
// Sign selects the direction pin, magnitude sets the PWM duty.
// 0 must stop the motor.
void motor_hal_set(int16_t u_permille);

// Current encoder position in counts (TC2 quadrature decoder).
int32_t motor_hal_position(void);

// Set the current encoder position to 0 (e.g. at the left end stop).
void motor_hal_zero(void);

// Free-running millisecond counter, used for telemetry time stamps
// and for the PC-link timeout. Wrap-around is handled.
uint32_t motor_hal_millis(void);

#endif
