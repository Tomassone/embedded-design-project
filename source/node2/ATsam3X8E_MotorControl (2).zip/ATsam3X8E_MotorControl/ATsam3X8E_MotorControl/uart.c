#include <stdio.h>
#include <errno.h>
#include <sys/stat.h>
#include "sam.h"
#include "uart.h"
#include "board.h"

// Sizes must be powers of two (index wrap by masking).
#define RX_SIZE  256u
#define TX_SIZE  1024u

_Static_assert((RX_SIZE & (RX_SIZE - 1)) == 0, "RX_SIZE must be a power of two");
_Static_assert((TX_SIZE & (TX_SIZE - 1)) == 0, "TX_SIZE must be a power of two");

static volatile uint8_t  rx_buf[RX_SIZE];
static volatile uint16_t rx_head, rx_tail;     // ISR writes head, main reads tail

static volatile uint8_t  tx_buf[TX_SIZE];
static volatile uint16_t tx_head, tx_tail;     // main writes head, ISR reads tail


void uart_init(uint32_t cpufreq, uint32_t baudrate)
{
    // PA8 = URXD, PA9 = UTXD, peripheral A
    PMC->PMC_PCER0 = (1u << ID_PIOA) | (1u << ID_UART);
    PIOA->PIO_PDR   = PIO_PA8A_URXD | PIO_PA9A_UTXD;
    PIOA->PIO_ABSR &= ~(PIO_PA8A_URXD | PIO_PA9A_UTXD);
    PIOA->PIO_PUER  = PIO_PA8A_URXD;            // idle high if nothing is connected

    UART->UART_CR   = UART_CR_RSTRX | UART_CR_RSTTX | UART_CR_RXDIS | UART_CR_TXDIS;
    UART->UART_IDR  = 0xFFFFFFFFu;

    // Baud = MCK / (16 * CD), rounded to the nearest divider.
    // 84 MHz, 115200 -> CD 46 -> 114 130 baud (-0.9 %), well inside spec.
    UART->UART_BRGR = (cpufreq + 8u * baudrate) / (16u * baudrate);
    UART->UART_MR   = UART_MR_PAR_NO | UART_MR_CHMODE_NORMAL;

    rx_head = rx_tail = 0;
    tx_head = tx_tail = 0;

    UART->UART_IER = UART_IER_RXRDY;
    NVIC_ClearPendingIRQ(UART_IRQn);
    NVIC_SetPriority(UART_IRQn, 2);
    NVIC_EnableIRQ(UART_IRQn);

    UART->UART_CR = UART_CR_RXEN | UART_CR_TXEN;

    // Line-buffered stdout with a small buffer on the heap.
    //
    // Do NOT use _IONBF here: for an unbuffered stream newlib's printf
    // puts a temporary 1024-byte buffer on the STACK for every call.
    // With Atmel Studio's default stack that overflows into .bss, where
    // the UART ring buffers sit, and the UART then sends stack garbage.
    static char stdout_buf[128];
    setvbuf(stdout, stdout_buf, _IOLBF, sizeof stdout_buf);
}


// ---------------------------------------------------------------------
// Last-resort output that needs no interrupts and no ring buffer.
// Used by the fault handler, where the normal path cannot be trusted.
// ---------------------------------------------------------------------
void uart_puts_blocking(const char *s)
{
    while (*s)
    {
        while (!(UART->UART_SR & UART_SR_TXRDY))
            ;
        UART->UART_THR = (uint8_t)*s++;
    }
}


// A crash (bad pointer, stack overflow into a return address) lands
// here instead of silently freezing. The motor is stopped first.
void HardFault_Handler(void)
{
    __disable_irq();

    // Motor off without trusting the PWM block: take the A3959 ENABLE pin
    // over as a GPIO and drive it low.
    MOTOR_PWM_PIO->PIO_CODR = MOTOR_PWM_PIN;
    MOTOR_PWM_PIO->PIO_OER  = MOTOR_PWM_PIN;
    MOTOR_PWM_PIO->PIO_PER  = MOTOR_PWM_PIN;
    PWM->PWM_DIS = 0x0Fu;                       // all PWM channels off

    // Solenoid driver off.
#if SOLENOID_ACTIVE_HIGH
    SOLENOID_PIO->PIO_CODR = SOLENOID_PIN;
#else
    SOLENOID_PIO->PIO_SODR = SOLENOID_PIN;
#endif
    uart_puts_blocking("\r\n!! HardFault -- node 2 stopped. Reset the Due.\r\n");
    for (;;)
        ;
}


void UART_Handler(void)
{
    uint32_t sr = UART->UART_SR;

    if (sr & UART_SR_RXRDY)
    {
        uint8_t  c    = (uint8_t)UART->UART_RHR;
        uint16_t next = (rx_head + 1u) & (RX_SIZE - 1u);
        if (next != rx_tail)                    // full: drop the newest byte
        {
            rx_buf[rx_head] = c;
            rx_head = next;
        }
    }

    // Overrun / framing errors: clear them so reception continues.
    if (sr & (UART_SR_OVRE | UART_SR_FRAME | UART_SR_PARE))
        UART->UART_CR = UART_CR_RSTSTA;

    if ((sr & UART_SR_TXRDY) && (UART->UART_IMR & UART_IMR_TXRDY))
    {
        if (tx_tail != tx_head)
        {
            UART->UART_THR = tx_buf[tx_tail];
            tx_tail = (tx_tail + 1u) & (TX_SIZE - 1u);
        }
        else
        {
            UART->UART_IDR = UART_IDR_TXRDY;    // nothing left to send
        }
    }
}


uint8_t uart_rx(uint8_t *c)
{
    if (rx_tail == rx_head)
        return 0;

    *c = rx_buf[rx_tail];
    rx_tail = (rx_tail + 1u) & (RX_SIZE - 1u);
    return 1;
}


void uart_tx(uint8_t c)
{
    uint16_t next = (tx_head + 1u) & (TX_SIZE - 1u);

    while (next == tx_tail)                     // buffer full: wait for the ISR
        ;

    tx_buf[tx_head] = c;
    tx_head = next;
    UART->UART_IER = UART_IER_TXRDY;            // (re)start the ISR
}


void uart_flush(void)
{
    while (tx_tail != tx_head)
        ;
    while (!(UART->UART_SR & UART_SR_TXEMPTY))
        ;
}


// ---------------------------------------------------------------------
// newlib system calls, so printf() works without extra libraries.
// _write sends to the UART. The others are weak placeholders: if your
// toolchain settings already provide them, those win.
// ---------------------------------------------------------------------

int _write(int file, char *ptr, int len)
{
    (void)file;
    for (int i = 0; i < len; i++)
        uart_tx((uint8_t)ptr[i]);
    return len;
}

__attribute__((weak)) int _read(int file, char *ptr, int len)
{
    (void)file; (void)ptr; (void)len;
    return 0;
}

__attribute__((weak)) int _close(int file)            { (void)file; return -1; }
__attribute__((weak)) int _isatty(int file)           { (void)file; return 1; }
__attribute__((weak)) int _lseek(int file, int p, int d) { (void)file; (void)p; (void)d; return 0; }
__attribute__((weak)) int _getpid(void)               { return 1; }
__attribute__((weak)) int _kill(int pid, int sig)     { (void)pid; (void)sig; errno = EINVAL; return -1; }
__attribute__((weak)) void _exit(int status)          { (void)status; for (;;) ; }

__attribute__((weak)) int _fstat(int file, struct stat *st)
{
    (void)file;
    st->st_mode = S_IFCHR;
    return 0;
}

// Heap for printf's buffers: starts at _end (defined by Atmel's linker
// script, after .bss and the stack) and grows upward through free RAM.
__attribute__((weak)) void *_sbrk(int incr)
{
    extern char _end;
    static char *heap_end;

    if (heap_end == 0)
        heap_end = &_end;

    char *prev = heap_end;
    heap_end += incr;
    return prev;
}
