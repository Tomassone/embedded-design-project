#pragma once
#include <stdint.h>
#include "motor_hal.h"

// ---------------------------------------------------------------------
// motor.h -- exercise 8 motor driver and encoder
//
// The motor_hal_* functions declared in motor_hal.h are implemented in
// motor.c on top of this driver. tuning.c only uses that interface.
// ---------------------------------------------------------------------

// PWM, direction pin and quadrature decoder. Call first in main(): it
// pulls the A3959 ENABLE pin low before anything else runs.
void motor_init(void);

// Joystick x (-range..+range) to a position setpoint in encoder counts,
// inside travel minus MOTOR_MARGIN_COUNTS at each end.
// The reference drive itself lives in tuning.c (tuning_start_cal()).
int32_t motor_joystick_to_counts(int8_t x, int8_t range, int32_t travel);
