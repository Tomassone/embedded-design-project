#define F_CPU 4915200UL
#define BAUD 9600UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include "uart.h"
#include "sram.h"

int main(void)
{
	DDRB |= (1 << PB0);   // heartbeat LED

	uart_init();
	sei();

	xmem_init();

	printf("\r\nSRAM Test\r\n");
	printf("  t = run SRAM test\r\n");

	while (1)
	{
		if (uart_available())
		{
			char c = getchar();

			switch (c)
			{
				case 't':
				case 'T':
				sram_test();
				break;
				default:
				printf("Invalid input: '%c'\r\n", c);
				break;
			}
		}

		PORTB ^= (1 << PB0);
		_delay_ms(200);
	}
}