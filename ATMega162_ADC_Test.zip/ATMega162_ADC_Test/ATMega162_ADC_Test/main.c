#define F_CPU 4915200UL
#define BAUD 9600UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include "uart.h"
#include "sram.h"
#include "adc.h"

int main(void)
{
	DDRB |= (1 << PB0);   // heartbeat LED

	uart_init();
	sei();

	xmem_init();          // must come before any ADC or SRAM access
	adc_init();

	uint8_t streaming = 0;

	printf("\r\nNode 1 test menu\r\n");
	printf("  t = run SRAM test\r\n");
	printf("  j = read joystick once\r\n");
	printf("  s = toggle continuous joystick streaming\r\n");
	printf("  a = read all four ADC channels\r\n");

	while (1)
	{
		if (uart_available())
		{
			char c = getchar();

			switch (c)
			{
				case 't':
				case 'T':
				sram_test();
				break;

				case 'j':
				case 'J':
				{
					uint8_t x = adc_read_channel(ADC_CH_JOY_X);
					uint8_t y = adc_read_channel(ADC_CH_JOY_Y);
					printf("X = %3u   Y = %3u\r\n", x, y);
					break;
				}

				case 's':
				case 'S':
				streaming = !streaming;
				printf("Streaming %s\r\n", streaming ? "on" : "off");
				break;

				case 'a':
				case 'A':
				{
					uint8_t ch[4];
					adc_read_all(ch);
					printf("AIN0=%3u AIN1=%3u AIN2=%3u AIN3=%3u\r\n",
					ch[0], ch[1], ch[2], ch[3]);
					break;
				}

				default:
				printf("Invalid input: '%c'\r\n", c);
				break;
			}
		}

		if (streaming)
		{
			uint8_t x = adc_read_channel(ADC_CH_JOY_X);
			uint8_t y = adc_read_channel(ADC_CH_JOY_Y);
			printf("X = %3u   Y = %3u\r\n", x, y);
		}

		PORTB ^= (1 << PB0);

		// _delay_ms() needs a compile-time constant, so the two rates
		// are separate calls rather than a ternary expression.
		if (streaming)
		_delay_ms(100);
		else
		_delay_ms(200);
	}
}