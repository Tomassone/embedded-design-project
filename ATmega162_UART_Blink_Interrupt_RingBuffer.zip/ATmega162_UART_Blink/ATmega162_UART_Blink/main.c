#define F_CPU 4915200UL
#define BAUD 9600UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include "uart.h"

int main(void)
{
	uart_init();
	sei();  // enable global interrupts -- required for all interrupt-based bus code

	DDRC |= (1 << PC0);  // LED on PC0 as output

	uint16_t blink_delay_ms = 500;

	printf("\r\nRS232 LED Blink Control (interrupt-driven)\r\n");
	printf("Select speed:\r\n");
	printf("  1 = slow   (1000 ms)\r\n");
	printf("  2 = medium (500 ms)\r\n");
	printf("  3 = fast   (100 ms)\r\n");

	while (1)
	{
		if (uart_available())
		{
			char c = getchar();

			switch (c)
			{
				case '1':
				blink_delay_ms = 1000;
				printf("-> slow selected (1000 ms)\r\n");
				break;
				case '2':
				blink_delay_ms = 500;
				printf("-> medium selected (500 ms)\r\n");
				break;
				case '3':
				blink_delay_ms = 100;
				printf("-> fast selected (100 ms)\r\n");
				break;
				default:
				printf("Invalid input: '%c'\r\n", c);
				break;
			}
		}

		PORTC ^= (1 << PC0);

		for (uint16_t i = 0; i < blink_delay_ms / 10; i++)
		{
			_delay_ms(10);
		}
	}
}